import sys

def add_new_user(a):
    global dict
    dict[a] = []


def delete_existing_user(f):
    global dict
    del dict[f]
    for j in dict.values():
        if f in j:
            j.remove(f)


def add_new_friend(v,b):
    global dict
    dict[v].append(b)
    dict[b].append(v)


def delete_existing_friend(m,n):
    global dict
    for i in dict[m]:
        if i == n:
            dict[m].remove(i)
    for j in dict[n]:
        if j == m:
            dict[n].remove(j)


def count_friends(l):
    global dict
    global t
    t = len(dict[l])


def find_possible_friends(h,p):
    global w
    global y
    global dict
    global list3
    list3 = []
    if p == "1":
        for i in dict[h]:
            list3.append(i)
        w = list3
        w.sort()
        y = len(w)
    elif p == "2":
        for i in dict[h]:
            list3.append(i)
            for j in dict[i]:
                list3.append(j)
        for k in list3:
            if k == h:
                list3.remove(k)
        w = set(list3)
        w = list(w)
        w.sort()
        y = len(w)
    elif p == "3":
        for i in dict[h]:
            list3.append(i)
            for j in dict[i]:
                list3.append(j)
                for r in dict[j]:
                    list3.append(r)
        for s in list3:
            if s == h:
                list3.remove(s)
        w = set(list3)
        w = list(w)
        w.sort()
        y = len(w)


def suggest_friend(pla,md):
    global liste4
    liste4 = []
    cou2 = []
    cou3 = []
    ar = ""
    if md == 2:
        for i in dict[pla]:
            liste4.extend(dict[i])
        for j in liste4:
            if j == pla:
                liste4.remove(pla)
        for z in liste4:
            if z in dict[pla]:
                liste4.remove(z)
        for ost in liste4:
            if liste4.count(ost) == 2:
                cou2.append(ost)
                so = set(cou2)
                cou2 = list(so)
                cou2.sort()
            elif liste4.count(ost) == 3:
                cou3.append(ost)
                os = set(cou3)
                cou3 = list(os)
                cou3.sort()
        sta = cou2 + cou3
        ar += "Suggestion List for '{}' (when MD is {}):\n".format(pla,md)
        for sos in sta:
            ar += "'{}' has {} mutual friends with '{}'\n".format(pla,liste4.count(sos),sos)
        sta.sort()
        ar += "The suggested friends for '{}':{}\n".format(pla,sta)
        ar = ar.replace("[","")
        ar = ar.replace("]","")
        ar = ar.replace(", ", ",")
    elif md == 3:
        for i in dict[pla]:
            liste4.extend(dict[i])
        for j in liste4:
            if j == pla:
                liste4.remove(pla)
        for z in liste4:
            if z in dict[pla]:
                liste4.remove(z)
        for tso in liste4:
            if liste4.count(tso) == 3:
                cou3.append(tso)
                uy = set(cou3)
                cou3 = list(uy)
        ar += "Suggestion List for '{}' (when MD is {}):\n".format(pla, md)
        cou3.sort()
        for sos in cou3:
            ar += "'{}' has {} mutual friends with '{}'\n".format(pla, liste4.count(sos), sos)
        ar += "The suggested friends for '{}':{}\n".format(pla, cou3)
        ar = ar.replace("[", "")
        ar = ar.replace("]", "")
        ar = ar.replace(", ",",")
    return ar


dict = {}
list1 = []
list2 = []
with open(sys.argv[1],"r+",encoding="utf-8") as file:
    for i in file:
        if "\n" in i:
            i = i[:-1]
            i = i.strip()
            a = i.split(":")
            b = a[1].split(" ")
            dict[a[0]] = []
            for j in b:
                if j != "":
                    dict[a[0]].append(j)
        elif "\n" not in i:
            i = i.strip()
            a = i.split(":")
            b = a[1].split(" ")
            dict[a[0]] = []
            for j in b:
                if j != "":
                    dict[a[0]].append(j)
    with open(sys.argv[2], "r", encoding="utf-8") as file1:
        for g in file1:
            if "\n" in g:
                g = g[:-1]
                g = g.strip()
                c = g.split(" ")
                list1.append(c)
            elif "\n" not in g:
                g = g.strip()
                c = g.split(" ")
                list1.append(c)
        with open("output.txt", "w", encoding="utf-8") as file2:
            for k in list1:
                if k[0] == "ANU":
                    if k[1] in dict:
                        file2.write("ERROR: Wrong input type! for 'ANU!' -- This user already exists!!\n")
                    elif k[1] not in dict:
                        a = k[1]
                        add_new_user(a)
                        file2.write("User '{}' has been added to the social network successfully\n".format(k[1]))
                elif k[0] == "DEU":
                    if k[1] not in dict:
                        file2.write("ERROR: Wrong input type! for 'DEU'!--There is no user named '{}'!!\n".format(k[1]))
                    elif k[1] in dict:
                        f = k[1]
                        delete_existing_user(f)
                        file2.write("User '{}' and his/her all relations have been removed successfully\n".format(k[1]))
                elif k[0] == "ANF":
                    if k[1] not in dict and k[2] in dict:
                        file2.write("ERROR: Wrong input type! for 'ANF'! -- No user named '{}' found!!\n".format(k[1]))
                    elif k[1] in dict and k[2] not in dict:
                        file2.write("ERROR: Wrong input type! for 'ANF'! -- No user named '{}' found!!\n".format(k[2]))
                    elif k[1] not in dict and k[2] not in dict:
                        file2.write("ERROR: Wrong input type! for 'ANF'! -- No user named '{}' and '{}' found!!\n".format(k[1],k[2]))
                    elif k[1] and k[2] in dict:
                        if k[1] in dict[k[2]] and k[2] in dict[k[1]]:
                            file2.write("ERROR: A relation between '{}' and '{}' already exists!!\n".format(k[1],k[2]))
                        elif k[1] not in dict[k[2]] and k[2] not in dict[k[1]]:
                            v = k[1]
                            b = k[2]
                            add_new_friend(v,b)
                            file2.write("Relation between '{}' and '{}' has been added successfully\n".format(k[1],k[2]))
                elif k[0] == "DEF":
                    if k[1] not in dict and k[2] in dict:
                        file2.write("ERROR: Wrong input type! for 'DEF'! -- No user named '{}' found!!\n".format(k[1]))
                    elif k[1] in dict and k[2] not in dict:
                        file2.write("ERROR: Wrong input type! for 'DEF'! -- No user named '{}' found!!\n".format(k[2]))
                    elif k[1] not in dict and k[2] not in dict:
                        file2.write("ERROR: Wrong input type! for 'DEF'! -- No user named '{}' and '{}' found!\n".format(k[1],k[2]))
                    elif k[1] and k[2] in dict:
                        if k[1] not in dict[k[2]] and k[2] not in dict[k[1]]:
                            file2.write("ERROR: No relation between '{}' and '{}' found!!\n".format(k[1],k[2]))
                        elif k[1] in dict[k[2]] and k[2] in dict[k[1]]:
                            m = k[1]
                            n = k[2]
                            delete_existing_friend(m,n)
                            file2.write("Relation between '{}' and '{}' has been deleted successfully\n".format(k[1],k[2]))
                elif k[0] == "CF":
                    if k[1] not in dict:
                        file2.write("ERROR: Wrong input type! for 'CF'! -- No user named '{}' found!\n".format(k[1]))
                    elif k[1] in dict:
                        l = k[1]
                        count_friends(l)
                        file2.write("User '{}' has {} friends\n".format(k[1],t))
                elif k[0] == "FPF":
                    if k[1] not in dict:
                        file2.write("ERROR: Wrong input type! for 'FPF'! -- No user named '{}' found!\n".format(k[1]))
                    elif int(k[2])<1 or int(k[2]) > 3:
                        file2.write("ERROR: Maximum distance is out of range!!\n")
                    elif k[1] in dict:
                        h = k[1]
                        p = k[2]
                        find_possible_friends(h,p)
                        file2.write("User '{}' has {} possible friends when maximum distance is {}\n".format(k[1],y,p))
                        txt = "These possible friends: {possible_friend_list}".format(possible_friend_list=w)
                        x = txt.replace("[","{")
                        x = x.replace("]","}")
                        file2.write(x+"\n")
                elif k[0] == "SF":
                    md = int(k[2])
                    if k[1] not in dict.keys():
                        file2.write("ERROR: Wrong input type! for 'SF'! -- No user named '{}' found!\n".format(k[1]))
                    elif md<2 or md> 3:
                        file2.write("Error: Mutually Degree cannot be less than 2 or greater than 3" + "\n")
                    elif (k[1] in dict) and (md> 1 and md<4):
                        pla = k[1]
                        file2.write(suggest_friend(pla, md))