import sys


def see_matris():
    global matris
    for c in range(len(matris)):
        for d in range(len(matris[c])):
            print(matris[c][d], end=" ")
        print()
def cell_exploding(r,c,d):
    global liste
    global matris
    try:
        if d != "up":
            if matris[r][c] == matris[r + 1][c] and [r+1,c] not in liste:
                liste.append([r + 1, c])
                cell_exploding(r + 1, c,"down")
    except:
        pass

    try:
        if d != "down" and r != 0:
            if matris[r][c] == matris[r - 1][c] and [r-1,c] not in liste:
                liste.append([r - 1, c])
                cell_exploding(r - 1, c,"up")
    except:
        pass

    try:
        if d != "left":
            if matris[r][c] == matris[r][c + 1] and [r,c+1] not in liste:
                liste.append([r, c + 1])
                cell_exploding(r, c + 1,"right")
    except:
        pass
    try:
        if d != "right" and c != 0:
            if matris[r][c] == matris[r][c - 1] and [r,c-1] not in liste:
                liste.append([r, c - 1])
                cell_exploding(r, c - 1,"left")
    except:
        pass

def remove():
    global liste
    global matris
    global point_dict
    global score_total
    score_adder1 = []
    if len(liste) > 1:
        for x in liste:
            score_adder1.append(matris[x[0]][x[1]])
            matris[x[0]][x[1]] = " "
        try:
            for i in score_adder1:
                score_total += point_dict[i]
        except:
            pass
    liste = []

def swap():
    global matris
    saver = []
    for z in matris:
        for i in range(len(z)):
            for j in range(len(matris)):
                try:
                    if matris[j][i] != " " and matris[j+1][i] == " ":
                        matris[j][i],matris[j+1][i] = matris[j+1][i],matris[j][i]
                except:
                    pass
    for i in range(len(matris)):
        empty_check = []
        for j in range(len(matris[0])):
            if matris[i][j] == " ":
                empty_check.append(matris[i][j])
                if empty_check == matris[i]:
                    saver.append(0)
    for i in saver:
        matris.remove(matris[i])
def trim():
    global matris
    try:
        a = 0
        k = matris[-1]
        while a < len(k):
            if k[a] == " ":
                for i in matris:
                    del i[a]
            elif k[a] != " ":
                a += 1
    except IndexError:
        pass
def bomb(r,c):
    global matris
    global score_total
    global point_dict
    for i in range(len(matris[r])):
        if matris[r][i] != "X":
            try:
                score_total += int(point_dict[matris[r][i]])
            except:
                pass
            matris[r][i] = " "
        elif matris[r][i] == "X" and i == c:
                matris[r][i] = " "
        elif matris[r][i] == "X" and i != c:
            che = i
            bomb(r,che)
    for j in range(len(matris)):
        if matris[j][c] != "X":
            try:
                score_total += int(point_dict[matris[j][c]])
            except:
                pass
            matris[j][c] = " "
        elif matris[j][c] == "X" and j == r:
            matris[j][c] = " "
        elif matris[j][c] == "X" and j != r:
            hec = j
            bomb(hec,c)
with open(sys.argv[1],"r",encoding="utf8") as file:
    a = file.readlines()
    matris = []
    score_total = 0
    point_dict = {"B":9,"G":8,"W":7,"Y":6,"R":5,"P":4,"O":3,"D":2,"F":1}
    for i in a:
        if "\n" in i:
            i = i[:-1]
            i = i.split()
            matris.append(i)
        elif "\n" not in i:
            i = i.split()
            matris.append(i)
see_matris()
print("")
print("Your score is: {}".format(score_total))
print("")
while True:
    liste = []
    end_point = 0
    try:
        rocol = input("Please enter a row and column number: ")
        r, c = rocol.split(" ")
        r, c = int(r), int(c)
        liste.append([r, c])
        if matris[r][c] == " ":
            print("")
            print("Please enter a valid size!")
            print("")
        elif matris[r][c] != " ":
            if matris[r][c] != "X":
                cell_exploding(r,c,"")
                remove()
                swap()
                trim()
                print("")
                see_matris()
                print("")
                print("Your score is: {}".format(score_total))
                print("")
            elif matris[r][c] == "X":
                bomb(r,c)
                swap()
                trim()
                print("")
                see_matris()
                print("")
                print("Your score is: {}".format(score_total))
                print("")
            for set in range(len(matris)):
                for tse in range(len(matris[-1])):
                        if matris[set][tse] != " ":
                            try:
                                if matris[set][tse] == matris[set][tse+1]:
                                    end_point += 1
                            except:
                                pass
                            try:
                                if matris[set][tse] == matris[set+1][tse]:
                                    end_point += 1
                            except:
                                pass
                            if matris[set][tse] == "X":
                                    end_point += 1
            if end_point == 0:
                print("Game over!")
                break
    except:
        print("")
        print("Please enter a valid size!")
        print("")