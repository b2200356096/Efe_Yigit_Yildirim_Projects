def cre_mat(n):
    global m1
    m1 = [["+" for x in range(n+2)] for y in range(n+2)]
    for v in range(n+2):
            for h in range(n+2):
                if (v == 0 or v == n+1 or h == 0 or h == n+1):
                    pass
                else:
                    m1[v][h] = " "
def brush_down():
    global brush
    global a
    global b
    brush = "down"
    m1[a][b] = "1"
def brush_up():
    global brush
    brush = "up"
def rotate_right():
    global current
    if (current == "right"):
        current = "down"
    elif (current == "down"):
        current = "left"
    elif (current == "left"):
        current = "up"
    elif (current == "up"):
        current = "right"

def rotate_left():
    global current
    if (current == "right"):
        current = "up"
    elif (current == "down"):
        current = "right"
    elif (current == "left"):
        current = "down"
    elif (current == "up"):
        current = "left"

def reverse():
    global current
    if (current == "right"):
        current = "left"
    elif (current == "left"):
        current = "right"
    elif (current == "up"):
        current = "down"
    elif (current == "down"):
        current = "up"
def move(e):
    global brush
    global current
    global a
    global b
    if (brush == "down"):
        if (current == "right"):
            if ((b + e) > n):
                if (e < n):
                    f = (b + e) % n
                    g = 1
                    while (b <= n):
                        m1[a][b] = "1"
                        b += 1
                    while (g <= f):
                        m1[a][g] = "1"
                        g += 1
                    b = f
                elif (e >= n):
                    for l in range(1,n+1):
                        m1[a][l] = "1"
                    if ((b + e) % n == 0):
                        b = n
                    elif ((b + e) % n != 0):
                        b = (b + e) % n
            elif ((b + e) <= n):
                c = e + b
                while True:
                    m1[a][b] = "1"
                    b += 1
                    if (c == b):
                        m1[a][b] = "1"
                        break
        elif (current == "left"):
            if ((b - e) >= 1):
                c = b - e
                while True:
                    m1[a][b] = "1"
                    b -= 1
                    if (b == c):
                        m1[a][b] = "1"
                        break
            elif ((b - e) < 1):
                if (e < n):
                    if ((b - e) != 0):
                        f = (b - e) % n
                        g = n
                        while (b >= 1):
                            m1[a][b] = "1"
                            b -= 1
                        while (g > f):
                            m1[a][g] = "1"
                            g -= 1
                        if (g == f):
                            m1[a][g] = "1"
                        b = g
                    elif ((b - e) == 0):
                        g = n
                        while (b >= 1):
                            m1[a][b] = "1"
                            b -= 1
                        m1[a][g] = "1"
                        b = g
                elif (e >= n):
                    for l in range(1,n+1):
                        m1[a][l] = "1"
                    if ((b - e) % n == 0):
                        b = n
                    elif ((b - e) % n != 0):
                        b = (b - e) % n
        elif (current == "up"):
            if ((a - e) >= 1):
                c = a - e
                while True:
                    m1[a][b] = "1"
                    a -= 1
                    if (a == c):
                        m1[a][b] = "1"
                        break
            elif ((a - e) < 1):
                if (e < n):
                    if ((a - e) != 0):
                        f = (a - e) % n
                        g = n
                        while (a >= 1):
                            m1[a][b] = "1"
                            a -= 1
                        while (g > f):
                            m1[g][b] = "1"
                            g -= 1
                        if (g == f):
                            m1[g][b] = "1"
                        a = g
                    elif ((a - e) == 0):
                        g = n
                        while (a >= 1):
                            m1[a][b] = "1"
                            a -= 1
                        m1[g][b] = "1"
                        a = g
                elif (e >= n):
                    for l in range(1,n+1):
                        m1[l][b] = "1"
                    if ((a - e) % n == 0):
                        a = n
                    elif ((a - e) % n != 0):
                        a = (a - e) % n
        elif (current == "down"):
            if ((a + e) > n):
                if (e < n):
                    f = (a + e) % n
                    g = 1
                    while (a <= n):
                        m1[a][b] = "1"
                        a += 1
                    while (g <= f):
                        m1[g][b] = "1"
                        g += 1
                    a = f
                elif (e >= n):
                    for g in range(1,n+1):
                        m1[g][b] = "1"
                    if ((a + e) % n == 0):
                        a = n
                    elif ((a + e) % n != 0):
                        a = (a + e) % n
            elif ((a + e) <= n):
                c = a + e
                while True:
                    m1[a][b] = "1"
                    a += 1
                    if (c == a):
                        m1[a][b] = "1"
                        break
    if (brush == "up"):
        if (current == "right"):
            if ((b + e) > n):
                if ((b + e) % n == 0):
                    b = n
                    cur_pos = m1[a][b]
                elif ((b + e) % n != 0):
                    b = (b + e) % n
            elif ((b + e) <= n):
                b = (b + e)
        elif (current == "left"):
            if ((b - e) < 1):
                if ((b - e) % n == 0):
                    b = n
                elif ((b - e) % n != 0):
                    b = (b - e) % n
            elif ((b - e) >= 1):
                b = (b - e)
        elif (current == "up"):
            if ((a - e) < 1):
                if ((a - e) % n == 0):
                    a = n
                elif ((a - e) % n != 0):
                    a = (a - e) % n
            elif ((a - e) >= 1):
                a = (a - e)
        elif (current == "down"):
            if ((a + e) > n):
                if ((a + e) % n == 0):
                    a = n
                elif ((a + e) % n != 0):
                    a = (a + e) % n
            elif ((a + e) <= n):
                a = (a + e)

def jump():
    global brush
    global current
    global a
    global b
    c = 3
    if (current == "right"):
        if((b + c) <= n):
            b = (b + c)
        elif((b + c) > n):
            b = (b + c) % n
    elif (current == "left"):
        if ((b - c) >= 1):
            b = (b - c)
        elif ((b - c) < 1):
            if ((b - c) == 0):
                b = n
            elif ((b - c) != 0):
                b = (b - c) % n
    elif (current == "up"):
        if ((a - c) >= 1):
            a = (a - c)
        elif ((a - c) < 1):
            if ((a - c) == 0):
                a = n
            elif ((a - c) != 0):
                a = (a - c) % n
    elif (current == "down"):
        if ((a + c) <= n):
            a = (a + c)
        elif ((a + c) > n):
            a = (a + c) % n
    if (brush == "up"):
        pass
    elif (brush == "down"):
        brush = "up"

def view():
    for r in range(1,n+1):
        for h in range(1,n+1):
            if (m1[r][h] == "1"):
                m1[r][h] = "*"
            else:
                pass
    for c in range(len(m1)):
        for d in range(len(m1)):
            print(m1[c][d], end="")
        print()
p = 0
print("""<-----RULES----->
1. BRUSH DOWN
2. BRUSH UP
3. VEHICLE ROTATES RIGHT
4. VEHICLE ROTATES LEFT
5. MOVE UP TO X
6. JUMP
7. REVERSE DIRECTION
8. VIEW THE MATRIX
0. EXIT
Please enter the commands with a plus sign (+) between them.
""", end="")
while (p == 0):
    l = input("")
    liste8 = list()
    liste8 = l.split("+")
    liste9 = list()
    liste9.append(liste8[0])
    liste8.remove(liste8[0])
    n = int(liste9[0])
    cre_mat(int(n))
    a = 1
    b = 1
    brush = "up"
    current = "right"
    for i in liste8:
        if (i == "1"):
            brush_down()
        elif (i == "2"):
            brush_up()
        elif (i == "3"):
            rotate_right()
        elif (i == "4"):
            rotate_left()
        elif (i[0] == "5"):
            if (len(i) < 3):
                print("You entered an incorrect command. Please try again!")
                break
            elif (len(i) == 3):
                e = int(i[2])
            elif (len(i) > 3):
                liste35 = i.split("_")
                if (len(liste35[0]) > 1):
                    print("You entered an incorrect command. Please try again!")
                    break
                elif (len(liste35[0]) == 1):
                    e = int(liste35[1])
            move(e)
        elif (i == "6"):
            jump()
        elif (i == "7"):
            reverse()
        elif (i == "8"):
            view()
        elif (i == "0"):
            p = 1
            break
        else:
            print("You entered an incorrect command. Please try again!")
            break