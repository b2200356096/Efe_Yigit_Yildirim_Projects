import java.io.*;
import java.util.*;
import java.awt.*;
import java.util.List;

public class IMECEPathFinder {
    public int[][] grid;
    int max = 0;
    int min = 0;
    public int height, width;
    public int maxFlyingHeight;
    public double fuelCostPerUnit, climbingCostPerUnit;
    Double[][] to_calculate;
    Point final_one;

    public IMECEPathFinder(String filename, int rows, int cols, int maxFlyingHeight, double fuelCostPerUnit, double climbingCostPerUnit) {
        grid = new int[rows][cols];
        try {
            File file = new File(filename);
            Scanner fileReader = new Scanner(file);
            String[][] split_strings = new String[rows][cols];
            int b = 0;
            while (fileReader.hasNextLine()) {
                String data = fileReader.nextLine();
                String[] split_line = data.split("[\\t ]+");
                split_strings[b] = split_line;
                b++;
            }
            max = Integer.parseInt(split_strings[0][1]);
            min = Integer.parseInt(split_strings[0][1]);
            for (int i = 0; i < rows; i++) {
                for (int j = 1; j < cols + 1; j++) {
                    int value = Integer.parseInt(split_strings[i][j]);
                    if (value > max) {
                        max = value;
                    }
                    if (value < min) {
                        min = value;
                    }
                    grid[i][j - 1] = value;
                }
            }
        } catch (FileNotFoundException fileNotFoundException) {
            int a = 5;
        }
        this.height = rows;
        this.width = cols;
        this.maxFlyingHeight = maxFlyingHeight;
        this.fuelCostPerUnit = fuelCostPerUnit;
        this.climbingCostPerUnit = climbingCostPerUnit;
        // TODO: fill the grid variable using data from filename

    }


    /**
     * Draws the grid using the given Graphics object.
     * Colors should be grayscale values 0-255, scaled based on min/max elevation values in the grid
     */
    public void drawGrayscaleMap(Graphics g) {

        // TODO: draw the grid, delete the sample drawing with random color values given below
        try {
            File file = new File("grayscaleMap.dat");
            FileWriter fileWriter = new FileWriter(file);
            StringBuilder bartu = new StringBuilder();
            for (int i = 0; i < grid.length; i++) {
                for (int j = 0; j < grid[0].length; j++) {
                    double scale_value = (1.0*(grid[i][j] - min) / ( max - min)) * (255.0);
                    int scale_int_value = (int) scale_value;
                    if (j == grid[0].length - 1) {
                        bartu.append(scale_int_value);
                        bartu.append("\n");
                    } else {
                        bartu.append(scale_int_value).append(" ");
                    }
                    //g.setColor(new Color(scale_int_value, scale_int_value, scale_int_value));
                    //g.fillRect(j, i, 1, 1);
                }
            }
            fileWriter.write(String.valueOf(bartu));
            fileWriter.close();
        } catch (IOException ignore) {
        }
    }

    public double cost(Point u , Point point){
        double height_imp;
        double distance;
        if (grid[u.y][u.x] >= grid[point.y][point.x]){
            height_imp = 0.0;
        }else {
            height_imp = grid[point.y][point.x] - grid[u.y][u.x];
        }
        distance = (Math.sqrt(Math.pow((Math.abs(u.y) - Math.abs(point.y)),2) + Math.pow((Math.abs(u.x) - Math.abs(point.x)),2)));
        return (distance * fuelCostPerUnit) + (climbingCostPerUnit * height_imp);
    }

    /**
     * Get the most cost-efficient path from the source Point start to the destination Point end
     * using Dijkstra's algorithm on pixels.
     *
     * @return the List of Points on the most cost-efficient path from start to end
     */
    public List<Point> getMostEfficientPath(Point start, Point end) {
        List<Point> path = new ArrayList<>();
        // TODO: Your code goes here
        // TODO: Implement the Mission 0 algorithm here
        int num_Of_Vertices = grid.length * grid[0].length;
        Double[][] dist = new Double[grid.length][grid[0].length];
        Boolean[][] visited = new Boolean[grid.length][grid[0].length];
        Point[][] parent = new Point[grid.length][grid[0].length];
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                dist[i][j] = Double.MAX_VALUE;
            }
        }
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                visited[i][j] = false;
            }
        }
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                parent[i][j] = null;
            }
        }
        dist[start.y][start.x] = 0.0;
        PriorityQueue<Point> pq = new PriorityQueue<>();
        start.road = 0;
        pq.add(start);
        while (!pq.isEmpty()) {
            Point u = pq.poll();
            ArrayList<Point> points = new ArrayList<>();
            Point left = new Point(u.x -1, u.y);
            Point right = new Point(u.x + 1, u.y);
            Point up = new Point(u.x, u.y - 1);
            Point down = new Point(u.x, u.y + 1);
            Point left_down = new Point(u.x - 1, u.y + 1);
            Point left_up = new Point(u.x - 1, u.y - 1);
            Point right_down = new Point(u.x + 1, u.y + 1);
            Point right_up = new Point(u.x + 1, u.y - 1);
            points.add(left);points.add(right);
            points.add(up);points.add(down);
            points.add(left_down);points.add(left_up);
            points.add(right_down);points.add(right_up);
            for (Point point : points) {
                if (point.y < 0 || point.x < 0 || point.y == height || point.x == width || grid[point.y][point.x] > maxFlyingHeight) {
                    continue;
                } else {
                    double new_road = dist[u.y][u.x] + cost(u, point);
                    if (!visited[point.y][point.x]){
                        if (new_road < dist[point.y][point.x]) {
                            parent[point.y][point.x] = u;
                            dist[point.y][point.x] = new_road;
                            point.road = new_road;
                            pq.add(point);
                        }
                        visited[u.y][u.x] = true;
                    }
                }
            }
        }
        final_one = end;
        step_back_adder(path, parent, end, start);
        to_calculate = dist;
        //System.out.println(path);
        return path;
    }

    public static void step_back_adder(List<Point> path, Point[][] parent, Point end, Point source) {

        while (end != null) {
            path.add(0, end);
            end = parent[end.y][end.x];
        }
    }


    /**
     * Calculate the most cost-efficient path from source to destination.
     *
     * @return the total cost of this most cost-efficient path when traveling from source to destination
     */
    public double getMostEfficientPathCost(List<Point> path) {
        double totalCost = 0.0;

        // TODO: Your code goes here, use the output from the getMostEfficientPath() method
        totalCost = to_calculate[final_one.y][final_one.x];
        return totalCost;
    }


    /**
     * Draw the most cost-efficient path on top of the grayscale map from source to destination.
     */
    public void drawMostEfficientPath(Graphics g, List<Point> path) {
        // TODO: Your code goes here, use the output from the getMostEfficientPath() method
        for (Point point : path) {
            g.setColor(Color.green);
            g.fillRect(point.y, point.x, 1, 1);
        }
    }

    /**
     * Find an escape path from source towards East such that it has the lowest elevation change.
     * Choose a forward step out of 3 possible forward locations, using greedy method described in the assignment instructions.
     *
     * @return the list of Points on the path
     */
    public List<Point> getLowestElevationEscapePath(Point start) {
        List<Point> pathPointsList = new ArrayList<>();
        // TODO: Your code goes here
        // TODO: Implement the Mission 1 greedy approach here
        pathPointsList.add(start);
        int row = start.y;
        int column = start.x;
        while (column < width - 1) {
            Point straight = new Point(column + 1, row);
            Point northeast = new Point( column + 1, row - 1);
            Point southeast = new Point(column + 1, row + 1);

            // Calculate the differences in elevation
            straight.difference = Math.abs(grid[row][column] - grid[row][column + 1]);
            northeast.difference = Math.abs(grid[row][column] - grid[row - 1][column + 1]);
            southeast.difference = Math.abs(grid[row][column] - grid[row + 1][column + 1]);
            // Find the minimum difference
            int minDifference = Math.min(straight.difference, Math.min(northeast.difference, southeast.difference));

            // Choose the direction with the minimum difference
            if (minDifference == straight.difference) {
                column++;
                pathPointsList.add(straight);
            } else if (minDifference == northeast.difference) {
                row--;
                column++;
                pathPointsList.add(northeast);
            } else {
                row++;
                column++;
                pathPointsList.add(southeast);
            }
        }
        return pathPointsList;
    }

    /**
     * Calculate the escape path from source towards East such that it has the lowest elevation change.
     *
     * @return the total change in elevation for the entire path
     */
    public int getLowestElevationEscapePathCost(List<Point> pathPointsList) {
        int totalChange = 0;

        // TODO: Your code goes here, use the output from the getLowestElevationEscapePath() method
        for (int i = 0; i < pathPointsList.size(); i++) {
            totalChange += pathPointsList.get(i).difference;
        }
        return totalChange;
    }


    /**
     * Draw the escape path from source towards East on top of the grayscale map such that it has the lowest elevation change.
     */
    public void drawLowestElevationEscapePath(Graphics g, List<Point> pathPointsList) {
        // TODO: Your code goes here, use the output from the getLowestElevationEscapePath() method
        for (Point point : pathPointsList) {
            g.setColor(Color.yellow);
            g.fillRect(point.y, point.x, 1, 1);
        }
    }
}

