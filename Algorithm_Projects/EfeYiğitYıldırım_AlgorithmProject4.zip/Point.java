import java.util.ArrayList;
import java.util.List;

public class Point implements Comparable<Point> {
    public int x;
    public int y;
    public int weight;
    public int difference;
    public double road;
    public boolean visited;
    public double height_imp;
    public Point from;
    public boolean if_exists;

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    public double getRoad() {
        return road;
    }

    public void setRoad(double road) {
        this.road = road;
    }

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    @Override
    public int compareTo(Point o) {
        return Double.compare(this.road,o.road);
    }


    // You can add additional variables and methods if necessary.
}