import java.util.ArrayList;
import java.lang.Math;
import java.util.Arrays;


public class Planner {

    public final Task[] taskArray ;
    public final Integer[] compatibility;
    public final Double[] maxWeight;
    public final ArrayList<Task> planDynamic;
    public final ArrayList<Task> planGreedy;
    public int location;
    public String max_Array_String = "";
    public String dynamic_String = "";

    public Planner(Task[] taskArray) {

        // Should be instantiated with an Task array
        // All the properties of this class should be initialized here

        this.taskArray = taskArray;
        this.compatibility = new Integer[taskArray.length];
        this.location = taskArray.length - 1;
        maxWeight = new Double[taskArray.length];
        this.planDynamic = new ArrayList<>();
        this.planGreedy = new ArrayList<>();
    }

    /**
     * @param index of the {@link Task}
     * @return Returns the index of the last compatible {@link Task},
     * returns -1 if there are no compatible {@link Task}s.
     */
    public int binarySearch(int index) {
        // YOUR CODE HERE
        int left = 0;
        int right = taskArray.length - 1;
        int ret_val = -1;
        while (left <= right){
            int middle = (left + right) / 2;
            Task middle_task = taskArray[middle];
            String[] split1 = taskArray[index].getStartTime().split(":");
            int compare1 = 0;
            if (split1[0].charAt(0) == '0'){
                compare1 += Integer.parseInt(String.valueOf(split1[0].charAt(1))) * 60;
            }
            else {
                compare1 += Integer.parseInt(split1[0]) * 60;
            }
            if (split1[1].charAt(0) == '0'){
                compare1 += Integer.parseInt(String.valueOf(split1[1].charAt(1)));
            }
            else {
                compare1 += Integer.parseInt(split1[1]);
            }
            String[] split2 = taskArray[middle].getFinishTime().split(":");
            int compare2 = 0;
            if (split2[0].charAt(0) == '0'){
                compare2 += Integer.parseInt(String.valueOf(split2[0].charAt(1))) * 60;
            }
            else {
                compare2 += Integer.parseInt(split2[0]) * 60;
            }
            if (split2[1].charAt(0) == '0'){
                compare2 += Integer.parseInt(String.valueOf(split2[1].charAt(1)));
            }
            else {
                compare2 += Integer.parseInt(split2[1]);
            }
            if (compare2 <= compare1){
                ret_val = middle;
                left = middle + 1;
            }
            else {
                right = middle - 1;
            }
        }
        if (ret_val != -1){
            return ret_val;
        }
        return -1;
    }


    /**
     * {@link #compatibility} must be filled after calling this method
     */
    public void calculateCompatibility() {
        // YOUR CODE HERE
        for (int i = 0; i < this.taskArray.length; i++){
            this.compatibility[i] = this.binarySearch(i);
        }
    }


    /**
     * Uses {@link #taskArray} property
     * This function is for generating a plan using the dynamic programming approach.
     * @return Returns a list of planned tasks.
     */
    public ArrayList<Task> planDynamic() {
        // YOUR CODE HERE
        this.calculateCompatibility();
        this.max_Array_String += "Calculating max array\n";
        this.max_Array_String += "---------------------\n";
        this.calculateMaxWeight(this.taskArray.length - 1);
        this.dynamic_String += "Calculating the dynamic solution\n";
        this.dynamic_String += "--------------------------------\n";
        solveDynamic(this.taskArray.length-1);
        return planDynamic;
    }

    /**
     * {@link #planDynamic} must be filled after calling this method
     */
    public void solveDynamic(int i) {
        // YOUR CODE HERE
        if (i == -1){
            return;
        }
        else {
            this.dynamic_String += "Called solveDynamic(" + i + ")\n";
            if (i == 0){
                this.planDynamic.add(taskArray[0]);
                return;
            }
            double compare1 = this.maxWeight[i];
            double compare2 = this.maxWeight[i-1];
            if (compare1 > compare2){
                solveDynamic(compatibility[i]);
                planDynamic.add(this.taskArray[i]);
            }
            else {
                solveDynamic(i-1);
            }
        }
    }

    /**
     * {@link #maxWeight} must be filled after calling this method
     */
    /* This function calculates maximum weights and prints out whether it has been called before or not  */
    public Double calculateMaxWeight(int i) {
        this.max_Array_String += "Called calculateMaxWeight(" + String.valueOf(i) + ")\n";
        if (i == -1){
            return 0.0;
        }
        else {
            if ((this.maxWeight[i] != null)){
                return maxWeight[i];
            }
            else {
                double compare1 = this.taskArray[i].getWeight() + calculateMaxWeight(this.compatibility[i]);
                double compare2 = this.calculateMaxWeight(i-1);
                this.maxWeight[i] = Math.max(compare2,compare1);
                return maxWeight[i];
            }
        }
    }

    /**
     * {@link #planGreedy} must be filled after calling this method
     * Uses {@link #taskArray} property
     *
     * @return Returns a list of scheduled assignments
     */

    /*
     * This function is for generating a plan using the greedy approach.
     * */
    public void sou(){
        String explanation_Dynamic_String = "";
        explanation_Dynamic_String += "Dynamic Schedule\n";
        explanation_Dynamic_String += "----------------\n";
        for (int i = 0; i < this.planDynamic.size(); i++){
            explanation_Dynamic_String += "At " + this.planDynamic.get(i).start + ", " + this.planDynamic.get(i).name + ".\n";
        }
        String explanation_Greedy_String = "";
        explanation_Greedy_String += "Greedy Schedule\n";
        explanation_Greedy_String += "---------------\n";
        for (int i = 0; i < this.planGreedy.size(); i++){
            explanation_Greedy_String += "At " + this.planGreedy.get(i).start + ", " + this.planGreedy.get(i).name + ".";
            if (i != this.planGreedy.size() - 1){
                explanation_Greedy_String += "\n";
            }
        }
        System.out.print(this.max_Array_String);
        System.out.println();
        System.out.print(this.dynamic_String);
        System.out.println();
        System.out.print(explanation_Dynamic_String);
        System.out.println();
        System.out.print(explanation_Greedy_String);
    }
    public ArrayList<Task> planGreedy() {
        // YOUR CODE HERE
        this.planGreedy.add(this.taskArray[0]);
        Task last = this.taskArray[0];
        for (int i = 1; i < this.taskArray.length; i++){
            if (last.isComp(this.taskArray[i])){
                this.planGreedy.add(this.taskArray[i]);
                last = this.taskArray[i];
            }
        }
        return planGreedy;
    }
}