import java.awt.*;
import java.time.LocalTime;

public class Task implements Comparable {
    public String name;
    public String start;
    public int duration;
    public int importance;
    public boolean urgent;

    /*
        Getter methods
     */
    public String getName() {
        return this.name;
    }

    public String getStartTime() {
        return this.start;
    }

    public int getDuration() {
        return this.duration;
    }

    public int getImportance() {
        return this.importance;
    }

    public boolean isUrgent() {
        return this.urgent;
    }

    /**
     * Finish time should be calculated here
     *
     * @return calculated finish time as String
     */
    public String getFinishTime() {
        // YOUR CODE HERE
        String split = this.start.split(":")[0];
        if (split.charAt(0) == '0'){
            int temp = Integer.parseInt(String.valueOf(split.charAt(1)));
            temp += this.duration;
            if (temp <= 9){
                String string1 = "0" + String.valueOf(temp);
                return string1 + ":" + this.start.split(":")[1];
            }
            else {
                String string1 = String.valueOf(temp);
                return string1 + ":" + this.start.split(":")[1];
            }
        }
        else if (split.charAt(0) != '0'){
             int temp = Integer.parseInt(split);
             temp += this.duration;
             return String.valueOf(temp) + ":" + this.start.split(":")[1];
        }
        return "";
    }

    /**
     * Weight calculation should be performed here
     *
     * @return calculated weight
     */

    public boolean isComp(Task task){
        String[] split_finish = this.getFinishTime().split(":");
        LocalTime finish_time = LocalTime.of(Integer.parseInt(split_finish[0]),Integer.parseInt(split_finish[1]));
        String[] split_start_Task = task.start.split(":");
        LocalTime start_time_task = LocalTime.of(Integer.parseInt(split_start_Task[0]),Integer.parseInt(split_start_Task[1]));
        if (finish_time.compareTo(start_time_task) > 0){
            return false;
        }
        else {
            return true;
        }
    }


    public double getWeight() {
        // YOUR CODE HERE
        double check = 0;
        if (this.urgent){
            check = 2000.0;
        }
        else {
            check = 1.0;
        }
        double temp_importance = this.importance;
        double temp_duration = this.duration;
        return (temp_importance * check) / temp_duration;
    }

    /**
     * This method is needed to use {@link java.util.Arrays#sort(Object[])} ()}, which sorts the given array easily
     *
     * @param o Object to compare to
     * @return If self > object, return > 0 (e.g. 1)
     * If self == object, return 0
     * If self < object, return < 0 (e.g. -1)
     */
    @Override
    public int compareTo(Object o) {
        // YOUR CODE HERE
        Task other_task = (Task) o;
        String[] split1 = this.getFinishTime().split(":");
        int compare1 = 0;
        if (split1[0].charAt(0) == '0'){
            compare1 += Integer.parseInt(String.valueOf(split1[0].charAt(1))) * 60;
        }
        else {
            compare1 += Integer.parseInt(split1[0]) * 60;
        }
        if (split1[1].charAt(0) == '0'){
            compare1 += Integer.parseInt(String.valueOf(split1[1].charAt(1)));
        }
        else {
            compare1 += Integer.parseInt(split1[1]);
        }
        String[] split2 = other_task.getFinishTime().split(":");
        int compare2 = 0;
        if (split2[0].charAt(0) == '0'){
            compare2 += Integer.parseInt(String.valueOf(split2[0].charAt(1))) * 60;
        }
        else {
            compare2 += Integer.parseInt(split2[0]) * 60;
        }
        if (split2[1].charAt(0) == '0'){
            compare2 += Integer.parseInt(String.valueOf(split2[1].charAt(1)));
        }
        else {
            compare2 += Integer.parseInt(split2[1]);
        }
        if (compare1 > compare2) {
            return 1;
        } else if (compare1 == compare2) {
            return 0;
        }
        return -1;
    }
}
