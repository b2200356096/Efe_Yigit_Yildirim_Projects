import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Kingdom {

    // TODO: You should add appropriate instance variables.
    public int[][] graph;
    public void initializeKingdom(String filename){
        // Read the txt file and fill your instance variables
        // TODO: Your code here
        try {
            File file = new File(filename);
            Scanner myReader = new Scanner(file);
            int boy = 0;
            int en  = 0;
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] elements = data.split(" ");
                en = elements.length;
                boy++;
            }
            myReader.close();
            graph = new int[boy][en];
            int check = 0;
            Scanner myReader1 = new Scanner(file);
            while (myReader1.hasNextLine()){
                String data = myReader1.nextLine();
                String[] elements = data.split(" ");
                for (int i = 0; i < en;i++){
                    this.graph[check][i] = Integer.parseInt(elements[i]);
                }
                check++;
            }
            myReader1.close();
        }
        catch (IOException e){
            int a = 5;
        }
    }

    public List<Colony> getColonies() {
        List<Colony> colonies = new ArrayList<>();
        // TODO: DON'T READ THE .TXT FILE HERE!
        // Identify the colonies using the given input file.
        // TODO: Your code here
        int n = graph.length; // number of vertices
        boolean[] visited = new boolean[n]; // to keep track of visited vertices
        for (int i = 1; i <= n; i++) {  // start with vertex 1 instead of 0
            if (!visited[i - 1]) {
                List<Integer> colony_list = new ArrayList<>();
                dfs(graph, visited, i - 1, colony_list);
                Colony colony1 = new Colony();
                colony1.cities = colony_list;
                colonies.add(colony1);
            }
        }
        for (Colony colony : colonies){
            for (int city : colony.cities){
                List<Integer> roads = new ArrayList<>();
                for (int i = 0; i < graph[city-1].length;i++){
                    if (graph[city-1][i] != 0){
                        roads.add(i+1);
                    }
                }
                colony.roadNetwork.put(city,roads);
            }
        }
        return colonies;
    }

    public void dfs(int[][] graph, boolean[] visited, int vertex, List<Integer> colony) {
        visited[vertex] = true;
        colony.add(vertex + 1);  // add 1 to get the vertex name
        for (int i = 0; i < graph.length; i++) {
            if (graph[vertex][i] != 0 && !visited[i]) {
                dfs(graph,visited,i,colony);
            }
            if (graph[i][vertex] != 0 && !visited[i]) {
                dfs(graph,visited,i,colony);
            }
        }
    }

    public void printColonies(List<Colony> discoveredColonies) {
        // Print the given list of discovered colonies conforming to the given output format.
        // TODO: Your code here
        System.out.println("Discovered colonies are:");
        int check = 1;
        for (Colony colony : discoveredColonies) {
            List<Integer> cities1 = new ArrayList<>();
            for (int i : colony.cities){
                cities1.add(i);
            }
            Collections.sort(cities1);
            System.out.print("Colony " + check + ": ");
            System.out.println(cities1);
            check++;
        }
    }
}