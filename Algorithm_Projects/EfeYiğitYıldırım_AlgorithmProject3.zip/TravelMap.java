import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.*;

public class TravelMap {

    // Maps a single Id to a single Location.
    public Map<Integer, Location> locationMap = new HashMap<>();

    // List of locations, read in the given order
    public List<Location> locations = new ArrayList<>();

    // List of trails, read in the given order
    public List<Trail> trails = new ArrayList<>();

    // TODO: You are free to add more variables if necessary.


    public void initializeMap(String filename) {
        // Read the XML file and fill the instance variables locationMap, locations and trails.
        // TODO: Your code here
        try {
            File inputFile = new File(filename);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("Location");
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    String name = element.getElementsByTagName("Name").item(0).getTextContent();
                    int id = Integer.parseInt(element.getElementsByTagName("Id").item(0).getTextContent());
                    Location location = new Location(name,id);
                    locations.add(location);
                    locationMap.put(id,location);
                }
            }

            NodeList nodeList2 = doc.getElementsByTagName("Trail");
            for (int i = 0; i < nodeList2.getLength(); i++) {
                Node node = nodeList2.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    int source = Integer.parseInt(element.getElementsByTagName("Source").item(0).getTextContent());
                    int destination = Integer.parseInt(element.getElementsByTagName("Destination").item(0).getTextContent());
                    int danger = Integer.parseInt(element.getElementsByTagName("Danger").item(0).getTextContent());
                    Trail trail = new Trail(
                            locationMap.get(source),locationMap.get(destination), danger
                    );
                    trails.add(trail);
                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }

    public List<Trail> getSafestTrails() {
        List<Trail> safestTrails = new ArrayList<>();
        // Fill the safestTrail list and return it.
        // Select the optimal Trails from the Trail list that you have read.
        // TODO: Your code here
        List<Trail> mst = new ArrayList<>(); // minimum spanning tree
        boolean[] visited = new boolean[locations.size()]; // keep track of included vertices
        PriorityQueue<Trail> pq = new PriorityQueue<>(Comparator.comparingInt(e -> e.getDanger())); // priority queue of edges

        visited[0] = true;
        for (Trail e : trails) {
            if (e.getSource().getId() == 0 || e.getDestination().getId() == 0) {
                pq.offer(e);
            }
        }
        while (!pq.isEmpty() && mst.size() < locations.size() - 1) {
            Trail e = pq.poll();

            if (visited[e.getSource().getId()] && visited[e.getDestination().getId()]) {
                continue;
            }

            mst.add(e);

            int nextVertex = visited[e.getSource().getId()] ? e.getDestination().getId() : e.getSource().getId();
            visited[nextVertex] = true;

            for (Trail edge : trails) {
                if (!visited[edge.getSource().getId()] || !visited[edge.getDestination().getId()]) {
                    if (edge.getSource().getId() == nextVertex || edge.getDestination().getId() == nextVertex) {
                        pq.offer(edge);
                    }
                }
            }
        }
        safestTrails = mst;
        return safestTrails;
    }

    public void printSafestTrails(List<Trail> safestTrails) {
        // Print the given list of safest trails conforming to the given output format.
        // TODO: Your code here
        System.out.println("Safest trails are:");
        int total = 0;
        for (Trail trail : safestTrails){
            total += trail.getDanger();
            System.out.println("The trail from " + trail.getSource().getName() + " to " + trail.getDestination().getName()
                    + " with danger " + trail.getDanger());
        }
        System.out.print("Total danger: " + total);
    }
}
