#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct node_flat {
    int is_empty = 0;
    string id;
    int  bandwidth_value;
    struct node_flat *next = nullptr;
    struct node_flat *prev = nullptr;
};typedef struct node_flat* nodeflatptr;

nodeflatptr getFnode(){
    nodeflatptr p;
    p = new node_flat;
    return p;
}

void freeFnode(nodeflatptr p ){
    delete p;
}

struct node {
    int  bandwidth_value;
    string name;
    struct node *next;
    struct node_flat *flat_linked_list = nullptr;
};typedef struct node* nodeptr;

nodeptr getnode(){
    nodeptr p;
    p = new node;
    return p;
}

int sum_bandwidth(nodeptr head,nodeptr last){
    if (head == nullptr){
        return 0;
    }
    else {
        nodeptr i = head;
        if (head->name == last->name){
            return head->bandwidth_value;
        }
        else {
            int sum = 0;
            for(;i->name != last->name; i = i->next){
                sum += i->bandwidth_value;
            }
            sum += i->bandwidth_value;
            return sum;
        }
    }
}

void make_flat_empty(nodeptr *head,string first,string second){
    nodeptr temp = *head;
    for (;temp->name != first;temp = temp->next){
    }
    nodeflatptr temp2 = temp->flat_linked_list;
    for (;temp2->id != second;temp2 = temp2->next){
    }
    temp2->is_empty = 1;
}

nodeptr freenode(nodeptr head,nodeptr last,nodeptr p){
    if (head->name == last->name){
        freeFnode(head->flat_linked_list);
        head = nullptr;
        delete p;
    }
    else if (head->name == p->name){
        freeFnode(head->flat_linked_list);
        head = head->next;
        delete p;
    }
    else if (last->name == p->name){
        nodeptr i = head;
        for (;i->next->name != last->name;i = i->next){
        }
        freeFnode(i->next->flat_linked_list);
        i->next = head;
        delete p;
    }
    else {
        nodeptr i = head;
        for (;i->next->name != p->name; i = i->next){
        }
        freeFnode(i->next->flat_linked_list);
        nodeptr te = i->next->next;
        i->next = te;
        delete p;
    }
    return head;
}

void add_apartment(nodeptr &head,nodeptr &last,string t1,string t2,string t3){
    string first;string second;string word2;
    for (auto y : t2){
        if (y == '_'){
            first = word2;
            word2 = "";
        }
        else {
            word2 += y;
        }
        second = word2;
    }
    if (head->name == last->name){
        if (first == "after"){
            nodeptr nodeptr1 = getnode();
            nodeptr1 -> name = t1;
            nodeptr1 -> bandwidth_value = stoi(t3);
            last = nodeptr1;
            last -> next = head;
            head -> next = nodeptr1;
        }
        else if (first == "before"){
            nodeptr nodeptr1 = getnode();
            nodeptr1 -> name = t1;
            nodeptr1 -> bandwidth_value = stoi(t3);
            nodeptr1->next = head;
            head = nodeptr1;
            last->next = head;
        }
    }
    else {
        if (first == "before"){
            if (second != head->name){
                nodeptr temp1 = head;
                for (;temp1->next->name != second;temp1 = temp1->next){
                }
                nodeptr nodeptr1 = getnode();
                nodeptr1->name = t1;
                nodeptr1->bandwidth_value = stoi(t3);
                nodeptr nodeptr2 = temp1->next;
                nodeptr1->next = nodeptr2;
                temp1->next = nodeptr1;
            }
            else {
                nodeptr nodeptr2 = getnode();
                nodeptr2->name = t1;
                nodeptr2->bandwidth_value = stoi(t3);
                nodeptr2->next = head;
                head = nodeptr2;
                last->next = head;
            }
        }
        else if (first == "after"){
            if (second == last->name){
                nodeptr temp1 = head;
                for (;temp1->name != second;temp1 = temp1->next){
                }
                nodeptr nodeptr1 = getnode();
                nodeptr1->name = t1;
                nodeptr1->bandwidth_value = stoi(t3);
                nodeptr1->next = head;
                temp1->next = nodeptr1;
                last = nodeptr1;
            }
            else {
                nodeptr temp1 = head;
                for (;temp1->name != second;temp1 = temp1->next){
                }
                nodeptr nodeptr1 = getnode();
                nodeptr1->name = t1;
                nodeptr1->bandwidth_value = stoi(t3);
                nodeptr nodeptr2 = temp1->next;
                nodeptr1->next = nodeptr2;
                temp1->next = nodeptr1;
            }
        }
    }
}

void add_flat(nodeptr *head,string t1,string t2,string t3,string t4){
    nodeptr temp = *head;
    for (;temp->name != t1;temp = temp->next){
    }
    if (temp->flat_linked_list == nullptr){
        nodeflatptr nodeflatptr1 = getFnode();
        if (stoi(t3) >= temp->bandwidth_value){
            nodeflatptr1->bandwidth_value = temp->bandwidth_value;
        } else{
            nodeflatptr1->bandwidth_value = stoi(t3);
        }
        nodeflatptr1->id = t4;
        temp->flat_linked_list = nodeflatptr1;
    }
    else {
        int index = stoi(t2);
        int count_b = 0;
        nodeflatptr j = temp->flat_linked_list;
        for (;j->next != nullptr;j = j->next){
            count_b += j->bandwidth_value;
        }
        count_b += j->bandwidth_value;
        nodeflatptr i = temp->flat_linked_list;
        if (index == 0){
            nodeflatptr nodeflatptr1 = getFnode();
            if (stoi(t3) >= (temp->bandwidth_value - count_b)){
                nodeflatptr1->bandwidth_value = temp->bandwidth_value - count_b;
            } else{
                nodeflatptr1->bandwidth_value = stoi(t3);
            }
            nodeflatptr1->id = t4;
            i->prev = nodeflatptr1;
            nodeflatptr1->next = i;
            temp->flat_linked_list = nodeflatptr1;
        }
        else {
            if (i->next == nullptr){
                nodeflatptr nodeflatptr1 = getFnode();
                if (stoi(t3) >= (temp->bandwidth_value - count_b)){
                    nodeflatptr1->bandwidth_value = temp->bandwidth_value - count_b;
                } else{
                    nodeflatptr1->bandwidth_value = stoi(t3);
                }
                nodeflatptr1->id = t4;
                nodeflatptr1->prev = i;
                i->next = nodeflatptr1;
            }
            else {
                for (int count = 0;count < index - 1;count++){
                    i = i->next;
                }
                nodeflatptr nodeflatptr1 = getFnode();
                if (stoi(t3) >= (temp->bandwidth_value - count_b)){
                    nodeflatptr1->bandwidth_value = temp->bandwidth_value - count_b;
                } else{
                    nodeflatptr1->bandwidth_value = stoi(t3);
                }
                nodeflatptr1->id = t4;
                if (i->next != nullptr){
                    nodeflatptr nodeflatptr2 = i->next;
                    nodeflatptr1->prev = i;
                    nodeflatptr2->prev = nodeflatptr1;
                    nodeflatptr1->next = nodeflatptr2;
                    i->next = nodeflatptr1;
                }
                else {
                    nodeflatptr1->prev = i;
                    i->next = nodeflatptr1;
                }
            }
        }
    }
}

nodeptr merge_apartments(nodeptr &head,nodeptr &last,string t1,string t2){
    nodeptr t = head;
    nodeptr f = head;
    for (;t->name != last->name; t = t->next){
        if (t->name == t1){
            break;
        }
    }
    for (;f->name != last->name; f = f->next){
        if (f->name == t2){
            break;
        }
    }
    if (head->next->name == last->name){
        if ((t->name == head->name) && (f->name == last->name)){
            nodeflatptr nodeflatptr1 = f->flat_linked_list;
            nodeflatptr nodeflatptr2 = t->flat_linked_list;
            for (;nodeflatptr2->next != nullptr; nodeflatptr2 = nodeflatptr2->next){
            }
            nodeflatptr1->prev = nodeflatptr2;
            nodeflatptr2->next = nodeflatptr1;
            f->flat_linked_list = nullptr;
            t->bandwidth_value += f->bandwidth_value;
            last = last->next;
            last->next = head;
        }
        else if ((t->name == last->name) && (f->name == head->name)){
            nodeflatptr nodeflatptr1 = f->flat_linked_list;
            nodeflatptr nodeflatptr2 = t->flat_linked_list;
            for (;nodeflatptr2->next != nullptr; nodeflatptr2 = nodeflatptr2->next){
            }
            nodeflatptr1->prev = nodeflatptr2;
            nodeflatptr2->next = nodeflatptr1;
            f->flat_linked_list = nullptr;
            t->bandwidth_value += f->bandwidth_value;
            head = head->next;
            last->next = head;
        }
    }
    else {
        if (f->name == head->name){
            if ((f->flat_linked_list == nullptr) && (t->flat_linked_list == nullptr)){
                t->bandwidth_value += f->bandwidth_value;
                head = head->next;
                last->next = head;
            }
            else if (f->flat_linked_list == nullptr){
                t->bandwidth_value += f->bandwidth_value;
                head = head->next;
                last->next = head;
            }
            else if (t->flat_linked_list == nullptr){
                t->flat_linked_list = f->flat_linked_list;
                t->bandwidth_value += f->bandwidth_value;
                head = head->next;
                last->next = head;
            }
            else {
                nodeflatptr nodeflatptr1 = f->flat_linked_list;
                nodeflatptr nodeflatptr2 = t->flat_linked_list;
                for (;nodeflatptr2->next != nullptr; nodeflatptr2 = nodeflatptr2->next){
                }
                nodeflatptr1->prev = nodeflatptr2;
                nodeflatptr2->next = nodeflatptr1;
                f->flat_linked_list = nullptr;
                t->bandwidth_value += f->bandwidth_value;
                head = head->next;
                last->next = head;
            }
        }
        else if (f->name == last->name){
            nodeptr bef = head;
            for (;bef->next->name != last->name; bef = bef->next){
            }
            if ((f->flat_linked_list == nullptr) && (t->flat_linked_list == nullptr)){
                t->bandwidth_value += f->bandwidth_value;
                bef->next = head;
                last = bef;
            }
            else if(f->flat_linked_list == nullptr){
                t->bandwidth_value += f->bandwidth_value;
                bef->next = head;
                last = bef;
            }
            else if (t->flat_linked_list == nullptr){
                t->flat_linked_list = f->flat_linked_list;
                t->bandwidth_value += f->bandwidth_value;
                bef->next = head;
                last = bef;
            }
            else {
                nodeflatptr nodeflatptr1 = f->flat_linked_list;
                nodeflatptr nodeflatptr2 = t->flat_linked_list;
                for (;nodeflatptr2->next != nullptr; nodeflatptr2 = nodeflatptr2->next){
                }
                nodeflatptr1->prev = nodeflatptr2;
                nodeflatptr2->next = nodeflatptr1;
                f->flat_linked_list = nullptr;
                t->bandwidth_value += f->bandwidth_value;
                bef->next = head;
                last = bef;
            }
        }
        else {
            nodeptr s = head;
            nodeptr d = head;
            for (;s->name != last->name; s = s->next){
                if (s->next->name == t1){
                    break;
                }
            }
            for (;d->name != last->name; d = d->next){
                if (d->next->name == t2){
                    break;
                }
            }
            if ((s->next->flat_linked_list == nullptr) && (d->next->flat_linked_list == nullptr)){
                s->next->bandwidth_value += d->next->bandwidth_value;
                d->next = d->next->next;
            }
            else if (s->next->flat_linked_list == nullptr){
                s->next->bandwidth_value += d->next->bandwidth_value;
                s->next->flat_linked_list = d->next->flat_linked_list;
                d->next = d->next->next;
            }
            else if (d->next->flat_linked_list == nullptr){
                s->next->bandwidth_value += d->next->bandwidth_value;
                d->next = d->next->next;
            }
            else {
                nodeflatptr nodeflatptr1 = d->next->flat_linked_list;
                nodeflatptr nodeflatptr2 = s->next->flat_linked_list;
                for (;nodeflatptr2->next != nullptr; nodeflatptr2 = nodeflatptr2->next){
                }
                nodeflatptr1->prev = nodeflatptr2;
                nodeflatptr2->next = nodeflatptr1;
                s->next->bandwidth_value += d->next->bandwidth_value;
                d->next = d->next->next;
            }
        }
    }
    return head;
}

int main(int argc,char** argv) {
    string line;
    ifstream readFile(argv[1]);
    //R"(C:\Users\EYY\Desktop\assignment2\input2.txt)"
    ofstream output_file;
    output_file.open(argv[2]);
    //R"(C:\Users\EYY\Desktop\assignment2\output.txt)"
    int null_check = 0;
    nodeptr head = nullptr;
    nodeptr last = nullptr;
    while(getline(readFile,line)){
        if (line[line.size()-1] == '\r' || line[line.size()-1] == '\n'){
            line.pop_back();
        }
        int count = 0;
        string temp_list[5];
        string word;
        for (auto x : line){
            if (x == '\t'){
                temp_list[count] = word;
                word = "";
                count++;
            }
            else {
                word += x;
            }
        }
        temp_list[count] = word;
        count++;
        if (temp_list[0] == "add_apartment"){
            if (temp_list[2] == "head"){
                head = getnode();
                last = getnode();
                head->bandwidth_value = stoi(temp_list[3]);
                head->name = temp_list[1];
                last->bandwidth_value = stoi(temp_list[3]);
                last->name = temp_list[1];
                last->next = head;
            }
            else {
                add_apartment(head,last,temp_list[1],temp_list[2],temp_list[3]);
            }
        }
        else if(temp_list[0] == "add_flat"){
            add_flat(&head,temp_list[1],temp_list[2],temp_list[3],temp_list[4]);
        }
        else if (temp_list[0] == "remove_apartment"){
            nodeptr t = head;
            for (;t->name != temp_list[1];t = t->next){
            }
            if (head->name == last->name){
                head = freenode(head,last,t);
                last = nullptr;
            }
            else if (head->name == temp_list[1]) {
                head = freenode(head,last,t);
                last->next = head;
            }
            else if (last->name == temp_list[1]){
                head = freenode(head,last,t);
                nodeptr p = head;
                for (;p->next->name != head->name; p = p->next){
                }
                last = p;
            }
            else {
                head = freenode(head,last,t);
            }
        }
        else if (temp_list[0] == "make_flat_empty"){
            make_flat_empty(&head,temp_list[1],temp_list[2]);
        }
        else if (temp_list[0] == "find_sum_of_max_bandwidths"){
            int sum = sum_bandwidth(head,last);
            output_file << endl << "sum of bandwidth:" << to_string(sum) << endl << endl;
        }
        else if (temp_list[0] == "merge_two_apartments"){
            head = merge_apartments(head,last,temp_list[1],temp_list[2]);
        }
        else if (temp_list[0] == "list_apartments"){
            if (head != nullptr){
                nodeptr t = head;
                for(;t->name != last->name; t = t->next){
                    string apartment = t->name + "(" + to_string(t->bandwidth_value) + ")\t";
                    output_file << apartment;
                    if (t->flat_linked_list != nullptr){
                        for (nodeflatptr l = t->flat_linked_list; l != nullptr;l = l->next){
                            string flat = "Flat" + l->id + "(" + to_string(l->bandwidth_value) + ")\t";
                            output_file << flat;
                        }
                    }
                    output_file << endl;
                }
                string apartment = t->name + "(" + to_string(t->bandwidth_value) + ")\t";
                output_file << apartment;
                if (t->flat_linked_list != nullptr){
                    for (nodeflatptr l = t->flat_linked_list; l != nullptr;l = l->next){
                        string flat = "Flat" + l->id + "(" + to_string(l->bandwidth_value) + ")\t";
                        output_file << flat;
                    }
                }
                output_file << endl;
            }
        }
    }
    output_file.close();
    readFile.close();
    return 0;
}

