#include <iostream>
#include <fstream>
#include <string>
using namespace std;

string avl_writer = "";
string rb_writer = "";

//this is my struct for red-black tree nodes
struct rb_node{
    int price;
    string name;
    string color;
    rb_node* left;
    rb_node* right;
};

//this is my struct for avl tree nodes
struct avl_node{
    int price;
    string name;
    avl_node *left;
    avl_node *right;
};

//this is my struct for primary nodes that is used at the first base of our tree
struct primary{
    string name;
    avl_node* link;
    rb_node* rb_link;
    primary* left;
    primary* right;
};

// I use this function for adding nodes to the first base of the tree
primary* addPrimary(primary* primary2, primary* new_one){
    if (primary2 == nullptr){
        return new_one;
    }
    else if (string(new_one->name) < string(primary2->name)){
        primary2->left = addPrimary(primary2->left,new_one);
    }
    else if (string(new_one->name) > string(primary2->name)){
        primary2->right = addPrimary(primary2->right,new_one);
    }
    return primary2;
}

//with that function I access the height of our avl tree;
int getHeight(avl_node *avlNode){
    if (avlNode == nullptr){
        return 0;
    }
    else {
        int maximum_height;
        if (getHeight(avlNode->left) > getHeight(avlNode->right)){
            maximum_height = getHeight(avlNode->left);
        }
        else {
            maximum_height = getHeight(avlNode->right);
        }
        return maximum_height + 1;
    }
}

//with that function I access the height of our red-black tree;
int getHeightRb(rb_node *rbNode1){
    if (rbNode1 == nullptr){
        return 0;
    }
    else {
        int maximum_height;
        if (getHeightRb(rbNode1->left) > getHeightRb(rbNode1->right)){
            maximum_height = getHeightRb(rbNode1->left);
        }
        else {
            maximum_height = getHeightRb(rbNode1->right);
        }
        return maximum_height + 1;
    }
}

//with that function I access the height of our primary tree;
int getHeight_p(primary* primary){
    if (primary == nullptr){
        return 0;
    }
    else {
        int maximum_height;
        if (getHeight_p(primary->left) > getHeight_p(primary->right)){
            maximum_height = getHeight_p(primary->left);
        }
        else {
            maximum_height = getHeight_p(primary->right);
        }
        return maximum_height + 1;
    }
}

int balance_factor_difference(avl_node *avlNode) {
    return getHeight(avlNode->left) - getHeight(avlNode->right);
}

//with that function I rotate our avl tree to left
avl_node* right_right(avl_node *avlNode){
    avl_node *temp;
    temp = avlNode->right;
    avlNode->right = temp->left;
    temp->left = avlNode;
    avlNode = temp;
    return avlNode;
}

//with that function I rotate our avl tree to right
avl_node* left_left(avl_node *avlNode){
    avl_node *temp;
    temp = avlNode->left;
    avlNode->left = temp->right;
    temp->right = avlNode;
    avlNode = temp;
    return avlNode;
}

//with that function I rotate our avl tree first to left then to right
avl_node* left_right(avl_node *avlNode){
    avl_node *temp;
    temp = avlNode->left;
    temp = right_right(temp);
    avlNode->left = temp;
    avlNode = left_left(avlNode);
    return avlNode;
}

//with that function I rotate our avl tree first to right then to left
avl_node* right_left(avl_node *avlNode){
    avl_node *temp;
    temp = avlNode->right;
    temp = left_left(temp);
    avlNode->right = temp;
    avlNode = right_right(avlNode);
    return avlNode;
}

//In that function I rebalance our avl tree
avl_node* balance(avl_node *avlNode){
    int balance_factor = balance_factor_difference(avlNode);
    if (balance_factor > 1){
        if (balance_factor_difference(avlNode->left) > 0){
            avlNode = left_left(avlNode);
        }
        else {
            avlNode = left_right(avlNode);
        }
    }
    else if (balance_factor < -1){
        if (balance_factor_difference(avlNode->right) < 0){
            avlNode = right_right(avlNode);
        }
        else {
            avlNode = right_left(avlNode);
        }
    }
    return avlNode;
}

//Thanks to that function I rebalance our red-black tree after insertion
//I don't use it after deletion because I couldn't have done deletion part in red-black tree
rb_node* balance_rb(rb_node* rbNode1){
    if (rbNode1->right != nullptr){
        if (rbNode1->right->color == "red"){
            rb_node* temp;
            temp = rbNode1->right;
            rbNode1->right = temp->left;
            temp->left = rbNode1;
            string color_temp = temp->color;
            string color_rb = rbNode1->color;
            rbNode1 = temp;
            rbNode1->color = color_rb;
            rbNode1->left->color = "red";
            return rbNode1;
        }
    }
    if ((rbNode1->left != nullptr) && (rbNode1->left->left != nullptr)){
        if ((rbNode1->left->color == "red") && (rbNode1->left->left->color == "red")){
            rb_node* temp;
            temp = rbNode1->left;
            rbNode1->left = temp->right;
            temp->right = rbNode1;
            rbNode1 = temp;
            rbNode1->left->color = "black";
            rbNode1->right->color = "black";
            rbNode1->color = "red";
        }
    }
    if ((rbNode1->left != nullptr) && (rbNode1->right != nullptr)){
        if ((rbNode1->left->color == "red") && (rbNode1->right->color) == "red"){
            rbNode1->color = "red";
            rbNode1->left->color = "black";
            rbNode1->right->color = "black";
        }
    }
    return rbNode1;
}

//In that function I add my nodes recursively and rebalance the red-black tree
rb_node* addRbNode(rb_node* rbNode1,rb_node* new_rb){
    if (rbNode1 == nullptr){
        return new_rb;
    }
    else if (string(new_rb->name) < rbNode1->name){
        rbNode1->left = addRbNode(rbNode1->left,new_rb);
        rbNode1->left = balance_rb(rbNode1->left);
    }
    else if (string(new_rb->name) > rbNode1->name){
        rbNode1->right = addRbNode(rbNode1->right,new_rb);
        rbNode1->right = balance_rb(rbNode1->right);
    }
    rbNode1 = balance_rb(rbNode1);
    return rbNode1;
}

//In that function I add my nodes recursively and rebalance the avl tree
avl_node* addNode(avl_node *root, avl_node *new_one){
    if (root == nullptr){
        return new_one;
    }
    else if (string(new_one->name) < root->name){
        root->left = addNode(root->left,new_one);
        root->left = balance(root->left);
    }
    else if (string(new_one->name) > root->name){
        root->right = addNode(root->right,new_one);
        root->right = balance(root->right);
    }
    root = balance(root);
    return root;
}

//In the next 6 functions with the name "print" I write all nodes in them with calling them recursively
void print_avl_level(avl_node *avlNode, int level){
    if (avlNode == nullptr){
        return;
    }
    if (level == 0){
        avl_writer += '"'+ avlNode->name + '"' + ":" + '"' +  to_string(avlNode->price) + '"' + ",";
    }
    else if (level > 0){
        print_avl_level(avlNode->left,level-1);
        print_avl_level(avlNode->right,level-1);
    }
}

void print_all_avl_level(primary* primary_node){
    int height = getHeight(primary_node->link);
    if (height == 0){
        avl_writer += "{}\n";
    }
    else {
        avl_node *avl = primary_node->link;
        avl_writer += "\n";
        for (int i = 0; i < height;i++){
            avl_writer += "\t";
            print_avl_level(avl,i);
            avl_writer.pop_back();
            avl_writer += "\n";
        }
    }
}

void print_rb_level(rb_node* rbNode1,int level){
    if (rbNode1 == nullptr){
        return;
    }
    if (level == 0){
        rb_writer += '"'+ rbNode1->name + '"' + ":" + '"' +  to_string(rbNode1->price) + '"' + ",";
    }
    else if (level > 0){
        print_rb_level(rbNode1->left,level-1);
        print_rb_level(rbNode1->right,level-1);
    }
}


void print_all_rb_level(primary* primary_node){
    int height = getHeightRb(primary_node->rb_link);
    if (height == 0){
        rb_writer += "{}\n";
    }
    else {
        rb_node *rb = primary_node->rb_link;
        rb_writer += "\n";
        for (int i = 0; i < height;i++){
            rb_writer += "\t";
            print_rb_level(rb,i);
            rb_writer.pop_back();
            rb_writer += "\n";
        }
    }
}


void print_primary_level(primary* primary2,int level){
    if (primary2 == nullptr){
        return;
    }
    if (level == 0){
        rb_writer += '"' + primary2->name +  '"' + ":";
        avl_writer +=  '"' + primary2->name +  '"' + ":";
        print_all_avl_level(primary2);
        print_all_rb_level(primary2);
    }
    else if (level > 0){
        print_primary_level(primary2->left,level-1);
        print_primary_level(primary2->right,level-1);
    }
}

void print_all_primary_level(primary* primary_node){
    int height = getHeight_p(primary_node);
    rb_writer += "command:printAllItems\n{\n";
    avl_writer += "command:printAllItems\n{\n";
    for (int i = 0; i < height;i++){
        print_primary_level(primary_node,i);
    }
    rb_writer += "}\n";
    avl_writer += "}\n";
}

avl_node* leftmost_of_right(avl_node *avlNode){
    avl_node *temp = avlNode;
    while (temp->left != nullptr){
        temp = temp->left;
    }
    return temp;
}

//In that function I make deletion operation for avl tree
avl_node* deleteNode(avl_node* avlNode,string key){
    if (avlNode == nullptr){
        return avlNode;
    }
    else if (string(key) < string(avlNode->name)) {
        avlNode->left = deleteNode(avlNode->left,key);
    }
    else if (string(key) > string(avlNode->name)){
        avlNode->right = deleteNode(avlNode->right,key);
    }
    else if (avlNode->name == key) {
        if ((avlNode->left == nullptr) && (avlNode->right == nullptr)){
            avlNode = nullptr;
        }
        else if ((avlNode->left == nullptr) || (avlNode->right == nullptr)){
            avl_node* temp = nullptr;
            if (avlNode->left == nullptr){
                temp = avlNode->right;
            }
            else if (avlNode->right == nullptr){
                temp = avlNode->left;
            }
            avlNode = temp;
        }
        else {
            avl_node *temp;
            temp = leftmost_of_right(avlNode->right);
            avlNode->name = temp->name;
            avlNode->price = temp->price;
            avlNode->right = deleteNode(avlNode->right,temp->name);
        }
    }
    if (avlNode == nullptr){
        return avlNode;
    }
    avlNode = balance(avlNode);
    return avlNode;
}

//In that function I search for the specified avl tree node if it exists
avl_node* search(avl_node *avlNode,string key){
    if (avlNode == nullptr){
        return nullptr;
    }
    else if (avlNode->name == key){
        return avlNode;
    }
    else if (string(avlNode->name) > string(key)){
        return search(avlNode->left,key);
    }
    else {
        return search(avlNode->right,key);
    }
}

//In that function I search for the specified red-black tree node if it exists
rb_node* search_rb(rb_node* rbNode1,string key){
    if (rbNode1 == nullptr){
        return nullptr;
    }
    else if (rbNode1->name == key){
        return rbNode1;
    }
    else if (string(rbNode1->name) > string(key)){
        return search_rb(rbNode1->left,key);
    }
    else {
        return search_rb(rbNode1->right,key);
    }
}

//In that function I search for the specified primary node if it exists
primary* search_primary(primary* primary_node,string key){
    if (primary_node == nullptr){
        return nullptr;
    }
    else if (primary_node->name == key){
        return primary_node;
    }
    else if (string(primary_node->name) > string(key)){
        return search_primary(primary_node->left,key);
    }
    else {
        return search_primary(primary_node->right,key);
    }
}

int main(int argc,char** argv) {
    string line;
    ifstream readFile(argv[1]);
    //R"(C:\Users\EYY\Desktop\assignment4\input1.txt)"
    string category_list[20];
    primary *primary1 = nullptr;
    ofstream output_file;
    ofstream output_file2;
    output_file.open(argv[2]);
    //R"(C:\Users\EYY\Desktop\assignment4\output1.txt)"
    output_file2.open(argv[3]);
    //R"(C:\Users\EYY\Desktop\assignment4\output2.txt)"
    int index = 0;
    //In that while operation I make operations according to the commands and call functions.
    while (getline(readFile,line)){
        int count = 0;
        string temp_list[5];
        string word;
        for (auto x : line){
            if (x == '\t'){
                temp_list[count] = word;
                word = "";
                count++;
            }
            else {
                word += x;
            }
        }
        temp_list[count] = word;
        count++;
        if (temp_list[0] == "insert"){
            int control = 0;
            for (int z = 0; z < 20; z++){
                if (temp_list[1] == category_list[z]){
                    control++;
                }
            }
            if (primary1 == nullptr){
                category_list[index] = temp_list[1];
                index++;
                primary1 = new primary;
                primary1->name = temp_list[1];
                primary1->link = nullptr;
                primary1->left = nullptr;
                primary1->right = nullptr;
                rb_node *temp_rb_node = new rb_node;
                temp_rb_node->left = nullptr;
                temp_rb_node->right = nullptr;
                temp_rb_node->name = temp_list[2];
                temp_rb_node->price = stoi(temp_list[3]);
                temp_rb_node->color = "black";
                primary1->rb_link = temp_rb_node;
                avl_node *temp_avl_node = new avl_node;
                temp_avl_node->left = nullptr;
                temp_avl_node->right = nullptr;
                temp_avl_node->price = stoi(temp_list[3]);
                temp_avl_node->name = temp_list[2];
                primary1->link = temp_avl_node;
            }
            else {
                if (control == 0){
                    category_list[index] = temp_list[1];
                    index++;
                    primary* temp = new primary;
                    temp->name = temp_list[1];
                    temp->link = nullptr;
                    temp->left = nullptr;
                    temp->right = nullptr;
                    rb_node *temp_rb_node = new rb_node;
                    temp_rb_node->left = nullptr;
                    temp_rb_node->right = nullptr;
                    temp_rb_node->name = temp_list[2];
                    temp_rb_node->price = stoi(temp_list[3]);
                    temp_rb_node->color = "black";
                    avl_node *temp_avl_node = new avl_node;
                    temp_avl_node->left = nullptr;
                    temp_avl_node->right = nullptr;
                    temp_avl_node->price = stoi(temp_list[3]);
                    temp_avl_node->name = temp_list[2];
                    temp->link = temp_avl_node;
                    temp->rb_link = temp_rb_node;
                    primary1 = addPrimary(primary1,temp);
                }
                else {
                    rb_node *temp_rb_node = new rb_node;
                    temp_rb_node->left = nullptr;
                    temp_rb_node->right = nullptr;
                    temp_rb_node->name = temp_list[2];
                    temp_rb_node->price = stoi(temp_list[3]);
                    temp_rb_node->color = "red";
                    avl_node *temp_avl_node = new avl_node;
                    temp_avl_node->left = nullptr;
                    temp_avl_node->right = nullptr;
                    temp_avl_node->price = stoi(temp_list[3]);
                    temp_avl_node->name = temp_list[2];
                    primary* temp_primary = search_primary(primary1,temp_list[1]);
                    if (temp_primary->link == nullptr){
                        temp_primary->link = temp_avl_node;
                    }
                    else {
                        temp_primary->link = addNode(temp_primary->link,temp_avl_node);
                    }
                    if (temp_primary->rb_link == nullptr){
                        temp_rb_node->color = "black";
                        temp_primary->rb_link = temp_rb_node;
                    }
                    else {
                        temp_primary->rb_link = addRbNode(temp_primary->rb_link,temp_rb_node);
                        temp_primary->rb_link->color = "black";
                    }
                }
            }
        }
        else if (temp_list[0] == "remove"){
            if (search_primary(primary1,temp_list[1])->link == nullptr){

            }
            else {
                search_primary(primary1,temp_list[1])->link =
                        deleteNode(search_primary(primary1,temp_list[1])->link,temp_list[2]);
            }
        }
        else if (temp_list[0] == "printAllItems"){
            print_all_primary_level(primary1);
        }
        else if (temp_list[0] == "printAllItemsInCategory"){
            primary* temp_primary = search_primary(primary1,temp_list[1]);
            rb_writer += "commandprintAllItemsInCategory\t" + temp_primary->name + "\n{\n" + '"' + temp_primary->name
                         + '"' + ":";
            avl_writer += "commandprintAllItemsInCategory\t" + temp_primary->name + "\n{\n" + '"' + temp_primary->name
                    + '"' + ":";
            print_all_avl_level(temp_primary);
            print_all_rb_level(temp_primary);
            rb_writer += "}\n";
            avl_writer += "}\n";
        }
        else if (temp_list[0] == "printItem"){
            primary* temp_primary = search_primary(primary1,temp_list[1]);
            avl_node *temp_avl = search(temp_primary->link,temp_list[2]);
            rb_node *temp_rb = search_rb(temp_primary->rb_link,temp_list[2]);
            if (temp_avl == nullptr){
                avl_writer += "command:printItem\t" + temp_list[1] + "\t" + temp_list[2] + "\n";
                avl_writer += "{}\n";
            }
            else {
                avl_writer += "command:printItem\t" + temp_primary->name + "\t" + temp_avl->name + "\n{\n" + '"' + temp_primary->name
                              + '"' + ":\n\t";
                avl_writer += '"' + temp_avl->name + '"' + ":" + '"' + to_string(temp_avl->price) + '"' + "\n";
                avl_writer += "}\n";
            }
            if (temp_rb == nullptr){
                rb_writer += "command:printItem\t" + temp_list[1] + "\t" + temp_list[2] + "\n";
                rb_writer += "{}\n";
            }
            else {
                rb_writer += "command:printItem\t" + temp_primary->name + "\t" + temp_rb->name + "\n{\n" + '"' + temp_primary->name
                              + '"' + ":\n\t";
                rb_writer += '"' + temp_rb->name + '"' + ":" + '"' + to_string(temp_rb->price) + '"' + "\n";
                rb_writer += "}\n";
            }
        }
        else if (temp_list[0] == "find"){
            primary* temp_primary = search_primary(primary1,temp_list[1]);
            avl_writer += "command:find\t" + temp_list[1] + "\t" + temp_list[2] + "\n";
            rb_writer += "command:find\t" + temp_list[1] + "\t" + temp_list[2] + "\n";
            if (temp_primary == nullptr){
                avl_writer += "{}\n";
                rb_writer += "{}\n";
            }
            else {
                avl_node* temp_avl = search(temp_primary->link,temp_list[2]);
                rb_node* temp_rb = search_rb(temp_primary->rb_link,temp_list[2]);
                if (temp_avl == nullptr){
                    avl_writer += "{}\n";
                }
                else {
                    avl_writer += "{\n";
                    avl_writer += '"' + temp_primary->name + '"' + ":" + "\n\t";
                    avl_writer += '"' + temp_avl->name + '"' + ":" + '"' + to_string(temp_avl->price) + '"' + "\n";
                    avl_writer += "}\n";
                }
                if (temp_rb == nullptr){
                    rb_writer += "{}\n";
                }
                else {
                    rb_writer += "{\n";
                    rb_writer += '"' + temp_primary->name + '"' + ":" + "\n\t";
                    rb_writer += '"' + temp_rb->name + '"' + ":" + '"' + to_string(temp_rb->price) + '"' + "\n";
                    rb_writer += "}\n";
                }
            }
        }
        else if (temp_list[0] == "updateData"){
            primary* temp_primary = search_primary(primary1,temp_list[1]);
            avl_node *temp_avl = search(temp_primary->link,temp_list[2]);
            rb_node* temp_rb = search_rb(temp_primary->rb_link,temp_list[2]);
            temp_avl->price = stoi(temp_list[3]);
            temp_rb->price = stoi(temp_list[3]);
        }
    }
    output_file2 << rb_writer;
    output_file << avl_writer;
    output_file2.close();
    output_file.close();
    return 0;
}
