#include <iostream>
#include <fstream>
#include <string>
using namespace std;


void treasure_finder(int *ptr_row,int *ptr_column,string **main_arr,string **key_arr, int key,int row,
                     int column,string control_array[],int *ptr_control,string output_name){
    //this is my recursive function for map operations
    ofstream output_file;
    output_file.open(output_name);

    int temp_row = *ptr_row - (key / 2);
    int temp_col = *ptr_column - (key / 2);
    int sum = 0;


    for (int i = 0; i < key;i++){
        for (int j = 0;j < key;j++){
            sum = sum + ((stoi(main_arr[temp_row + i][temp_col + j])) * stoi(key_arr[i][j]));
        }
    }
    while (sum < 0){
        sum += 5;
    }
    if (((sum + 5) % 5) == 0){
        string string_row = to_string(*ptr_row);
        string string_column = to_string(*ptr_column);
        string string_sum = to_string(sum);
        string temp = string_row + "," + string_column + ":" + string_sum;
        control_array[*ptr_control] = temp;
        *ptr_control = *ptr_control + 1;
        for (int k = 0; k < *ptr_control;k++){
            if (k == *ptr_control - 1){
                output_file << control_array[k];
            } else{
                output_file << control_array[k] << endl;
            }
        }
    }
    else if (((sum + 5) % 5) == 1){
        string string_row = to_string(*ptr_row);
        string string_column = to_string(*ptr_column);
        string string_sum = to_string(sum);
        string temp = string_row + "," + string_column + ":" + string_sum;
        control_array[*ptr_control] = temp;
        *ptr_control = *ptr_control + 1;
        output_file << *ptr_row << " " << *ptr_column << " "<< sum << endl;
        if ((*ptr_row - key) >= (key / 2)){
            *ptr_row = *ptr_row - key;
        }
        else {
            *ptr_row = *ptr_row + key;
        }
        treasure_finder(ptr_row,ptr_column,main_arr,key_arr,key,row,column,control_array,ptr_control,output_name);
    }
    else if (((sum + 5) % 5) == 2){
        string string_row = to_string(*ptr_row);
        string string_column = to_string(*ptr_column);
        string string_sum = to_string(sum);
        string temp = string_row + "," + string_column + ":" + string_sum;
        control_array[*ptr_control] = temp;
        *ptr_control = *ptr_control + 1;
        output_file << *ptr_row << " " << *ptr_column << " "<< sum << endl;
        if ((*ptr_row + key) <= (row - 1 - (key / 2))){
            *ptr_row = *ptr_row + key;
        }
        else{
            *ptr_row = *ptr_row - key;
        }
        treasure_finder(ptr_row,ptr_column,main_arr,key_arr,key,row,column,control_array,ptr_control,output_name);
    }
    else if (((sum + 5) % 5) == 3){
        string string_row = to_string(*ptr_row);
        string string_column = to_string(*ptr_column);
        string string_sum = to_string(sum);
        string temp = string_row + "," + string_column + ":" + string_sum;
        control_array[*ptr_control] = temp;
        *ptr_control = *ptr_control + 1;
        output_file << *ptr_row << " " << *ptr_column << " "<< sum << endl;
        if ((*ptr_column + key) <= (column - 1 - (key / 2))){
            *ptr_column = *ptr_column + key;
        }
        else{
            *ptr_column = *ptr_column - key;
        }
        treasure_finder(ptr_row,ptr_column,main_arr,key_arr,key,row,column,control_array,ptr_control,output_name);
    }
    else if (((sum + 5) % 5) == 4){
        string string_row = to_string(*ptr_row);
        string string_column = to_string(*ptr_column);
        string string_sum = to_string(sum);
        string temp = string_row + "," + string_column + ":" + string_sum;
        control_array[*ptr_control] = temp;
        *ptr_control = *ptr_control + 1;
        output_file << *ptr_row << " " << *ptr_column << " "<< sum << endl;
        if ((*ptr_column - key) >= (key / 2)){
            *ptr_column = *ptr_column - key;
        }
        else {
            *ptr_column = *ptr_column + key;
        }
        treasure_finder(ptr_row,ptr_column,main_arr,key_arr,key,row,column,control_array,ptr_control,output_name);
    }
    output_file.close();
}

int main(int argc,char** argv) {

    int row = 0;
    int column = 0;
    string efe = argv[1];
    int control_int = 0;
    string word_command = "";
    // I split the size command with this for loop
    for (auto l : efe){
        if ((control_int == 0) || (control_int == 1)){
            word_command = word_command + l;
            if (control_int == 1){
                row = stoi(word_command);
            }
            control_int++;
        }
        else if (control_int == 2){
            word_command = "";
            control_int++;
        }
        else if ((control_int == 3) || (control_int == 4)){
            word_command = word_command + l;
            if (control_int == 4){
                column = stoi(word_command);
            }
            control_int++;
        }
    }

    int key_value = stoi(argv[2]);

    // here I create my map and key pointers, my map and key arrays create my map with the while loops
    string string_list[row][column];
    string key_string_list[key_value][key_value];

    string **pString = new string *[row];
    for (int p = 0;p < row;p++){
        pString[p] = new string[column];
    }

    string **kString = new string *[key_value];
    for (int p = 0;p < key_value;p++){
        kString[p] = new string[key_value];
    }

    string line;
    ifstream readFile(argv[3]);
    int i = 0;
    while(getline(readFile,line)){
        int j = 0;
        string word = "";
        for (auto x : line){
            if (x == ' '){
                string_list[i][j] = word;
                pString[i][j] = word;
                word = "";
                j++;
            }
            else {
                word = word + x;
            }
        }
        if (j == (column - 1)){
            string_list[i][j] = "0";
            pString[i][j] = "0";
        }
        i++;
    }

    string key_line;
    ifstream read_key_file(argv[4]);
    int ki = 0;
    while (getline(read_key_file,key_line)){
        int ji = 0;
        string key_word = "";
        for (auto y : key_line){
            if (y == ' '){
                key_string_list[ki][ji] = key_word;
                kString[ki][ji] = key_word;
                key_word = "";
                ji++;
            }
            else {
                key_word = key_word + y;
                if ((ji == (key_value - 1)) && (y != '-')){
                    key_string_list[ki][ji] = key_word;
                    kString[ki][ji] = key_word;
                    key_word = "";
                    ji = 0;
                }
            }
        }
        ki++;
    }


    int position_row = (key_value / 2);
    int position_column = (key_value / 2);
    int output_control = 0;
    int *ptr_row = &position_row;
    int *ptr_column = &position_column;
    int *ptr_control = &output_control;

    string output_array[100];
    string output_location = argv[5];
    // after ı create my integer pointers ı start to do my operation with the recursive funciton
    treasure_finder(ptr_row,ptr_column,pString,kString,key_value,row,column,
                    output_array,ptr_control,output_location);

    // I use dynamic memory here and delete pointers
    for (int t = 0; t < row; t++){
        delete [] pString[t];
    }
    for (int p = 0; p < key_value; p++){
        delete [] kString[p];
    }
    delete [] kString;
    delete [] pString;


    readFile.close();
    read_key_file.close();


    return 0;
}
