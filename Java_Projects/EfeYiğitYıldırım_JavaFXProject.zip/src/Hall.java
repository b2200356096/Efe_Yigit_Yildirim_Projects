public class Hall {
    private String film_name;
    private String hall_name;
    private String price;
    private String row;
    private String column;
    Hall(String[] parted){
        this.film_name = parted[1];
        this.hall_name = parted[2];
        this.price = parted[3];
        this.row = parted[4];
        this.column = parted[5];
    }

    public String getHall_name() {
        return hall_name;
    }

    public void setHall_name(String hall_name) {
        this.hall_name = hall_name;
    }

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public String getPrice() {
        return price;
    }

    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }

    public void setPrice(String price) {
        this.price = price;
    }
    public String getFilm_name() {
        return film_name;
    }

    public void setFilm_name(String film_name) {
        this.film_name = film_name;
    }
}
