public class User {
    private String name;
    private String hashcode;
    private String if_club_member;
    private String if_admin;
    User(String[] parted){
        this.name = parted[1];
        this.hashcode = parted[2];
        this.if_club_member = parted[3];
        this.if_admin = parted[4];
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHashcode() {
        return hashcode;
    }

    public String getIf_admin() {
        return if_admin;
    }

    public void setIf_admin(String if_admin) {
        this.if_admin = if_admin;
    }

    public String getIf_club_member() {
        return if_club_member;
    }

    public void setIf_club_member(String if_club_member) {
        this.if_club_member = if_club_member;
    }

    public void setHashcode(String hashcode) {
        this.hashcode = hashcode;
    }
}
