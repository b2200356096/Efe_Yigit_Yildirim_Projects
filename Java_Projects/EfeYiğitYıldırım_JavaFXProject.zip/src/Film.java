import java.util.ArrayList;

public class Film {
    private String name;
    private String path;
    private String time;
    private ArrayList<Hall> halls = new ArrayList<>();
    Film(String[] parted){
        this.name = parted[1];
        this.path = parted[2];
        this.time = parted[3];
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public ArrayList<Hall> getHalls() {
        return halls;
    }

    public void setHalls(Hall hall) {
        this.halls.add(hall);
    }
    public void removeHall(Hall hall){
        this.halls.remove(hall);
    }

    public void setPath(String path) {
        this.path = path;
    }
}
