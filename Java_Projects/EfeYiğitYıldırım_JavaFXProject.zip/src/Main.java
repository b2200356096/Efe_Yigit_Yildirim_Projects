import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Timer;
import java.util.TimerTask;


public class Main extends Application {
    public static ArrayList<User> user_list = new ArrayList<>();
    public static ArrayList<Film> film_list = new ArrayList<>();

    @Override
    public void start(Stage stage) throws Exception {
        File file = new File("assets\\data\\backup.dat");
        FileReader fileReader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        File file1 = new File("assets\\data\\properties.dat");
        FileReader fileReader1 = new FileReader(file1);
        BufferedReader bufferedReader1 = new BufferedReader(fileReader1);
        String lines;
        String property_lines;
        ArrayList<User> users = user_list;
        ArrayList<Film> films = film_list;
        ArrayList<String> paths = new ArrayList<>();
        ArrayList<Hall> halls = new ArrayList<>();
        ArrayList<Integer> count_check = new ArrayList<>();
        ArrayList<Integer> seconds_passed = new ArrayList<>();
        ArrayList<Integer> five_check = new ArrayList<>();
        ArrayList<String> properties_array = new ArrayList<>();
        int max_error_count = 0;
        int block_time = 0;
        while ((lines = bufferedReader.readLine()) != null){
            String[] parted = lines.split("\t");
            if (parted[0].equals("user")){
                users.add(new User(parted));
            }
            else if (parted[0].equals("film")){
                films.add(new Film(parted));
            }
            else if (parted[0].equals("hall")){
                for (Film film : films){
                    if (film.getName().equals(parted[1])){
                        halls.add(new Hall(parted));
                    }
                }
            }
        }
        for (Film film : films){
            for (Hall hall : halls){
                if (film.getName().equals(hall.getFilm_name())){
                    film.setHalls(hall);
                }
            }
        }
        while ((property_lines = bufferedReader1.readLine()) != null){
            if (property_lines.equals("title=HUCS Cinema Reservation System")){
                String[] parts = property_lines.split("=");
                stage.setTitle(parts[1]);
            }
            else if (property_lines.contains("maximum-error")){
                String[] part = property_lines.split("=");
                max_error_count = Integer.parseInt(part[1]);
            }
            else if (property_lines.contains("block-time")){
                String[] part = property_lines.split("=");
                block_time = Integer.parseInt(part[1]);
            }
        }
        paths.add("avengers_endgame.mp4");
        paths.add("doctor_strange_in_the_multiverse_of_madness.mp4");
        paths.add("fantastic_beasts_the_secrets_of_dumbledore.mp4");
        paths.add("the_imitation_game.mp4");
        paths.add("the_batman.mp4");
        paths.add("sonic_the_hedgehog_2.mp4");
        paths.add("spider_man_no_way_home.mp4");
        // Tableview part
        TableView<User> table = new TableView<>();
        table.setItems(getUsers(users));

        // Tableview part
        File icon_file = new File("assets\\icons\\logo.png");
        String icon_uri = icon_file.toURI().toString();
        stage.getIcons().add(new Image(icon_uri));
        File error_file = new File("assets\\effects\\error.mp3");
        String error_path_string = error_file.toURI().toString();
        Media error_media = new Media(error_path_string);
        MediaPlayer error_media_player = new MediaPlayer(error_media);
        // login_part
        Label label = new Label("Welcome to the HUCS Cinema Reservation System!");
        Label label1 = new Label("Please enter your credentials below and click login");
        Label label2 = new Label("You can create a new account by clicking sign up button");
        Label hidden = new Label("saklı");
        hidden.setVisible(false);
        Label label3 = new Label("Username:  ");
        TextField textField = new TextField();
        Label label4 = new Label("Password:  ");
        PasswordField textField1 = new PasswordField();
        Button button = new Button("SIGN UP");
        Button button1 = new Button("LOG IN");

        HBox hBox1 = new HBox();
        hBox1.getChildren().addAll(label3,textField);
        hBox1.setPadding(new Insets(30,30,0,0));
        hBox1.setAlignment(Pos.CENTER);
        HBox hBox2 = new HBox();
        hBox2.getChildren().addAll(label4,textField1);
        hBox2.setPadding(new Insets(10,30,10,0));
        hBox2.setAlignment(Pos.CENTER);
        HBox hBox3 = new HBox();
        hBox3.getChildren().addAll(button,button1);
        HBox.setMargin(button,new Insets(0,100,0,0));
        hBox3.setAlignment(Pos.CENTER);

        VBox vBox1 = new VBox();
        vBox1.getChildren().addAll(label,label1,label2,hBox1,hBox2,hBox3,hidden);
        VBox.setMargin(hidden,new Insets(10,0,0,0));
        vBox1.setAlignment(Pos.CENTER);
        Scene scene1 = new Scene(vBox1,500,500);
        // login part

        // sign up part
        Label label5 = new Label("Welcome to the HUCS Cinema Reservation System");
        Label label6 = new Label("Fill the form below to create a new account");
        Label label7 = new Label("You can go to log in page by clicking log in button");
        Label hidden_sign_up = new Label("ERROR");
        hidden_sign_up.setVisible(false);
        Label label8 = new Label("Username:  ");
        TextField textField2 = new TextField();
        Label label9 = new Label("Password:  ");
        PasswordField textField3 = new PasswordField();
        Label label10 = new Label("Password:  ");
        PasswordField textField4 = new PasswordField();
        Button button2 = new Button("LOG IN");
        Button button3 = new Button("SIGN UP");
        HBox hBox4 = new HBox();
        hBox4.getChildren().addAll(label8,textField2);
        hBox4.setPadding(new Insets(30,0,0,0));
        hBox4.setAlignment(Pos.CENTER);
        HBox hBox5 = new HBox();
        hBox5.getChildren().addAll(label9,textField3);
        hBox5.setPadding(new Insets(10,0,10,0));
        hBox5.setAlignment(Pos.CENTER);
        HBox hBox6 = new HBox();
        hBox6.getChildren().addAll(label10,textField4);
        hBox6.setPadding(new Insets(0,0,20,0));
        hBox6.setAlignment(Pos.CENTER);
        HBox hBox7 = new HBox();
        hBox7.getChildren().addAll(button2,button3);
        HBox.setMargin(button2,new Insets(0,100,0,0));
        hBox7.setAlignment(Pos.CENTER);

        VBox vBox2 = new VBox();
        vBox2.getChildren().addAll(label5,label6,label7,hBox4,hBox5,hBox6,hBox7,hidden_sign_up);
        VBox.setMargin(hidden_sign_up,new Insets(10,0,0,0));
        vBox2.setAlignment(Pos.CENTER);
        Scene scene2 = new Scene(vBox2,500,500);

        // sign up part


        // button actions part
        button.setOnAction(e -> {
            textField2.clear();
            stage.setScene(scene2);
        });
        int finalMax_error_count = max_error_count;
        int finalBlock_time = block_time;
        button1.setOnAction(e -> {
            String pass = hashPassword(textField1.getText());
            boolean check = false;
            for (User user : users){
                if ((textField.getText().equals(user.getName())) && (pass.equals(user.getHashcode()))){
                    check = true;
                }
            }
            if (check && (five_check.size() == 0)){
                for (User user : table.getItems()){
                    if ((textField.getText().equals(user.getName())) && (pass.equals(user.getHashcode()))){
                        count_check.clear();
                        if (user.getIf_admin().equals("true")){
                            ChoiceBox<String> choiceBox = new ChoiceBox<>();
                            for (Film film : films){
                                choiceBox.getItems().add(film.getName());
                            }
                            try {
                                choiceBox.setValue(films.get(0).getName());
                            }
                            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                choiceBox.getItems().clear();
                            }
                            Label welcome_label1 = new Label("");
                            if (user.getIf_club_member().equals("true")){
                                welcome_label1 = new Label("Welcome " + user.getName() + " (Admin - Club Member)!");
                            }
                            else {
                                welcome_label1 = new Label("Welcome " + user.getName() + " (Admin)!");
                            }
                            Label welcome_label2 = new Label("You can either select film below or do edits.");
                            Button ok_button = new Button("OK");
                            Button add_button = new Button("Add Film");
                            Button remove_button = new Button("Remove Film");
                            Button edit_button = new Button("Edit Users");
                            Button log_out_button = new Button("LOG OUT");
                            log_out_button.setOnAction(a -> {
                                textField.clear();
                                textField1.clear();
                                hidden.setVisible(false);
                                stage.setScene(scene1);
                            });
                            HBox welcome_page_box = new HBox();
                            welcome_page_box.getChildren().addAll(choiceBox,ok_button);
                            HBox.setMargin(ok_button,new Insets(0,0,0,5));
                            welcome_page_box.setPadding(new Insets(30,10,10,0));
                            welcome_page_box.setAlignment(Pos.CENTER);
                            HBox welcome_page_box2 = new HBox();
                            welcome_page_box2.getChildren().addAll(add_button,remove_button,edit_button);
                            welcome_page_box2.setPadding(new Insets(0,0,10,0));
                            HBox.setMargin(add_button,new Insets(0,10,0,0));
                            HBox.setMargin(edit_button,new Insets(0,0,0,10));
                            welcome_page_box2.setAlignment(Pos.CENTER);
                            HBox welcome_page_box3 = new HBox();
                            welcome_page_box3.getChildren().addAll(log_out_button);
                            HBox.setMargin(log_out_button,new Insets(0,0,0,250));
                            welcome_page_box3.setAlignment(Pos.CENTER);
                            VBox welcome_vbox = new VBox(welcome_label1,welcome_label2,welcome_page_box,welcome_page_box2,welcome_page_box3);
                            welcome_vbox.setAlignment(Pos.CENTER);
                            Scene scene3 = new Scene(welcome_vbox,500,500);
                            stage.setScene(scene3);
                            remove_button.setOnAction(b -> {
                                Label remove_label = new Label("Select film that you desire to remove and then click OK");
                                Button back_button = new Button("Back");
                                back_button.setOnAction(c -> {
                                    try {
                                        choiceBox.setValue(films.get(0).getName());
                                    }
                                    catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                        choiceBox.getItems().clear();
                                    }
                                    stage.setScene(scene3);
                                });
                                Button remove_button_page = new Button("OK");
                                HBox choice_box_remove_page = new HBox();
                                ChoiceBox<String> choiceBox_temp = new ChoiceBox<>();
                                for (Film film : films){
                                    choiceBox_temp.getItems().add(film.getName());
                                }
                                try {
                                    choiceBox_temp.setValue(films.get(0).getName());
                                }
                                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                    choiceBox_temp.getItems().clear();
                                }
                                choice_box_remove_page.getChildren().addAll(choiceBox_temp);
                                choice_box_remove_page.setPadding(new Insets(20,0,10,0));
                                choice_box_remove_page.setAlignment(Pos.CENTER);
                                HBox remove_page_hbox = new HBox();
                                remove_page_hbox.getChildren().addAll(back_button,remove_button_page);
                                HBox.setMargin(back_button,new Insets(0,20,0,0));
                                remove_page_hbox.setAlignment(Pos.CENTER);
                                VBox remove_page_Vbox = new VBox(remove_label,choice_box_remove_page,remove_page_hbox);
                                remove_page_Vbox.setAlignment(Pos.CENTER);
                                Scene remove_page_scene = new Scene(remove_page_Vbox,400,400);
                                remove_button_page.setOnAction(d -> {
                                    String temp_erase = choiceBox_temp.getValue();
                                    choiceBox_temp.getItems().remove(choiceBox_temp.getValue());
                                    choiceBox.getItems().remove(temp_erase);
                                    films.removeIf(film -> film.getName().equals(temp_erase));
                                    try {
                                        choiceBox_temp.setValue(films.get(0).getName());
                                    }
                                    catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                        choiceBox_temp.getItems().clear();
                                    }
                                    try {
                                        choiceBox.setValue(films.get(0).getName());
                                    }
                                    catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                        choiceBox.getItems().clear();
                                    }
                                });
                                stage.setScene(remove_page_scene);
                            });
                            edit_button.setOnAction(g -> {
                                ArrayList<User> temp_users = new ArrayList<>();
                                for (User user1 : users){
                                    if (!(user.getName().equals(user1.getName()))){
                                        temp_users.add(user1);
                                    }
                                }
                                TableView<User> temp_table = new TableView<>();
                                temp_table.setItems(getUsers(temp_users));
                                TableColumn<User,String> name_column = new TableColumn<>("Username");
                                name_column.setMaxWidth(200);
                                name_column.setCellValueFactory(new PropertyValueFactory<>("name"));

                                TableColumn<User,String> if_club_member_column = new TableColumn<>("Club");
                                if_club_member_column.setMaxWidth(200);
                                if_club_member_column.setCellValueFactory(new PropertyValueFactory<>("if_club_member"));

                                TableColumn<User,String> if_admin = new TableColumn<>("Admin");
                                if_admin.setMaxWidth(200);
                                if_admin.setCellValueFactory(new PropertyValueFactory<>("if_admin"));

                                Button go_back_table = new Button("Back");
                                Button pro_demo_club = new Button("Promote/Demote Club Member");
                                pro_demo_club.setOnAction(h -> pro_demo_club(temp_table,users));
                                Button pro_demo_admin = new Button("Promote/Demote Admin");
                                pro_demo_admin.setOnAction(j -> pro_demo_admin(temp_table,users));

                                HBox hBox = new HBox();
                                hBox.setPadding(new Insets(10,10,10,10));
                                hBox.setSpacing(80);
                                hBox.getChildren().addAll(go_back_table,pro_demo_club,pro_demo_admin);
                                hBox.setAlignment(Pos.CENTER);

                                //getColumns().addAll(name_column,if_club_member_column,if_admin);
                                temp_table.getColumns().add(name_column);
                                temp_table.getColumns().add(if_club_member_column);
                                temp_table.getColumns().add(if_admin);
                                VBox vBox = new VBox();
                                vBox.getChildren().addAll(temp_table,hBox);
                                VBox.setMargin(temp_table,new Insets(0,50,0,50));
                                vBox.setAlignment(Pos.CENTER);
                                Scene scene = new Scene(vBox,650,650);
                                go_back_table.setOnAction(h -> {
                                    try {
                                        choiceBox.setValue(films.get(0).getName());
                                    }
                                    catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                        choiceBox.getItems().clear();
                                    }
                                    stage.setScene(scene3);
                                });
                                stage.setScene(scene);
                            });
                            add_button.setOnAction(r -> {
                                Label add_film_label = new Label("Please give name, relative path of the trailer and duration of the film");
                                Label add_film_name = new Label("Name:             ");
                                Label add_film_path = new Label("Trailer (Path):  ");
                                Label add_film_duration = new Label("Duration (m):  ");
                                Label hidden_add_film_label = new Label("ERROR");
                                hidden_add_film_label.setVisible(false);
                                TextField add_film_text1 = new TextField();
                                TextField add_film_text2 = new TextField();
                                TextField add_film_text3 = new TextField();
                                Button add_film_back = new Button("Back");
                                Button add_film_add = new Button("OK");
                                HBox add_film_hbox1 = new HBox();
                                add_film_hbox1.getChildren().addAll(add_film_name,add_film_text1);
                                add_film_hbox1.setPadding(new Insets(20,0,0,0));
                                add_film_hbox1.setAlignment(Pos.CENTER);
                                HBox add_film_hbox2 = new HBox();
                                add_film_hbox2.getChildren().addAll(add_film_path,add_film_text2);
                                add_film_hbox2.setPadding(new Insets(10,0,0,0));
                                add_film_hbox2.setAlignment(Pos.CENTER);
                                HBox add_film_hbox3 = new HBox();
                                add_film_hbox3.getChildren().addAll(add_film_duration,add_film_text3);
                                add_film_hbox3.setPadding(new Insets(10,0,0,0));
                                add_film_hbox3.setAlignment(Pos.CENTER);
                                HBox add_film_hbox4 = new HBox();
                                add_film_hbox4.getChildren().addAll(add_film_back,add_film_add);
                                add_film_hbox4.setPadding(new Insets(10,0,0,0));
                                add_film_hbox4.setAlignment(Pos.CENTER);
                                HBox.setMargin(add_film_back,new Insets(0,150,0,0));
                                VBox add_film_vbox = new VBox(add_film_label,add_film_hbox1,add_film_hbox2,add_film_hbox3,add_film_hbox4,hidden_add_film_label);
                                VBox.setMargin(hidden_add_film_label,new Insets(10,0,0,0));
                                add_film_vbox.setAlignment(Pos.CENTER);
                                Scene add_film_scene = new Scene(add_film_vbox,500,500);
                                stage.setScene(add_film_scene);
                                add_film_back.setOnAction(t -> {
                                    hidden_add_film_label.setVisible(false);
                                    try {
                                        choiceBox.setValue(films.get(0).getName());
                                    }
                                    catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                        choiceBox.getItems().clear();
                                    }
                                    stage.setScene(scene3);
                                });
                                add_film_add.setOnAction(y -> {
                                    String name = add_film_text1.getText();
                                    String path = add_film_text2.getText();
                                    String duration = add_film_text3.getText();
                                    if (name.equals("")){
                                        hidden_add_film_label.setText("ERROR: Film name could not be empty");
                                        hidden_add_film_label.setVisible(true);
                                        error_media_player.play();
                                        error_media_player.seek(Duration.ZERO);
                                    }
                                    else if (path.equals("")){
                                        hidden_add_film_label.setText("ERROR: Trailer path could not be empty");
                                        hidden_add_film_label.setVisible(true);
                                        error_media_player.play();
                                        error_media_player.seek(Duration.ZERO);
                                    }
                                    else if (duration.equals("")){
                                        hidden_add_film_label.setText("ERROR: Duration has to be a positive integer");
                                        hidden_add_film_label.setVisible(true);
                                        error_media_player.play();
                                        error_media_player.seek(Duration.ZERO);
                                    }
                                    else {
                                        try {
                                            int duration_int = Integer.parseInt(duration);
                                            if (!(paths.contains(path))){
                                                hidden_add_film_label.setText("ERROR: There is no such trailer");
                                                hidden_add_film_label.setVisible(true);
                                                error_media_player.play();
                                                error_media_player.seek(Duration.ZERO);
                                            }
                                            else {
                                                hidden_add_film_label.setText("SUCCESS: Film added successfully");
                                                hidden_add_film_label.setVisible(true);
                                                String[] temp_add_parted = {"film",name,path,duration};
                                                films.add(new Film(temp_add_parted));
                                                choiceBox.getItems().add(name);
                                                add_film_text1.clear();
                                                add_film_text2.clear();
                                                add_film_text3.clear();
                                            }
                                        }
                                        catch (NumberFormatException numberFormatException){
                                            hidden_add_film_label.setText("ERROR: Duration has to be a positive integer");
                                            hidden_add_film_label.setVisible(true);
                                            error_media_player.play();
                                            error_media_player.seek(Duration.ZERO);
                                        }
                                    }
                                });
                            });
                            ok_button.setOnAction(f -> {
                                if (choiceBox.getItems().size() == 0){
                                    error_media_player.play();
                                    error_media_player.seek(Duration.ZERO);
                                }
                                else {
                                    Label play_film_label = new Label("");
                                    File mp4_file = null;
                                    String MEDIA_URL = "";
                                    for (Film film : films){
                                        if (film.getName().equals(choiceBox.getValue())){
                                            mp4_file = new File("assets\\trailers\\" + film.getPath());
                                            play_film_label = new Label(film.getName() + "(" + film.getTime() + " minutes)");
                                        }
                                    }
                                    assert mp4_file != null;
                                    MEDIA_URL = mp4_file.toURI().toString();
                                    Media film_media = new Media(MEDIA_URL);
                                    MediaPlayer mediaPlayer = new MediaPlayer(film_media);
                                    mediaPlayer.setAutoPlay(false);
                                    mediaPlayer.setOnReady(stage::sizeToScene);
                                    MediaView mediaView = new MediaView(mediaPlayer);
                                    Slider slider = new Slider();
                                    slider.setPrefWidth(150);
                                    slider.setMaxWidth(Region.USE_PREF_SIZE);
                                    slider.setMinWidth(30);
                                    slider.setValue(50);
                                    slider.setOrientation(Orientation.VERTICAL);
                                    mediaPlayer.volumeProperty().bind(slider.valueProperty().divide(100));
                                    Button play_button = new Button(">");
                                    Button restart_button = new Button("|<<");
                                    Button go_back_button = new Button("<<");
                                    Button go_button = new Button(">>");
                                    go_button.setOnAction(yu -> mediaPlayer.seek(new Duration(mediaPlayer.getCurrentTime().toMillis() + 5000)));
                                    go_back_button.setOnAction(ut -> mediaPlayer.seek(new Duration(mediaPlayer.getCurrentTime().toMillis() - 5000)));
                                    Button film_back_button = new Button("BACK");
                                    film_back_button.setOnAction(p -> {
                                        mediaPlayer.stop();
                                        stage.setScene(scene3);
                                    });
                                    Button film_add_button = new Button("Add Hall");
                                    Button film_remove_button = new Button("Remove Hall");
                                    ChoiceBox<String> film_watch_choice_box = new ChoiceBox<>();
                                    for (Film film : films){
                                        if (film.getName().equals(choiceBox.getValue())){
                                            for (Hall hall : film.getHalls()){
                                                film_watch_choice_box.getItems().add(hall.getHall_name());
                                            }
                                            try {
                                                film_watch_choice_box.setValue(film.getHalls().get(0).getHall_name());
                                            }
                                            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                                film_watch_choice_box.getItems().clear();
                                            }
                                        }
                                    }
                                    Button film_ok_button = new Button("OK");
                                    film_ok_button.setOnAction(y -> {
                                        if (film_watch_choice_box.getItems().size() == 0){
                                            error_media_player.play();
                                            error_media_player.seek(Duration.ZERO);
                                        }
                                    });
                                    restart_button.setOnAction(p -> mediaPlayer.seek(Duration.ZERO));
                                    play_button.setOnAction(l -> {
                                        if (play_button.getText().equals(">")){
                                            mediaPlayer.play();
                                            play_button.setText("||");
                                        }
                                        else {
                                            mediaPlayer.pause();
                                            play_button.setText(">");
                                        }
                                    });
                                    VBox play_film_vbox = new VBox(play_button,go_back_button,go_button,restart_button,slider);
                                    VBox.setMargin(play_button,new Insets(0,0,0,65));
                                    VBox.setMargin(go_back_button,new Insets(15,0,0,65));
                                    VBox.setMargin(go_button,new Insets(15,0,0,65));
                                    VBox.setMargin(restart_button,new Insets(15,0,0,65));
                                    HBox.setMargin(film_back_button,new Insets(20,60,0,0));
                                    HBox.setMargin(film_add_button,new Insets(20,30,0,0));
                                    Label finalPlay_film_label = play_film_label;
                                    HBox.setMargin(film_remove_button,new Insets(20,0,0,0));
                                    HBox.setMargin(film_watch_choice_box,new Insets(20,0,0,30));
                                    HBox.setMargin(film_ok_button,new Insets(20,0,0,60));
                                    play_film_vbox.setPadding(new Insets(100,0,0,0));
                                    HBox film_player_hbox = new HBox();
                                    film_player_hbox.getChildren().addAll(mediaView,play_film_vbox);
                                    film_player_hbox.setAlignment(Pos.CENTER);
                                    HBox underline_film_hbox = new HBox();
                                    underline_film_hbox.getChildren().addAll(film_back_button,film_add_button,film_remove_button,film_watch_choice_box,film_ok_button);
                                    underline_film_hbox.setAlignment(Pos.CENTER);
                                    VBox all_play_film_vbox = new VBox(play_film_label,film_player_hbox,underline_film_hbox);
                                    VBox.setMargin(play_film_label,new Insets(0,0,20,0));
                                    all_play_film_vbox.setAlignment(Pos.CENTER);
                                    Scene film_scene = new Scene(all_play_film_vbox);
                                    stage.setScene(film_scene);
                                    film_add_button.setOnAction(y -> {
                                        mediaPlayer.stop();
                                        Label row_label = new Label("Row:      ");
                                        Label column_label = new Label("Column:  ");
                                        Label name_label = new Label("Name:   ");
                                        Label price_label = new Label("Price:  ");
                                        Label hidden_add_hall_label = new Label("ERROR");
                                        hidden_add_hall_label.setVisible(false);
                                        TextField name_text_field = new TextField();
                                        TextField price_text_field = new TextField();
                                        Button back_add_hall_button = new Button("Back");
                                        back_add_hall_button.setOnAction(p -> {
                                            hidden_add_hall_label.setVisible(false);
                                            play_button.setText(">");
                                            slider.setValue(50);
                                            stage.setScene(film_scene);
                                        });
                                        Button ok_add_hall_button = new Button("OK");
                                        ChoiceBox<String> row_choicebox = new ChoiceBox<>();
                                        row_choicebox.getItems().addAll("3","4","5","6","7","8","9","10");
                                        row_choicebox.setValue("3");
                                        ChoiceBox<String> column_choicebox = new ChoiceBox<>();
                                        column_choicebox.getItems().addAll("3","4","5","6","7","8","9","10");
                                        column_choicebox.setValue("3");
                                        ok_add_hall_button.setOnAction(u -> {
                                            String row = row_choicebox.getValue();
                                            String column = column_choicebox.getValue();
                                            String hall_name = name_text_field.getText();
                                            String price = price_text_field.getText();
                                            if (hall_name.equals("")){
                                                hidden_add_hall_label.setText("ERROR: Hall name could not be empty");
                                                hidden_add_hall_label.setVisible(true);
                                                error_media_player.play();
                                                error_media_player.seek(Duration.ZERO);
                                            }
                                            else if (price.equals("")){
                                                hidden_add_hall_label.setText("ERROR: Price could not be empty");
                                                hidden_add_hall_label.setVisible(true);
                                                error_media_player.play();
                                                error_media_player.seek(Duration.ZERO);
                                            }
                                            else {
                                                String[] temp_hall_parted = {"hall",choiceBox.getValue(),hall_name,price,row,column};
                                                for (Film film : films){
                                                    if (film.getName().equals(choiceBox.getValue())){
                                                        film.setHalls(new Hall(temp_hall_parted));
                                                        film_watch_choice_box.getItems().add(new Hall(temp_hall_parted).getHall_name());
                                                    }
                                                }
                                                if (film_watch_choice_box.getItems().size() == 1){
                                                    film_watch_choice_box.setValue(hall_name);
                                                }
                                                name_text_field.clear();
                                                price_text_field.clear();
                                                row_choicebox.setValue("3");
                                                column_choicebox.setValue("3");
                                                hidden_add_hall_label.setText("SUCCESS: Hall successfully created");
                                                hidden_add_hall_label.setVisible(true);
                                            }
                                            row_choicebox.setValue("3");
                                            column_choicebox.setValue("3");
                                        });
                                        HBox row_hbox = new HBox();
                                        row_hbox.getChildren().addAll(row_label,row_choicebox);
                                        HBox.setMargin(row_label,new Insets(0,80,0,0));
                                        HBox.setMargin(row_choicebox,new Insets(0,0,0,65));
                                        row_hbox.setAlignment(Pos.CENTER);
                                        HBox column_hbox = new HBox();
                                        column_hbox.getChildren().addAll(column_label,column_choicebox);
                                        HBox.setMargin(column_label,new Insets(0,80,0,0));
                                        HBox.setMargin(column_choicebox,new Insets(0,0,0,60));
                                        column_hbox.setAlignment(Pos.CENTER);
                                        HBox name_hbox = new HBox();
                                        name_hbox.getChildren().addAll(name_label,name_text_field);
                                        name_hbox.setAlignment(Pos.CENTER);
                                        HBox price_hbox = new HBox();
                                        price_hbox.getChildren().addAll(price_label,price_text_field);
                                        price_hbox.setAlignment(Pos.CENTER);
                                        HBox.setMargin(price_text_field,new Insets(0,0,0,5));
                                        HBox button_add_hall_hbox = new HBox();
                                        button_add_hall_hbox.getChildren().addAll(back_add_hall_button,ok_add_hall_button);
                                        HBox.setMargin(back_add_hall_button,new Insets(0,60,0,0));
                                        HBox.setMargin(ok_add_hall_button,new Insets(0,0,0,60));
                                        button_add_hall_hbox.setAlignment(Pos.CENTER);
                                        VBox add_hall_vbox = new VBox(finalPlay_film_label,row_hbox,column_hbox,name_hbox,price_hbox,button_add_hall_hbox,hidden_add_hall_label);
                                        VBox.setMargin(hidden_add_hall_label,new Insets(10,0,0,0));
                                        VBox.setMargin(column_hbox,new Insets(0,0,10,0));
                                        VBox.setMargin(name_hbox,new Insets(0,0,10,0));
                                        VBox.setMargin(price_hbox,new Insets(0,0,10,0));
                                        VBox.setMargin(button_add_hall_hbox,new Insets(0,0,10,0));
                                        add_hall_vbox.setAlignment(Pos.CENTER);
                                        Scene add_hall_scene = new Scene(add_hall_vbox,500,500);
                                        stage.setScene(add_hall_scene);
                                    });
                                    film_remove_button.setOnAction(uy -> {
                                        mediaPlayer.stop();
                                        Label remove_hall_label = new Label("Select the hall you desire to remove from " +
                                                choiceBox.getValue() + " and then click OK");
                                        ChoiceBox<String> remove_hall_choiceBox =new ChoiceBox<>();
                                        for (Film film : films){
                                            if (film.getName().equals(choiceBox.getValue())){
                                                for (Hall hall : film.getHalls()){
                                                    remove_hall_choiceBox.getItems().addAll(hall.getHall_name());
                                                }
                                                try {
                                                    remove_hall_choiceBox.setValue(film.getHalls().get(0).getHall_name());
                                                }
                                                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                                    remove_hall_choiceBox.getItems().clear();
                                                }
                                            }
                                        }
                                        Button remove_hall_back_button = new Button("BACK");
                                        remove_hall_back_button.setOnAction(us -> {
                                            play_button.setText(">");
                                            slider.setValue(50);
                                            stage.setScene(film_scene);
                                        });
                                        Button remove_hall_ok_button = new Button("OK");
                                        remove_hall_ok_button.setOnAction(us ->{
                                            Hall temp_hall = null;
                                            for (Film film : films){
                                                if (film.getName().equals(choiceBox.getValue())){
                                                    for (Hall hall : film.getHalls()){
                                                        if (hall.getHall_name().equals(remove_hall_choiceBox.getValue())){
                                                            temp_hall = hall;
                                                        }
                                                    }
                                                    film.removeHall(temp_hall);
                                                }
                                            }
                                            remove_hall_choiceBox.getItems().remove(remove_hall_choiceBox.getValue());
                                            film_watch_choice_box.getItems().remove(remove_hall_choiceBox.getValue());
                                            try {
                                                remove_hall_choiceBox.setValue(remove_hall_choiceBox.getItems().get(0));
                                                film_watch_choice_box.setValue(film_watch_choice_box.getItems().get(0));
                                            }
                                            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                                remove_hall_choiceBox.getItems().clear();
                                                film_watch_choice_box.getItems().clear();
                                            }
                                        });
                                        HBox remove_hall_hbox = new HBox();
                                        remove_hall_hbox.getChildren().addAll(remove_hall_back_button,remove_hall_ok_button);
                                        remove_hall_hbox.setAlignment(Pos.CENTER);
                                        VBox remove_hall_vbox = new VBox(remove_hall_label,remove_hall_choiceBox,remove_hall_hbox);
                                        VBox.setMargin(remove_hall_choiceBox,new Insets(10,0,0,0));
                                        VBox.setMargin(remove_hall_hbox,new Insets(10,0,0,0));
                                        HBox.setMargin(remove_hall_back_button,new Insets(0,10,0,0));
                                        remove_hall_vbox.setAlignment(Pos.CENTER);
                                        Scene remove_hall_scene = new Scene(remove_hall_vbox,700,500);
                                        stage.setScene(remove_hall_scene);
                                    });
                                }
                            });
                        }
                        else {
                            ChoiceBox<String> choiceBox = new ChoiceBox<>();
                            for (Film film : films){
                                choiceBox.getItems().add(film.getName());
                            }
                            try {
                                choiceBox.setValue(films.get(0).getName());
                            }
                            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                choiceBox.getItems().clear();
                            }
                            Label welcome_label3 = new Label("");
                            if (user.getIf_club_member().equals("true")){
                                welcome_label3 = new Label("Welcome " + user.getName() + " (Club Member)!");
                            }
                            else {
                                welcome_label3 = new Label("Welcome " + user.getName() + "!");
                            }
                            Label welcome_label4 = new Label("Select a film and then click OK to continue");
                            Button ok_button = new Button("OK");
                            Button log_out_button = new Button("LOG OUT");
                            HBox not_admin_hbox = new HBox();
                            not_admin_hbox.getChildren().addAll(choiceBox,ok_button);
                            not_admin_hbox.setPadding(new Insets(10,0,10,0));
                            HBox.setMargin(ok_button,new Insets(0,0,0,10));
                            not_admin_hbox.setAlignment(Pos.CENTER);
                            HBox not_admin_hbox1 = new HBox();
                            not_admin_hbox1.getChildren().addAll(log_out_button);
                            HBox.setMargin(log_out_button,new Insets(0,0,0,260));
                            not_admin_hbox1.setAlignment(Pos.CENTER);
                            VBox not_admin_vbox = new VBox(welcome_label3,welcome_label4,not_admin_hbox,not_admin_hbox1);
                            not_admin_vbox.setAlignment(Pos.CENTER);
                            Scene not_admin_scene = new Scene(not_admin_vbox,500,500);
                            stage.setScene(not_admin_scene);
                            log_out_button.setOnAction(sp -> {
                                textField.clear();
                                textField1.clear();
                                hidden.setVisible(false);
                                stage.setScene(scene1);
                            });
                            ok_button.setOnAction(ss -> {
                                if (choiceBox.getItems().size() == 0){
                                    error_media_player.play();
                                    error_media_player.seek(Duration.ZERO);
                                }
                                else {
                                    Label play_film_label = new Label("");
                                    File mp4_file = null;
                                    String MEDIA_URL = "";
                                    for (Film film : films){
                                        if (film.getName().equals(choiceBox.getValue())){
                                            mp4_file = new File("assets\\trailers\\" + film.getPath());
                                            play_film_label = new Label(film.getName() + "(" + film.getTime() + " minutes)");
                                        }
                                    }
                                    assert mp4_file != null;
                                    MEDIA_URL = mp4_file.toURI().toString();
                                    Media film_media = new Media(MEDIA_URL);
                                    MediaPlayer mediaPlayer = new MediaPlayer(film_media);
                                    mediaPlayer.setAutoPlay(false);
                                    mediaPlayer.setOnReady(stage::sizeToScene);
                                    MediaView mediaView = new MediaView(mediaPlayer);
                                    Slider slider = new Slider();
                                    slider.setPrefWidth(150);
                                    slider.setMaxWidth(Region.USE_PREF_SIZE);
                                    slider.setMinWidth(30);
                                    slider.setValue(50);
                                    slider.setOrientation(Orientation.VERTICAL);
                                    mediaPlayer.volumeProperty().bind(slider.valueProperty().divide(100));
                                    Button play_button = new Button(">");
                                    Button restart_button = new Button("|<<");
                                    Button go_back_button = new Button("<<");
                                    Button go_button = new Button(">>");
                                    Button film_back_button = new Button("BACK");
                                    go_button.setOnAction(yu -> mediaPlayer.seek(new Duration(mediaPlayer.getCurrentTime().toMillis() + 5000)));
                                    go_back_button.setOnAction(ut -> mediaPlayer.seek(new Duration(mediaPlayer.getCurrentTime().toMillis() - 5000)));
                                    film_back_button.setOnAction(p -> {
                                        mediaPlayer.stop();
                                        stage.setScene(not_admin_scene);
                                    });
                                    ChoiceBox<String> film_watch_choice_box = new ChoiceBox<>();
                                    for (Film film : films){
                                        if (film.getName().equals(choiceBox.getValue())){
                                            for (Hall hall : film.getHalls()){
                                                film_watch_choice_box.getItems().add(hall.getHall_name());
                                            }
                                            try {
                                                film_watch_choice_box.setValue(film.getHalls().get(0).getHall_name());
                                            }
                                            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                                                film_watch_choice_box.getItems().clear();
                                            }
                                        }
                                    }
                                    Button film_ok_button = new Button("OK");
                                    film_ok_button.setOnAction(ps -> {
                                        if (film_watch_choice_box.getItems().size() == 0){
                                            error_media_player.play();
                                            error_media_player.seek(Duration.ZERO);
                                        }
                                    });
                                    restart_button.setOnAction(p -> mediaPlayer.seek(Duration.ZERO));
                                    play_button.setOnAction(l -> {
                                        if (play_button.getText().equals(">")){
                                            mediaPlayer.play();
                                            play_button.setText("||");
                                        }
                                        else {
                                            mediaPlayer.pause();
                                            play_button.setText(">");
                                        }
                                    });
                                    VBox play_film_vbox = new VBox(play_button,go_back_button,go_button,restart_button,slider);
                                    VBox.setMargin(play_button,new Insets(0,0,0,65));
                                    VBox.setMargin(go_back_button,new Insets(15,0,0,65));
                                    VBox.setMargin(go_button,new Insets(15,0,0,65));
                                    VBox.setMargin(restart_button,new Insets(15,0,0,65));
                                    HBox.setMargin(film_back_button,new Insets(20,60,0,0));
                                    HBox.setMargin(film_watch_choice_box,new Insets(20,0,0,30));
                                    HBox.setMargin(film_ok_button,new Insets(20,0,0,60));
                                    play_film_vbox.setPadding(new Insets(100,0,0,0));
                                    HBox not_admin_film_player_hbox1 = new HBox();
                                    not_admin_film_player_hbox1.getChildren().addAll(mediaView,play_film_vbox);
                                    not_admin_film_player_hbox1.setAlignment(Pos.CENTER);
                                    HBox under_not_admin_hbox2 = new HBox();
                                    under_not_admin_hbox2.getChildren().addAll(film_back_button,film_watch_choice_box,film_ok_button);
                                    under_not_admin_hbox2.setAlignment(Pos.CENTER);
                                    VBox under_not_admin_vbox = new VBox(play_film_label,not_admin_film_player_hbox1,under_not_admin_hbox2);
                                    under_not_admin_vbox.setAlignment(Pos.CENTER);
                                    VBox.setMargin(play_film_label,new Insets(0,0,20,0));
                                    Scene film_scene = new Scene(under_not_admin_vbox);
                                    stage.setScene(film_scene);
                                }
                            });
                        }
                    }
                }
            }
            else {
                String text1 = "ERROR: There is no such a credential!";
                String text2 = "ERROR: Please wait for ";
                String text_second = Integer.toString(finalBlock_time);
                text2 += text_second;
                text2 += " seconds to make a new operation!";
                String text3 = "ERROR: Please wait until end of ";
                text3 += text_second;
                text3 += " seconds to make a new operation!";
                int temp_count = finalMax_error_count;
                int temp_time = finalBlock_time;
                int time_will_pass = 1000 * temp_time;
                if (check && (five_check.size() == 1)){
                    hidden.setText(text3);
                    hidden.setVisible(true);
                }
                else {
                    if (count_check.size() < temp_count){
                        count_check.add(1);
                    }
                    if (count_check.size() == temp_count && (five_check.size() == 0)){
                        hidden.setText(text2);
                        hidden.setVisible(true);
                        five_check.add(1);
                        Timer timer = new Timer();
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                seconds_passed.add(1);
                                count_check.clear();
                                five_check.clear();
                            }
                        },time_will_pass);
                    }
                    else if (count_check.size() == temp_count && (five_check.size() == 1) && (seconds_passed.size() == 0)){
                        hidden.setText(text3);
                        hidden.setVisible(true);
                    }
                    else {
                        seconds_passed.clear();
                        hidden.setText(text1);
                        hidden.setVisible(true);
                    }
                }
                textField1.clear();
                error_media_player.play();
                error_media_player.seek(Duration.ZERO);
            }
        });
        button2.setOnAction(e -> {
            hidden_sign_up.setVisible(false);
            textField.clear();
            textField1.clear();
            hidden.setVisible(false);
            stage.setScene(scene1);
        });
        button3.setOnAction(e -> {
            boolean user_checker = false;
            String temp_password1 = hashPassword(textField3.getText());
            String temp_password2 = hashPassword(textField4.getText());
            for (User user : users){
                if (textField2.getText().equals(user.getName())){
                    user_checker = true;
                }
            }
            if (user_checker){
                hidden_sign_up.setText("ERROR: This username already exists");
                hidden_sign_up.setVisible(true);
                error_media_player.play();
                error_media_player.seek(Duration.ZERO);
                textField2.clear();
                textField3.clear();
                textField4.clear();
            }
            else {
                if (textField2.getText().equals("")){
                    hidden_sign_up.setText("ERROR: Username cannot be empty");
                    hidden_sign_up.setVisible(true);
                    error_media_player.play();
                    error_media_player.seek(Duration.ZERO);
                    textField2.clear();
                    textField3.clear();
                    textField4.clear();
                }
                else if ((textField3.getText().equals("")) && (textField4.getText().equals(""))){
                    hidden_sign_up.setText("ERROR: Password cannot be empty");
                    hidden_sign_up.setVisible(true);
                    error_media_player.play();
                    error_media_player.seek(Duration.ZERO);
                }
                else if (!(textField3.getText().equals(textField4.getText()))){
                    hidden_sign_up.setText("ERROR: Passwords do not match");
                    hidden_sign_up.setVisible(true);
                    error_media_player.play();
                    error_media_player.seek(Duration.ZERO);
                    textField2.clear();
                    textField3.clear();
                    textField4.clear();
                }
                else {
                    hidden_sign_up.setText("You have successfully registered with your new credentials");
                    hidden_sign_up.setVisible(true);
                    String temp_code = hashPassword(textField3.getText());
                    String[] temp_list = {"user",textField2.getText(),temp_code,"false","false"};
                    users.add(new User(temp_list));
                    table.setItems(getUsers(users));
                    textField2.clear();
                    textField3.clear();
                    textField4.clear();
                }
            }
        });
        // button actions part


        stage.setScene(scene1);
        stage.show();
    }

    public static void main(String[] args) throws IOException {
        launch(args);
        File write_over = new File("assets\\data\\backup.dat");
        FileWriter fileWriter = new FileWriter(write_over,false);
        BufferedWriter buff = new BufferedWriter(fileWriter);
        for (User user : user_list){
            buff.write("user\t" + user.getName() + "\t" + user.getHashcode() + "\t" + user.getIf_club_member() + "\t" +
                    user.getIf_admin());
            buff.write("\n");
        }
        for (Film film : film_list){
            buff.write("film\t" + film.getName() + "\t" + film.getPath() + "\t" + film.getTime());
            buff.write("\n");
            for (Hall hall : film.getHalls()){
                buff.write("hall\t" + hall.getFilm_name() + "\t" + hall.getHall_name() + "\t" + hall.getPrice() + "\t" +
                        hall.getRow() + "\t" + hall.getColumn());
                buff.write("\n");
            }
        }
        buff.close();
    }
    public ObservableList<User> getUsers(ArrayList<User> users){
        ObservableList<User> userObservableList = FXCollections.observableArrayList();
        for (User user : users){
            userObservableList.add(user);
        }
        return userObservableList;
    }
    public void pro_demo_club(TableView<User> table,ArrayList<User> users){
        ObservableList<User> selected_user;
        selected_user = table.getSelectionModel().getSelectedItems();
        for (User user1 : selected_user){
            for (int i = 0;i < users.size();i++){
                if (users.get(i).getName().equals(user1.getName())){
                    if (users.get(i).getIf_club_member().equals("true")){
                        users.get(i).setIf_club_member("false");
                        table.refresh();
                    }
                    else if (users.get(i).getIf_club_member().equals("false")){
                        users.get(i).setIf_club_member("true");
                        table.refresh();
                    }
                }
            }
        }
    }
    public void pro_demo_admin(TableView<User> table,ArrayList<User> users){
        ObservableList<User> selected_user;
        selected_user = table.getSelectionModel().getSelectedItems();
        for (User user1 : selected_user){
            for (int i = 0;i < users.size();i++){
                if (users.get(i).getName().equals(user1.getName())){
                    if (users.get(i).getIf_admin().equals("true")){
                        users.get(i).setIf_admin("false");
                        table.refresh();
                    }
                    else if (users.get(i).getIf_admin().equals("false")){
                        users.get(i).setIf_admin("true");
                        table.refresh();
                    }
                }
            }
        }
    }
    public static String hashPassword(String password){
        byte[] bytesOfPassword = password.getBytes(StandardCharsets.UTF_8);
        byte[] md5Digest = new byte[0];
        try {
            md5Digest = MessageDigest.getInstance("MD5").digest(bytesOfPassword);
        } catch (NoSuchAlgorithmException e) {
            return "";
        }
        return Base64.getEncoder().encodeToString(md5Digest);
    }
}
