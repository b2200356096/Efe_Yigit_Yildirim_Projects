import java.util.ArrayList;

public class Player {
    private int money;
    private String name;
    private int location = 1;
    private String jail = "not";
    private String free_park = "not";
    private ArrayList<String> properties_list = new ArrayList<String>();
    private int jail_count = 1;

    public Player(String name){
        this.money = 15000;
        this.name = name;
    }

    public int getMoney() {
        return money;
    }

    public void setMoneyPlus(int money_move) {
        this.money += money_move;
    }
    public void setMoneyMinus(int money_move){
        this.money -= money_move;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location_act) {
        if (((location + location_act) % 40) != 0){
            this.location = (getLocation() + location_act) % 40;
        }
        else if (((location + location_act) % 40) == 0){
            this.location = 40;
        }
    }
    public void location_move_to(int move_to){
        this.location = move_to;
    }

    public String getJail() {
        return jail;
    }

    public void setJail(String jail) {
        this.jail = jail;
    }

    public String getFree_park() {
        return free_park;
    }

    public void setFree_park(String free_park) {
        this.free_park = free_park;
    }

    public ArrayList<String> getProperties_list() {
        return properties_list;
    }

    public void setProperties_list(String name) {
        this.properties_list.add(name);
    }

    public int getJail_count() {
        return jail_count;
    }

    public void setJail_count() {
        this.jail_count += 1;
    }
    public void setJail_count_one(){
        this.jail_count = 1;
    }
}
