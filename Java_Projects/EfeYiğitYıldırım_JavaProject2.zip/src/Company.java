import java.util.ArrayList;

public class Company extends Property {
    public Company(String[] values){
        super(values);
        setProperty_type("company");
    }

    @Override
    public String[] getRent(Player player, ArrayList<Property> properties, ArrayList<Player> players, String dice) {
        String write = "";
        String cont = "true";
        if (player.getName().equals(players.get(0).getName())){
            if (player.getMoney() >= (4 * Integer.parseInt(dice))){
                player.setMoneyMinus(4 * Integer.parseInt(dice));
                players.get(1).setMoneyPlus(4 * Integer.parseInt(dice));
                write =player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName()+
                        " "+"paid rent for " + getName() + "\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < (4 * Integer.parseInt(dice))){
                write =player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
        }
        else if (player.getName().equals(players.get(1).getName())){
            if (player.getMoney() >= (4 * Integer.parseInt(dice))){
                player.setMoneyMinus(4 * Integer.parseInt(dice));
                players.get(0).setMoneyPlus(4 * Integer.parseInt(dice));
                write =player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName()+
                        " "+"paid rent for " + getName() + "\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < (4 * Integer.parseInt(dice))){
                write =player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
        }
        return new String[]{write,cont};
    }
}
