import java.util.ArrayList;

public abstract class Property {
    private int id;
    private String name;
    private int cost;
    protected int rent;
    private String property_type;
    private String situation = "sale";

    public void setProperty_type(String property_type) {
        this.property_type = property_type;
    }

    public Property(String[] values){
        this.id = Integer.parseInt(values[0]);
        this.name = values[1];
        this.cost = Integer.parseInt(values[2]);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getCost() {
        return cost;
    }

    public abstract String[] getRent(Player player,ArrayList<Property> properties,ArrayList<Player> players,String dice);
    public int getRent(){
        return rent;
    }

    public void setRent(int rent) {
        this.rent = rent;
    }

    public String getSituation() {
        return situation;
    }

    public void setSituation(String situation) {
        this.situation = situation;
    }
    public String[] can_buy(Player player, Banker banker, String dice, ArrayList<Player> players){
        String write = "";
        String cont = "true";
        if (getSituation().equals("sale")){
            if (player.getMoney() >= getCost()){
                setSituation(player.getName());
                player.setMoneyMinus(getCost());
                player.setProperties_list(getName());
                banker.setBank_money_plus(getCost());
                write = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " bought" + " " + getName() + "\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < getCost()){
                write = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
        }
        else if (getSituation().equals(player.getName())){
            write = player.getName() + "\t" + dice + "\t" +
                    player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                    " has" + " " + getName()+ "\n";
        }
        return new String[]{write,cont};
    }
}
