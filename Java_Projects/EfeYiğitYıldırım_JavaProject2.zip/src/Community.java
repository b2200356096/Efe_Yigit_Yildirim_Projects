import java.util.ArrayList;

public class Community extends Card{
    public Community(String definiton) {
        super(definiton);
    }
    public String[] what_card(String change_return_definition, Player player, Banker banker, ArrayList<Community> community,
                            ArrayList<Player> players, String dice) {
        String writen = "";
        String cont = "true";
        if (change_return_definition.equals("Advance to Go (Collect $200)")){
            player.location_move_to(1);
            player.setMoneyPlus(200);banker.setBank_money_minus(200);
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
            writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                    players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                    "advance to go (collect 200)\n";
        }
        else if (change_return_definition.equals("Bank error in your favor - collect $75")){
            player.setMoneyPlus(75);banker.setBank_money_minus(75);
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
            writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                    players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                    "Bank error in your favor - collect $75\n";
        }
        else if (change_return_definition.equals("Doctor's fees - Pay $50")){
            if (player.getMoney() >= 50){
                player.setMoneyMinus(50);banker.setBank_money_plus(50);
                writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                        "Doctor's fees - Pay $50\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < 50){
                writen = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
        }
        else if (change_return_definition.equals("It is your birthday Collect $10 from each player")){
            if (player.getName().equals(players.get(0).getName())){
                if (players.get(1).getMoney() >= 10){
                    player.setMoneyPlus(10);players.get(1).setMoneyMinus(10);
                    writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                            players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                            "It is your birthday Collect $10 from each player\n";
                    if (players.get(1).getMoney() == 0){
                        cont = "false";
                    }
                }
                else if (players.get(1).getMoney() < 10){
                    writen = players.get(1).getName() + "\t" + dice + "\t" +
                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + players.get(1).getName() +
                            " goes bankrupts\n";
                    cont = "false";
                }
            }
            else if (player.getName().equals(players.get(1).getName())){
                if (players.get(0).getMoney() >= 10){
                    player.setMoneyPlus(10);players.get(0).setMoneyMinus(10);
                    writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                            players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                            "It is your birthday Collect $10 from each player\n";
                    if (players.get(0).getMoney() == 0){
                        cont = "false";
                    }
                }
                else if (players.get(0).getMoney() < 10){
                    writen = players.get(0).getName() + "\t" + dice + "\t" +
                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + players.get(0).getName() +
                            " goes bankrupts\n";
                    cont = "false";
                }
            }
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
        }
        else if (change_return_definition.equals("Grand Opera Night - collect $50 from every player for opening night seats")){
            if (player.getName().equals(players.get(0).getName())){
                if (players.get(1).getMoney() >= 50){
                    player.setMoneyPlus(50);players.get(1).setMoneyMinus(50);
                    writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                            players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                            "Grand Opera Night - collect $50 from every player\n";
                    if (players.get(1).getMoney() == 0){
                        cont = "false";
                    }
                }
                else if (players.get(1).getMoney() < 50){
                    writen = players.get(1).getName() + "\t" + dice + "\t" +
                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + players.get(1).getName() +
                            " goes bankrupts\n";
                    cont = "false";
                }
            }
            else if (player.getName().equals(players.get(1).getName())){
                if (players.get(0).getMoney() >= 50){
                    player.setMoneyPlus(50);players.get(0).setMoneyMinus(50);
                    writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                            players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                            "Grand Opera Night - collect $50 from every player\n";
                    if (players.get(0).getMoney() == 0){
                        cont = "false";
                    }
                }
                else if (players.get(0).getMoney() < 50){
                    writen = players.get(0).getName() + "\t" + dice + "\t" +
                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + players.get(0).getName() +
                            " goes bankrupts\n";
                    cont = "false";
                }
            }
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
        }
        else if (change_return_definition.equals("Income Tax refund - collect $20")){
            player.setMoneyPlus(20);banker.setBank_money_minus(20);
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
            writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                    players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                    "Income Tax refund - collect $20\n";
        }
        else if (change_return_definition.equals("Life Insurance Matures - collect $100")){
            player.setMoneyPlus(100);banker.setBank_money_minus(100);
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
            writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                    players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                    "Life Insurance Matures - collect $100\n";
        }
        else if (change_return_definition.equals("Pay Hospital Fees of $100")){
            if (player.getMoney() >= 100){
                player.setMoneyMinus(100);banker.setBank_money_plus(100);
                writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                        "Pay Hospital Fees of $100\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < 100){
                writen = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
        }
        else if (change_return_definition.equals("Pay School Fees of $50")){
            if (player.getMoney() >= 50){
                player.setMoneyMinus(50);banker.setBank_money_plus(50);
                writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                        "Pay School Fees of $50\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < 50){
                writen = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
        }
        else if (change_return_definition.equals("You inherit $100")){
            player.setMoneyPlus(100);banker.setBank_money_minus(100);
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
            writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                    players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                    "You inherit $100\n";
        }
        else if (change_return_definition.equals("From sale of stock you get $50")){
            player.setMoneyPlus(50);banker.setBank_money_minus(50);
            community.remove(community.get(0));
            community.add(new Community(change_return_definition));
            writen = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                    players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                    "From sale of stock you get $50\n";
        }
        return new String[]{writen,cont};
    }

}
