import java.util.ArrayList;

public class Chance extends Card{

    public Chance(String definiton) {
        super(definiton);
    }
    public String[] what_card(String change_return_definition, Player player, Banker banker,
                              ArrayList<Player> players, String dice,ArrayList<Community> communities,ArrayList<Property> properties,
                            ArrayList<Chance> chanceList) {
        String writed = "";
        String cont = "true";
        if (change_return_definition.equals("Advance to Go (Collect $200)")){
            player.location_move_to(1);
            player.setMoneyPlus(200);
            banker.setBank_money_minus(200);
            chanceList.remove(chanceList.get(0));
            chanceList.add(new Chance(change_return_definition));
            writed = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                    players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                    "advance to go (collect 200)\n";
        }
        else if (change_return_definition.equals("Advance to Leicester Square")){
            if (player.getLocation() > 27){
                player.setMoneyPlus(200);
                banker.setBank_money_minus(200);
            }
            player.location_move_to(27);
            for (Property b : properties){
                if (b.getId() == 27){
                    if ((b.getSituation().equals("sale")) || (b.getSituation().equals(player.getName()))){
                        if (b.getSituation().equals("sale")){
                            if (player.getMoney() >= b.getCost()){
                                b.setSituation(player.getName());
                                player.setMoneyMinus(b.getCost());
                                player.setProperties_list(b.getName());
                                banker.setBank_money_plus(b.getCost());
                                writed = player.getName() + "\t" + dice + "\t" +
                                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                                        " draw Advance to Leicester Square "+player.getName() + " bought Leicester Square\n";
                                if (player.getMoney() == 0){
                                    cont = "false";
                                }
                            }
                            else if (player.getMoney() < b.getCost()){
                                writed = player.getName() + "\t" + dice + "\t" +
                                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t"+ player.getName() +
                                        " goes bankrupts\n";
                                cont = "false";
                            }
                        }
                        else if (b.getSituation().equals(player.getName())){
                            writed = player.getName() + "\t" + dice + "\t" +
                                    player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                                    " draw Advance to Leicester Square "+ player.getName() +
                                    " has" + " " + b.getName()+ "\n";
                        }
                    }
                    else {
                        if (player.getName().equals(players.get(0).getName())){
                            if (player.getMoney() >= b.getRent()){
                                player.setMoneyMinus(b.getRent());
                                players.get(1).setMoneyPlus(b.getRent());
                                writed = player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName()+
                                        " "+"paid rent for " + b.getName() + "\n";
                                if (player.getMoney() == 0){
                                    cont = "false";
                                }
                            }
                            else if (player.getMoney() < b.getRent()){
                                writed = player.getName() + "\t" + dice + "\t" +
                                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                                        " goes bankrupts\n";
                                cont = "false";
                            }
                        }
                        else if (player.getName().equals(players.get(1).getName())){
                            if (player.getMoney() >= b.getRent()){
                                player.setMoneyMinus(b.getRent());
                                players.get(0).setMoneyPlus(b.getRent());
                                writed = player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName()+
                                        " "+"paid rent for " + b.getName() + "\n";
                                if (player.getMoney() == 0){
                                    cont = "false";
                                }
                            }
                            else if (player.getMoney() < b.getRent()){
                                writed = player.getName() + "\t" + dice + "\t" +
                                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                                        " goes bankrupts\n";
                                cont = "false";
                            }
                        }
                    }
                }
            }
            chanceList.remove(chanceList.get(0));
            chanceList.add(new Chance(change_return_definition));
        }
        else if (change_return_definition.equals("Go back 3 spaces")){
            int new_location = player.getLocation() - 3;
            if (new_location == 5){
                player.location_move_to(new_location);
                if (player.getMoney() >= 100){
                    player.setMoneyMinus(100);
                    banker.setBank_money_plus(100);
                    writed = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                            players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                            "Go back 3 spaces pay tax\n";
                    if (player.getMoney() == 0){
                        cont = "false";
                    }
                }
                else if (player.getMoney() < 100){
                    writed = player.getName() + "\t" + dice + "\t" +
                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                            " goes bankrupts\n";
                    cont = "false";
                }
            }
            else if (new_location == 20){
                player.location_move_to(20);
                for (Property b : properties){
                    if (b.getId() == 20){
                        if ((b.getSituation().equals("sale")) || (b.getSituation().equals(player.getName()))){
                            if (b.getSituation().equals("sale")){
                                if (player.getMoney() >= b.getCost()){
                                    b.setSituation(player.getName());
                                    player.setMoneyMinus(b.getCost());
                                    player.setProperties_list(b.getName());
                                    banker.setBank_money_plus(b.getCost());
                                    writed = player.getName() + "\t" + dice + "\t" +
                                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() + " draw Go back 3 spaces" + player.getName() +
                                            " bought" + " " + b.getName() + "\n";
                                    if (player.getMoney() == 0){
                                        cont = "false";
                                    }
                                }
                                else if (player.getMoney() < b.getCost()){
                                    writed = player.getName() + "\t" + dice + "\t" +
                                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                                            " goes bankrupts\n";
                                    cont = "false";
                                }
                            }
                            else if (b.getSituation().equals(player.getName())){
                                writed = player.getName() + "\t" + dice + "\t" +
                                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() + " draw Go back 3 spaces" + player.getName() +
                                        " has" + " " + b.getName() + "\n";
                            }
                        }
                        else {
                            if (player.getName().equals(players.get(0).getName())){
                                if (player.getMoney() >= b.getRent()){
                                    player.setMoneyMinus(b.getRent());
                                    players.get(1).setMoneyPlus(b.getRent());
                                    writed = player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                                            players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() + " draw Go back 3 spaces" +player.getName()+
                                            " "+"paid rent for " + b.getName() + "\n";
                                    if (player.getMoney() == 0){
                                        cont = "false";
                                    }
                                }
                                else if (player.getMoney() < b.getRent()){
                                    writed = player.getName() + "\t" + dice + "\t" +
                                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                                            " goes bankrupts\n";
                                    cont = "false";
                                }
                            }
                            else if (player.getName().equals(players.get(1).getName())){
                                if (player.getMoney() >= b.getRent()){
                                    player.setMoneyMinus(b.getRent());
                                    players.get(0).setMoneyPlus(b.getRent());
                                    writed = player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                                            players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName() + " draw Go back 3 spaces" +player.getName()+
                                            " "+"paid rent for " + b.getName() + "\n";
                                    if (player.getMoney() == 0){
                                        cont = "false";
                                    }
                                }
                                else if (player.getMoney() < b.getRent()){
                                    writed = player.getName() + "\t" + dice + "\t" +
                                            player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                                            " goes bankrupts\n";
                                    cont = "false";
                                }
                            }
                        }
                    }
                }
            }
            else if (new_location == 34){
                player.location_move_to(34);
                String def = communities.get(0).getDefiniton();
                Community temp = new Community(def);
                String[] write_list = temp.what_card(def,player,banker,communities,players,dice);
                writed = write_list[0];
                cont = write_list[1];
            }
            chanceList.remove(chanceList.get(0));
            chanceList.add(new Chance(change_return_definition));
        }
        else if (change_return_definition.equals("Pay poor tax of $15")){
            if (player.getMoney() >= 15){
                player.setMoneyMinus(15);
                banker.setBank_money_plus(15);
                writed = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                        "Pay poor tax of $15\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < 15){
                writed = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
            chanceList.remove(chanceList.get(0));
            chanceList.add(new Chance(change_return_definition));
        }
        else if (change_return_definition.equals("Your building loan matures - collect $150")){
            player.setMoneyPlus(150);
            banker.setBank_money_minus(150);
            chanceList.remove(chanceList.get(0));
            chanceList.add(new Chance(change_return_definition));
            writed = player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                    players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+ player.getName() +" "+
                    "Your building loan matures - collect $150\n";
        }
        else if (change_return_definition.equals("You have won a crossword competition - collect $100 ")){
            player.setMoneyPlus(100);
            banker.setBank_money_minus(100);
            chanceList.remove(chanceList.get(0));
            chanceList.add(new Chance(change_return_definition));
            writed = player.getName()+" "+dice+" "+player.getLocation()+" "+
                    players.get(0).getMoney()+" "+players.get(1).getMoney()+" "+ player.getName() +" "+
                    "You have won a crossword competition - collect $100 ";
        }
        return new String[]{writed,cont};
    }
}
