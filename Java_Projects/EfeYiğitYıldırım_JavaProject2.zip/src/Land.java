import java.util.ArrayList;

public class Land  extends Property{
    public Land(String[] values) {
        super(values);
        setProperty_type("land");
        if (getCost() < 2000){
            setRent(getCost() * 4 / 10);
        }
        else if ((getCost() < 3000) && (getCost() >= 2000)){
            setRent(getCost() * 3 /10);
        }
        else if ((getCost() <= 4000) && (getCost() >= 3000)){
            setRent(getCost() * 35 / 100);
        }
    }

    @Override
    public String[] getRent(Player player, ArrayList<Property> properties, ArrayList<Player> players, String dice) {
        String write = "";
        String cont = "true";
        if (player.getName().equals(players.get(0).getName())){
            if (player.getMoney() >= getRent()){
                player.setMoneyMinus(getRent());
                players.get(1).setMoneyPlus(getRent());
                write = player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName()+
                        " "+"paid rent for " + getName() + "\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < getRent()){
                write = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
        }
        else if (player.getName().equals(players.get(1).getName())){
            if (player.getMoney() >= getRent()){
                player.setMoneyMinus(getRent());
                players.get(0).setMoneyPlus(getRent());
                write = player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName()+
                        " "+"paid rent for " + getName() + "\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < getRent()){
                write = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
        }
        return new String[]{write,cont};
    }
}
