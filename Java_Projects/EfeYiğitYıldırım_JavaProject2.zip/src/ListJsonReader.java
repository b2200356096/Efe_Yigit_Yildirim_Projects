import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

public class ListJsonReader {
    public static ArrayList<Community> community_list = new ArrayList<>();
    public static ArrayList<Chance> chance_list = new ArrayList<>();

    public static ArrayList<Community> getCommunity_list() {
        return community_list;
    }

    public static ArrayList<Chance> getChance_list() {
        return chance_list;
    }

    public ListJsonReader(){
        JSONParser processor = new JSONParser();
        try (Reader file = new FileReader("list.json")){
            JSONObject jsonfile = (JSONObject) processor.parse(file);
            JSONArray chanceList = (JSONArray) jsonfile.get("chanceList");
            for(Object i:chanceList){
                String a = ((String)((JSONObject)i).get("item"));
                chance_list.add(new Chance(a));
            }
            JSONArray communityChestList = (JSONArray) jsonfile.get("communityChestList");
            for(Object i:communityChestList){
                String b = ((String)((JSONObject)i).get("item"));
                community_list.add(new Community(b));
            }
        }catch (IOException e){
            e.printStackTrace();
        }catch (ParseException e){
            e.printStackTrace();
        }
    }
}
