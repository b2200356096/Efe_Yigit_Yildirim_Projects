import java.util.ArrayList;

public class Railroad extends Property {
    public Railroad(String[] values){
        super(values);
        setProperty_type("railroad");
    }

    @Override
    public String[] getRent(Player player, ArrayList<Property> properties, ArrayList<Player> players, String dice) {
        String write = "";
        String cont = "true";
        int number_of_owned = 0;
        if (player.getName().equals(players.get(0).getName())){
            for (Property c : properties){
                if (c.getSituation().equals(players.get(1).getName())) {
                    number_of_owned++;
                }
            }
            if (player.getMoney() >= (25 * number_of_owned)){
                player.setMoneyMinus(25 * number_of_owned);
                players.get(1).setMoneyPlus(25 * number_of_owned);
                write = player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName()+
                        " "+"paid rent for " + getName() + "\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < (25 * number_of_owned)){
                write = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
        }
        else if (player.getName().equals(players.get(1).getName())){
            for (Property c : properties){
                if (c.getSituation().equals(players.get(0).getName())) {
                    number_of_owned++;
                }
            }
            if (player.getMoney() >= (25 * number_of_owned)){
                player.setMoneyMinus(25 * number_of_owned);
                players.get(0).setMoneyPlus(25 * number_of_owned);
                write = player.getName()+"\t"+dice+"\t"+player.getLocation()+ "\t" +
                        players.get(0).getMoney()+"\t"+players.get(1).getMoney()+"\t"+player.getName()+
                        " "+"paid rent for " + getName() + "\n";
                if (player.getMoney() == 0){
                    cont = "false";
                }
            }
            else if (player.getMoney() < (25 * number_of_owned)){
                write = player.getName() + "\t" + dice + "\t" +
                        player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                        " goes bankrupts\n";
                cont = "false";
            }
        }
        return new String[]{write,cont};
    }
}
