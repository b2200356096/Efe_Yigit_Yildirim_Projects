import java.io.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws IOException {
        PropertyJsonReader propertyJsonReader = new PropertyJsonReader();
        ArrayList<Property> properties_main = PropertyJsonReader.getProperties();
        ArrayList<Integer> properties_main_nums = new ArrayList<>();
        ArrayList<Integer> lands_nums_main = PropertyJsonReader.getLands_nums();
        ArrayList<Integer> railroads_nums = new ArrayList<>();
        railroads_nums.add(6);railroads_nums.add(16);railroads_nums.add(26);railroads_nums.add(36);
        ArrayList<Integer> companies_nums = new ArrayList<>();
        companies_nums.add(13);companies_nums.add(29);
        ArrayList<Integer> community_locations = new ArrayList<>();
        community_locations.add(3);community_locations.add(18);community_locations.add(34);
        ArrayList<Integer> chance_locations = new ArrayList<>();
        chance_locations.add(8);chance_locations.add(23);chance_locations.add(37);
        for (Property c : properties_main){
            properties_main_nums.add(c.getId());
        }
        ListJsonReader listJsonReader = new ListJsonReader();
        ArrayList<Community> community_main = ListJsonReader.getCommunity_list();
        ArrayList<Chance> chance_main = ListJsonReader.getChance_list();
        Banker banker = new Banker();
        File monitoring = new File("monitoring.txt");
        if (!monitoring.exists()){
            monitoring.createNewFile();
        }
        FileWriter m_writer = new FileWriter(monitoring, false);
        BufferedWriter bm_writer = new BufferedWriter(m_writer);
        File command = new File(args[0]);
        FileReader fileReader = new FileReader(command);
        BufferedReader bf_reader = new BufferedReader(fileReader);
        String c_each_line;
        ArrayList<String> command_list = new ArrayList<>();
        ArrayList<Player> players = new ArrayList<>();
        while ((c_each_line = bf_reader.readLine()) != null){
            command_list.add(c_each_line);
        }
        players.add(new Player("Player 1"));
        players.add(new Player("Player 2"));
        String control = "true";
        for (String m : command_list){
            if (control.equals("true")){
                if (m.equals("show()")){
                    bm_writer.write("------------------------------------------------------------------------------------------------------------\n");
                    for (Player player_show : players){
                        bm_writer.write(player_show.getName() + "\t" + player_show.getMoney() + "\t");
                        if (player_show.getProperties_list().size() == 0){
                            bm_writer.write("have: \n");
                        }
                        else {
                            bm_writer.write("have: ");
                            for (int i = 0;i < player_show.getProperties_list().size();i++){
                                if (i < (player_show.getProperties_list().size() - 1 )){
                                    bm_writer.write(player_show.getProperties_list().get(i) + ",");
                                }
                                else {
                                    bm_writer.write(player_show.getProperties_list().get(i) + "\n");
                                }
                            }
                        }
                    }
                    bm_writer.write(banker.getBanker_name() + "\t" + banker.getBank_money() + "\n");
                    if (players.get(0).getMoney() > players.get(1).getMoney()){
                        bm_writer.write("Winner Player 1\n");
                    }
                    else {
                        bm_writer.write("Winner Player 2\n");
                    }
                    bm_writer.write("------------------------------------------------------------------------------------------------------------\n");
                }
                else {
                    String[] parted = m.split(";");
                    String temp_name = parted[0];
                    String dice = parted[1];
                    for (Player player : players){
                        if (player.getName().equals(temp_name)){
                            if (player.getJail().equals("yes")){
                                bm_writer.write(player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+players.get(0).getMoney()+
                                        "\t"+players.get(1).getMoney()+"\t"+player.getName()+ " in jail "+
                                        "(count="+player.getJail_count()+")\n");
                                player.setJail_count();
                                if (player.getJail_count() == 4){
                                    player.setJail("not");
                                    player.setJail_count_one();
                                }
                            }
                            else if (player.getFree_park().equals("yes")){
                                player.setFree_park("not");
                                bm_writer.write(player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                                        players.get(0).getMoney() +"\t"+players.get(1).getMoney()+"\t"+player.getName()+" is in Free Parking\n");
                            }
                            else {
                                if (((player.getLocation() + Integer.parseInt(dice)) > 40) && (((player.getLocation() + Integer.parseInt(dice)) % 40) != 1)){
                                    player.setMoneyPlus(200);banker.setBank_money_minus(200);
                                }
                                player.setLocation(Integer.parseInt(dice));
                                if (player.getLocation() == 11){
                                    bm_writer.write(player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+players.get(0).getMoney()+ "\t"+players.get(1).getMoney()+"\t"+player.getName()+" "+"went to jail\n");
                                    player.setJail("yes");
                                }
                                else if (player.getLocation() == 21){
                                    player.setFree_park("yes");
                                    bm_writer.write(player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+
                                            players.get(0).getMoney() +"\t"+players.get(1).getMoney()+"\t"+player.getName()+" is in Free Parking\n");
                                }
                                else if (player.getLocation() == 31){
                                    player.location_move_to(11);
                                    bm_writer.write(player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+players.get(0).getMoney()+ "\t"+players.get(1).getMoney()+"\t"+player.getName()+" "+"went to jail\n");
                                    player.setJail("yes");
                                }
                                else if (player.getLocation() == 1){
                                    player.setMoneyPlus(200);banker.setBank_money_minus(200);
                                    bm_writer.write(player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+players.get(0).getMoney()+ "\t"+players.get(1).getMoney()+"\t"+player.getName()+" is in GO square\n");
                                }
                                else if ((player.getLocation() == 5) || (player.getLocation() == 39)){
                                    if (player.getMoney() >= 100){
                                        player.setMoneyMinus(100);banker.setBank_money_plus(100);
                                        bm_writer.write(player.getName()+"\t"+dice+"\t"+player.getLocation()+"\t"+players.get(0).getMoney()+ "\t"+players.get(1).getMoney()+"\t"+player.getName()+" paid Tax\n");
                                        if (player.getMoney() == 0){
                                            control = "false";
                                        }
                                    }
                                    else if (player.getMoney() < 100){
                                        bm_writer.write(player.getName() + "\t" + dice + "\t" +
                                                player.getLocation() + "\t" + players.get(0).getMoney() + "\t" + players.get(1).getMoney() + "\t" + player.getName() +
                                                " goes bankrupts\n");
                                        control = "false";
                                    }
                                }
                                else if (properties_main_nums.contains(player.getLocation())){
                                    if (railroads_nums.contains(player.getLocation())) {
                                        for (Property b : properties_main) {
                                            if (b.getId() == player.getLocation()) {
                                                if ((b.getSituation().equals("sale")) || (b.getSituation().equals(player.getName()))) {
                                                    String[] wite = b.can_buy(player,banker,dice,players);
                                                    bm_writer.write(wite[0]);
                                                    control = wite[1];
                                                }
                                                else {
                                                    String[] wite = b.getRent(player,properties_main,players,dice);
                                                    bm_writer.write(wite[0]);
                                                    control = wite[1];
                                                }
                                            }
                                        }
                                    }
                                    else if (companies_nums.contains(player.getLocation())){
                                        for (Property b : properties_main){
                                            if (b.getId() == player.getLocation()){
                                                if ((b.getSituation().equals("sale")) || (b.getSituation().equals(player.getName()))){
                                                    String[] wite = b.can_buy(player,banker,dice,players);
                                                    bm_writer.write(wite[0]);
                                                    control = wite[1];
                                                }
                                                else {
                                                    String[] wite = b.getRent(player,properties_main,players,dice);
                                                    bm_writer.write(wite[0]);
                                                    control = wite[1];
                                                }
                                            }
                                        }
                                    }
                                    else if (lands_nums_main.contains(player.getLocation())){
                                        for (Property b : properties_main){
                                            if (b.getId() == player.getLocation()){
                                                if ((b.getSituation().equals("sale")) || (b.getSituation().equals(player.getName()))){
                                                    String[] wite = b.can_buy(player,banker,dice,players);
                                                    bm_writer.write(wite[0]);
                                                    control = wite[1];
                                                }
                                                else {
                                                    String[] wite = b.getRent(player,properties_main,players,dice);
                                                    bm_writer.write(wite[0]);
                                                    control = wite[1];
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (chance_locations.contains(player.getLocation())){
                                    String temp_definition = chance_main.get(0).getDefiniton();
                                    String[] write_ple = new Chance(temp_definition).what_card(temp_definition,player,banker,players,dice,community_main,properties_main,chance_main);
                                    bm_writer.write(write_ple[0]);
                                    control = write_ple[1];
                                }
                                else if (community_locations.contains(player.getLocation())){
                                    String defi = community_main.get(0).getDefiniton();
                                    String[] write_pls = new Community(defi).what_card(defi,player,banker,community_main,players,dice);
                                    bm_writer.write(write_pls[0]);
                                    control = write_pls[1];
                                }
                            }
                        }
                    }
                }
            }
        }
        bm_writer.write("------------------------------------------------------------------------------------------------------------\n");
        for (Player player_show : players){
            bm_writer.write(player_show.getName() + "\t" + player_show.getMoney() + "\t");
            if (player_show.getProperties_list().size() == 0){
                bm_writer.write("have: \n");
            }
            else {
                bm_writer.write("have: ");
                for (int i = 0;i < player_show.getProperties_list().size();i++){
                    if (i < (player_show.getProperties_list().size() - 1 )){
                        bm_writer.write(player_show.getProperties_list().get(i) + ",");
                    }
                    else {
                        bm_writer.write(player_show.getProperties_list().get(i) + "\n");
                    }
                }
            }
        }
        bm_writer.write(banker.getBanker_name() + "\t" + banker.getBank_money() + "\n");
        if (players.get(0).getMoney() > players.get(1).getMoney()){
            bm_writer.write("Winner Player 1\n");
        }
        else {
            bm_writer.write("Winner Player 2\n");
        }
        bm_writer.write("------------------------------------------------------------------------------------------------------------");
        bf_reader.close();bm_writer.close();
    }
}
