import java.util.ArrayList;

public class Card {
    private String definiton;
    public Card(String definiton){
        this.definiton = definiton;
    }
    public String getDefiniton() {
        return definiton;
    }
}
