public class Banker {
    private String banker_name = "Banker";
    private int bank_money = 100000;

    public String getBanker_name() {
        return banker_name;
    }

    public int getBank_money() {
        return bank_money;
    }

    public void setBank_money_plus(int bank_money_plus) {
        this.bank_money += bank_money_plus;
    }
    public void setBank_money_minus(int bank_money_minus){
        this.bank_money -= bank_money_minus;
    }
}
