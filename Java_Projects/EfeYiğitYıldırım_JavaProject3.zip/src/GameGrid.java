import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class GameGrid {
    public ArrayList<ArrayList<Jewel>> jewels_list = new ArrayList<>();
    public ArrayList<Player> players = new ArrayList<>();
    public static HashSet<String> math_list = new HashSet<>();
    int size = 0;int location_of_player = 0;
    public static int score_sum = 0;public static int real_score = 0;
    GameGrid(String s) throws IOException {
        File grid1 = new File(s);
        FileReader grid_reader = new FileReader(grid1);
        BufferedReader buff_grid_reader = new BufferedReader(grid_reader);
        String each_line;
        while ((each_line = buff_grid_reader.readLine()) != null){
            String[] temp_list = each_line.split(" ");
            this.size = temp_list.length - 1;
            ArrayList<Jewel> temp_array_list = new ArrayList<>();
            for (String string : temp_list){
                if (string.equals("D")){
                    Jewel jewel = new Diamond("D",30);
                    temp_array_list.add(jewel);
                }
                else if (string.equals("S")){
                    Jewel jewel = new Square("S",15);
                    temp_array_list.add(jewel);
                }
                else if (string.equals("T")){
                    Jewel jewel = new Triangle("T",15);
                    temp_array_list.add(jewel);
                }
                else if (string.equals("W")){
                    Jewel jewel = new Wildcard("W",10);
                    temp_array_list.add(jewel);
                }
                // new letters can be added to here by creating a new else if block
                else {
                    if (string.equals("\\")){
                        // there is a special if clause because we can not read "\" directly
                        Jewel jewel = new Math("\\",20);
                        temp_array_list.add(jewel);
                        math_list.add("\\");
                    }
                    else {
                        Jewel jewel = new Math(string,20);
                        temp_array_list.add(jewel);
                        math_list.add(string);
                    }
                }
            }
            this.jewels_list.add(temp_array_list);
        }
    }
    public void gridCleaner(){
        for (int i = 0; i < jewels_list.size();i++){
            for (int j = 0; j < jewels_list.size(); j++){
                if (jewels_list.get(i).get(j).getName().equals(" ")){
                    Jewel empty = new Empty(" ",0);
                    jewels_list.get(i).set(j,empty);
                }
            }
        }
        for (ArrayList<Jewel> jewelArrayList : jewels_list){
            for (int i = 0; i < jewelArrayList.size(); i++){
                for (int j = 0; j < jewels_list.size();j++){
                    try {
                        if ((!(jewels_list.get(j).get(i).getName().equals(" "))) && (jewels_list.get(j+1).get(i).getName().equals(" "))){
                            Jewel temp_up = jewels_list.get(j).get(i);
                            Jewel empty = new Empty(" ",0);
                            jewels_list.get(j).set(i,empty);
                            jewels_list.get(j+1).set(i,temp_up);
                        }
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException){
                        int x = 5;
                    }
                }
            }
        }
    }
    public void player_sorter_writer(String name) throws IOException {
        File leaderboard = new File("leaderboard.txt");
        FileReader fileReader = new FileReader(leaderboard);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        File writer = new File("leaderboard.txt");
        if (!(writer.exists())){
            writer.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(writer,true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        String line;
        while ((line = bufferedReader.readLine()) != null){
            String[] parts = line.split(" ");
            players.add(new Player(parts[1],parts[0]));
        }
        Player our_player = new Player(Integer.toString(real_score),name);
        players.add(our_player);
        bufferedWriter.write("\n" + our_player.getName() + " " + our_player.getScore());
        Collections.sort(players);
        Collections.reverse(players);
        this.location_of_player = Collections.binarySearch(players,our_player,Collections.reverseOrder()) + 1;
        bufferedReader.close();
        bufferedWriter.close();
    }
    public void take_action(String commands) throws IOException {
        File command = new File(commands);
        FileReader command_reader = new FileReader(command);
        BufferedReader buff_command_reader = new BufferedReader(command_reader);
        File writer_show = new File("monitoring.txt");
        if (!(writer_show.exists())){
            writer_show.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(writer_show,false);
        BufferedWriter buff = new BufferedWriter(fileWriter);
        String command_line;
        ArrayList<String[]> commands_array = new ArrayList<>();
        while ((command_line = buff_command_reader.readLine()) != null){
            String[] parted = command_line.split(" ");
            commands_array.add(parted);
        }
        boolean check = true;
        buff.write("Game Grid:\n\n");
        for (ArrayList<Jewel> jewelArrayList : jewels_list){
            for (Jewel jewel : jewelArrayList){
                buff.write(jewel.getName() + " ");
            }
            buff.write("\n");
        }
        buff.write("\n");
        for (int z = 0;z < commands_array.size();z++){
            if (check){
                if (commands_array.get(z)[0].equals("E")){
                    buff.write("Select coordinate or enter E to end the game: " + commands_array.get(z)[0] + "\n\n");
                    buff.write("Total score: " + real_score + " points" +  "\n\n");
                    buff.write("Enter name: " + commands_array.get(z + 1)[0] + "\n\n");
                    player_sorter_writer(commands_array.get(z + 1)[0]);
                    // next if block looks for where is our player in the sorted ArrayList and writes according to that
                    if (location_of_player == 1){
                        int difference = players.get(0).getScore() - players.get(1).getScore();
                        buff.write("Your rank is " + location_of_player + "/" + players.size() + " your score is " + difference + " points higher than " + players.get(1).getName() + "\n\n");
                        buff.write("Good Bye!");
                    }
                    else if (location_of_player == players.size()){
                        int difference = players.get(location_of_player - 2).getScore() - players.get(location_of_player - 1).getScore();
                        buff.write("Your rank is " + location_of_player + "/" + players.size() + " your score is " + difference + " points lower than " + players.get(location_of_player - 2 ).getName() + "\n\n");
                        buff.write("Good Bye!");
                    }
                    else {
                        int difference_up = players.get(location_of_player - 2).getScore() - players.get(location_of_player - 1).getScore();
                        int difference_down = players.get(location_of_player - 1).getScore() - players.get(location_of_player).getScore();
                        buff.write("Your rank is " + location_of_player + "/" + players.size() + " your score is " + difference_up +
                                " points lower than " + players.get(location_of_player - 2).getName() + " and " + difference_down + " points higher than " + players.get(location_of_player).getName() + "\n\n");
                        buff.write("Good Bye!");
                    }
                    check = false;
                }
                else {
                    int len = Integer.parseInt(commands_array.get(z)[0]);
                    int size = Integer.parseInt(commands_array.get(z)[1]);
                    score_sum = 0;
                    // This is our real action part that we make explosions according to the indexes that are given
                    try {
                        if (!(jewels_list.get(len).get(size).getName().equals(" "))){
                            buff.write("Select coordinate or enter E to end the game: " + Integer.toString(len) + " " + Integer.toString(size) + "\n\n");
                            if (!(math_list.contains(jewels_list.get(len).get(size).getName()))){
                                jewels_list.get(len).get(size).action(jewels_list,len,size);
                                gridCleaner();
                                for (ArrayList<Jewel> jewelArrayList : jewels_list){
                                    for (Jewel jewel : jewelArrayList){
                                        buff.write(jewel.getName() + " ");
                                    }
                                    buff.write("\n");
                                }
                                buff.write("\n");
                                buff.write("Score: " + score_sum + " points" + "\n\n");
                                real_score += score_sum;
                            }
                            else {
                                jewels_list.get(len).get(size).action(jewels_list,len,size);
                                gridCleaner();
                                for (ArrayList<Jewel> jewelArrayList : jewels_list){
                                    for (Jewel jewel : jewelArrayList){
                                        buff.write(jewel.getName() + " ");
                                    }
                                    buff.write("\n");
                                }
                                buff.write("\n");
                                buff.write("Score: " + score_sum + " points" + "\n\n");
                                real_score += score_sum;
                            }
                        }
                        else{
                            buff.write("Select coordinate or enter E to end the game: " + Integer.toString(len) + " " + Integer.toString(size) + "\n\n");
                            buff.write("Please enter a valid coordinate\n\n");
                        }
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException){
                        buff.write("Select coordinate or enter E to end the game: " + Integer.toString(len) + " " + Integer.toString(size) + "\n\n");
                        buff.write("Please enter a valid coordinate\n\n");
                    }
                }
            }
        }
        buff_command_reader.close();
        buff.close();
    }
}
