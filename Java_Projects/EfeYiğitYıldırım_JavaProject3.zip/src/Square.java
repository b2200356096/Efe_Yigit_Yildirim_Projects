import java.util.ArrayList;

public class Square extends Jewel{
    Square(String name, int score) {
        super(name, score);
    }
    @Override
    public void action(ArrayList<ArrayList<Jewel>> jewel_list, int len, int size) {
        left_right_checker(jewel_list,len,size);
    }
}
