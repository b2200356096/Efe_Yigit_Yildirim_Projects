import java.util.ArrayList;

public class Diamond extends Jewel{
    Diamond(String name, int score) {
        super(name, score);
    }
    @Override
    public void action(ArrayList<ArrayList<Jewel>> jewel_list, int len, int size) {
        diagonal_checker(jewel_list,len,size);
    }
}
