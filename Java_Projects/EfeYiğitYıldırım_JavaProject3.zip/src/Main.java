import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        GameGrid gameGrid = new GameGrid(args[0]);
        gameGrid.take_action(args[1]);
    }
}
