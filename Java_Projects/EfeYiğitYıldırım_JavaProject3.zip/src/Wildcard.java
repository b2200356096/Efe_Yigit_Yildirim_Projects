import java.util.ArrayList;

public class Wildcard extends Jewel{
    Wildcard(String name, int score) {
        super(name, score);
    }

    @Override
    public void action(ArrayList<ArrayList<Jewel>> jewel_list, int len, int size) {
        up_down_checker(jewel_list,len,size);
        if (jewel_list.get(len).get(size).getName().equals("W")){
            left_right_checker(jewel_list,len,size);
        }
        if (jewel_list.get(len).get(size).getName().equals("W")){
            diagonal_checker(jewel_list,len,size);
        }
    }
}
