public class Player implements Comparable<Player> {
    private int score = 0;
    private String name;

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    Player(String score, String name){
        this.score = Integer.parseInt(score);
        this.name = name;
    }
    @Override
    public int compareTo(Player o) {
        if (this.score > o.getScore()){
            return 1;
        }
        else if (this.score == o.getScore()){
            return 0;
        }
        else {
            return -1;
        }
    }
}
