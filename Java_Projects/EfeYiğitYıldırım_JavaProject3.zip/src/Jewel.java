import java.util.ArrayList;
import java.util.HashSet;

public abstract class Jewel {
    private String name;
    private int score;
    Jewel(String name,int score){
        this.name = name;
        this.score = score;
    }
    public String getName() {
        return name;
    }
    // The method we use for math symbols. It has the same logic with up_down_checker but not the same algorithm.
    public void math_up_down(ArrayList<ArrayList<Jewel>> jewel_list, int len, int size, HashSet<String> set){
        if (!(jewel_list.get(len).get(size).getName().equals(" "))){
            try {
                if ((set.contains(jewel_list.get(len - 1).get(size).getName())) && (set.contains(jewel_list.get(len - 2).get(size).getName()))){
                    GameGrid.score_sum += 60;
                    jewel_list.get(len).get(size).setName(" ");
                    jewel_list.get(len - 1).get(size).setName(" ");
                    jewel_list.get(len - 2).get(size).setName(" ");
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                int x = 5;
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((set.contains(jewel_list.get(len + 1).get(size).getName())) && (set.contains(jewel_list.get(len + 2).get(size).getName()))){
                        GameGrid.score_sum += 60;
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len + 1).get(size).setName(" ");
                        jewel_list.get(len + 2).get(size).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
    }
    // The method we use for letters to check up and down directions.
    public void up_down_checker(ArrayList<ArrayList<Jewel>> jewel_list,int len,int size){
        if (!(jewel_list.get(len).get(size).getName().equals("W"))){
            String temp = jewel_list.get(len).get(size).getName();
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((jewel_list.get(len - 1).get(size).getName().equals(temp)) && (jewel_list.get(len - 2).get(size).getName().equals(temp))){
                        GameGrid.score_sum += (3 * (jewel_list.get(len).get(size).getScore()));
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len - 1).get(size).setName(" ");
                        jewel_list.get(len - 2).get(size).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((jewel_list.get(len + 1).get(size).getName().equals(temp)) && (jewel_list.get(len + 2).get(size).getName().equals(temp))){
                        GameGrid.score_sum += (3 * (jewel_list.get(len).get(size).getScore()));
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len + 1).get(size).setName(" ");
                        jewel_list.get(len + 2).get(size).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
        else {
            try {
                String check1 = jewel_list.get(len - 1).get(size).getName();
                String check2 = jewel_list.get(len - 2).get(size).getName();
                if ((!(GameGrid.math_list.contains(check1))) && (!(GameGrid.math_list.contains(check2)))){
                    if ((!(check1.equals(" "))) && (!(check2.equals(" ")))){
                        if ((jewel_list.get(len - 1).get(size).getName().equals(jewel_list.get(len - 2).get(size).getName()))){
                            GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                            GameGrid.score_sum += jewel_list.get(len - 1).get(size).getScore();
                            GameGrid.score_sum += jewel_list.get(len - 2).get(size).getScore();
                            jewel_list.get(len).get(size).setName(" ");
                            jewel_list.get(len - 1).get(size).setName(" ");
                            jewel_list.get(len - 2).get(size).setName(" ");
                        }
                        else if (((jewel_list.get(len - 1).get(size).getName().equals("W"))) || (jewel_list.get(len - 2).get(size).getName().equals("W"))){
                            GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                            GameGrid.score_sum += jewel_list.get(len - 1).get(size).getScore();
                            GameGrid.score_sum += jewel_list.get(len - 2).get(size).getScore();
                            jewel_list.get(len).get(size).setName(" ");
                            jewel_list.get(len - 1).get(size).setName(" ");
                            jewel_list.get(len - 2).get(size).setName(" ");
                        }
                    }
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                int x = 5;
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    String check1 = jewel_list.get(len + 1).get(size).getName();
                    String check2 = jewel_list.get(len + 2).get(size).getName();
                    if ((!(GameGrid.math_list.contains(check1))) && (!(GameGrid.math_list.contains(check2)))){
                        if ((!(check1.equals(" "))) && (!(check2.equals(" ")))){
                            if ((jewel_list.get(len + 1).get(size).getName().equals(jewel_list.get(len + 2).get(size).getName()))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 1).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 2).get(size).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len + 1).get(size).setName(" ");
                                jewel_list.get(len + 2).get(size).setName(" ");
                            }
                            else if (((jewel_list.get(len + 1).get(size).getName().equals("W"))) || (jewel_list.get(len + 2).get(size).getName().equals("W"))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 1).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 2).get(size).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len + 1).get(size).setName(" ");
                                jewel_list.get(len + 2).get(size).setName(" ");
                            }
                        }
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
    }
    // The method we use for math symbols. It has the same logic with left_right_checker but not the same algorithm.
    public void math_left_right(ArrayList<ArrayList<Jewel>> jewel_list, int len, int size, HashSet<String> set){
        if (!(jewel_list.get(len).get(size).getName().equals(" "))){
            try {
                if ((set.contains(jewel_list.get(len).get(size - 1).getName())) && (set.contains(jewel_list.get(len).get(size - 2).getName()))){
                    GameGrid.score_sum += 60;
                    jewel_list.get(len).get(size).setName(" ");
                    jewel_list.get(len).get(size - 1).setName(" ");
                    jewel_list.get(len).get(size - 2).setName(" ");
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                int x = 5;
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((set.contains(jewel_list.get(len).get(size + 1).getName())) && (set.contains(jewel_list.get(len).get(size + 2).getName()))){
                        GameGrid.score_sum += 60;
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len).get(size + 1).setName(" ");
                        jewel_list.get(len).get(size + 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
    }
    // The method we use for letters to check left and right directions.
    public void left_right_checker(ArrayList<ArrayList<Jewel>> jewel_list,int len,int size){
        if (!(jewel_list.get(len).get(size).getName().equals("W"))){
            String temp = jewel_list.get(len).get(size).getName();
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((jewel_list.get(len).get(size - 1).getName().equals(temp)) && (jewel_list.get(len).get(size - 2).getName().equals(temp))){
                        GameGrid.score_sum += (3 * (jewel_list.get(len).get(size).getScore()));
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len).get(size - 1).setName(" ");
                        jewel_list.get(len).get(size - 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((jewel_list.get(len).get(size + 1).getName().equals(temp)) && (jewel_list.get(len).get(size + 2).getName().equals(temp))){
                        GameGrid.score_sum += (3 * (jewel_list.get(len).get(size).getScore()));
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len).get(size + 1).setName(" ");
                        jewel_list.get(len).get(size + 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
        else {
            try {
                String check1 = jewel_list.get(len).get(size - 1).getName();
                String check2 = jewel_list.get(len).get(size - 2).getName();
                if ((!(GameGrid.math_list.contains(check1))) && (!(GameGrid.math_list.contains(check2)))){
                    if ((!(check1.equals(" "))) && (!(check2.equals(" ")))){
                        if ((jewel_list.get(len ).get(size - 1).getName().equals(jewel_list.get(len).get(size - 2).getName()))){
                            GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                            GameGrid.score_sum += jewel_list.get(len).get(size - 1).getScore();
                            GameGrid.score_sum += jewel_list.get(len).get(size - 2).getScore();
                            jewel_list.get(len).get(size).setName(" ");
                            jewel_list.get(len).get(size - 1).setName(" ");
                            jewel_list.get(len).get(size - 2).setName(" ");
                        }
                        else if ((jewel_list.get(len).get(size - 1).getName().equals("W")) || (jewel_list.get(len).get(size - 2).getName().equals("W")) ){
                            GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                            GameGrid.score_sum += jewel_list.get(len).get(size - 1).getScore();
                            GameGrid.score_sum += jewel_list.get(len).get(size - 2).getScore();
                            jewel_list.get(len).get(size).setName(" ");
                            jewel_list.get(len).get(size - 1).setName(" ");
                            jewel_list.get(len).get(size - 2).setName(" ");
                        }
                    }
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                int x = 5;
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    String check1 = jewel_list.get(len).get(size + 1).getName();
                    String check2 = jewel_list.get(len).get(size + 2).getName();
                    if ((!(GameGrid.math_list.contains(check1))) && (!(GameGrid.math_list.contains(check2)))){
                        if ((!(check1.equals(" "))) && (!(check2.equals(" ")))){
                            if ((jewel_list.get(len).get(size + 1).getName().equals(jewel_list.get(len).get(size + 2).getName()))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len).get(size + 1).getScore();
                                GameGrid.score_sum += jewel_list.get(len).get(size + 2).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len).get(size + 1).setName(" ");
                                jewel_list.get(len).get(size + 2).setName(" ");
                            }
                            else if ((jewel_list.get(len).get(size + 1).getName().equals("W")) || (jewel_list.get(len).get(size + 2).getName().equals("W"))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len).get(size + 1).getScore();
                                GameGrid.score_sum += jewel_list.get(len).get(size + 2).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len).get(size + 1).setName(" ");
                                jewel_list.get(len).get(size + 2).setName(" ");
                            }
                        }
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
    }
    // The method we use for math symbols. It has the same logic with diagonal_checker but not the same algorithm.
    public void math_right_diagonal(ArrayList<ArrayList<Jewel>> jewel_list,int len,int size, HashSet<String> set){
        if (!(jewel_list.get(len).get(size).getName().equals(" "))){
            try {
                if ((set.contains(jewel_list.get(len - 1).get(size + 1).getName())) && (set.contains(jewel_list.get(len - 2).get(size + 2).getName()))){
                    GameGrid.score_sum += 60;
                    jewel_list.get(len).get(size).setName(" ");
                    jewel_list.get(len - 1).get(size + 1).setName(" ");
                    jewel_list.get(len - 2).get(size + 2).setName(" ");
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                int x = 5;
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((set.contains(jewel_list.get(len + 1).get(size - 1).getName())) && (set.contains(jewel_list.get(len + 2).get(size - 2).getName()))){
                        GameGrid.score_sum += 60;
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len + 1).get(size - 1).setName(" ");
                        jewel_list.get(len + 2).get(size - 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
    }
    // The method we use for math symbols. It has the same logic with diagonal_checker but not the same algorithm.
    public void math_left_diagonal(ArrayList<ArrayList<Jewel>> jewel_list,int len,int size, HashSet<String> set){
        if (!(jewel_list.get(len).get(size).getName().equals(" "))){
            try {
                if ((set.contains(jewel_list.get(len - 1).get(size - 1).getName())) && (set.contains(jewel_list.get(len - 2).get(size - 2).getName()))){
                    GameGrid.score_sum += 60;
                    jewel_list.get(len).get(size).setName(" ");
                    jewel_list.get(len - 1).get(size - 1).setName(" ");
                    jewel_list.get(len - 2).get(size - 2).setName(" ");
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                int x = 5;
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((set.contains(jewel_list.get(len + 1).get(size + 1).getName())) && (set.contains(jewel_list.get(len + 2).get(size + 2).getName()))){
                        GameGrid.score_sum += 60;
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len + 1).get(size + 1).setName(" ");
                        jewel_list.get(len + 2).get(size + 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
    }
    // The method we use for letters to check left and right diagonal directions.
    public void diagonal_checker(ArrayList<ArrayList<Jewel>> jewel_list,int len,int size){
        if (!(jewel_list.get(len).get(size).getName().equals("W"))){
            String temp = jewel_list.get(len).get(size).getName();
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((jewel_list.get(len - 1).get(size - 1).getName().equals(temp)) && (jewel_list.get(len - 2).get(size - 2).getName().equals(temp))){
                        GameGrid.score_sum += (3 * (jewel_list.get(len).get(size).getScore()));
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len - 1).get(size - 1).setName(" ");
                        jewel_list.get(len - 2).get(size - 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((jewel_list.get(len + 1).get(size + 1).getName().equals(temp)) && (jewel_list.get(len + 2).get(size + 2).getName().equals(temp))){
                        GameGrid.score_sum += (3 * (jewel_list.get(len).get(size).getScore()));
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len + 1).get(size + 1).setName(" ");
                        jewel_list.get(len + 2).get(size + 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((jewel_list.get(len - 1).get(size + 1).getName().equals(temp)) && (jewel_list.get(len - 2).get(size + 2).getName().equals(temp))){
                        GameGrid.score_sum += (3 * (jewel_list.get(len).get(size).getScore()));
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len - 1).get(size + 1).setName(" ");
                        jewel_list.get(len - 2).get(size + 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    if ((jewel_list.get(len + 1).get(size - 1).getName().equals(temp)) && (jewel_list.get(len + 2).get(size - 2).getName().equals(temp))){
                        GameGrid.score_sum += (3 * (jewel_list.get(len).get(size).getScore()));
                        jewel_list.get(len).get(size).setName(" ");
                        jewel_list.get(len + 1).get(size - 1).setName(" ");
                        jewel_list.get(len + 2).get(size - 2).setName(" ");
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
        else {
            try {
                String check1 = jewel_list.get(len - 1).get(size - 1).getName();
                String check2 = jewel_list.get(len - 2).get(size - 2).getName();
                if ((!(GameGrid.math_list.contains(check1))) && (!(GameGrid.math_list.contains(check2)))){
                    if ((!(check1.equals(" "))) && (!(check2.equals(" ")))){
                        if ((jewel_list.get(len - 1).get(size - 1).getName().equals(jewel_list.get(len - 2).get(size - 2).getName()))){
                            GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                            GameGrid.score_sum += jewel_list.get(len - 1).get(size - 1).getScore();
                            GameGrid.score_sum += jewel_list.get(len - 2).get(size - 2).getScore();
                            jewel_list.get(len).get(size).setName(" ");
                            jewel_list.get(len - 1).get(size - 1).setName(" ");
                            jewel_list.get(len - 2).get(size - 2).setName(" ");
                        }
                        else if (jewel_list.get(len-1).get(size-1).getName().equals("W") || (jewel_list.get(len-2).get(size-2).getName().equals("W"))){
                            GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                            GameGrid.score_sum += jewel_list.get(len - 1).get(size - 1).getScore();
                            GameGrid.score_sum += jewel_list.get(len - 2).get(size - 2).getScore();
                            jewel_list.get(len).get(size).setName(" ");
                            jewel_list.get(len - 1).get(size - 1).setName(" ");
                            jewel_list.get(len - 2).get(size - 2).setName(" ");
                        }
                    }
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException){
                int x = 5;
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    String check1 = jewel_list.get(len + 1).get(size + 1).getName();
                    String check2 = jewel_list.get(len + 2).get(size + 2).getName();
                    if ((!(GameGrid.math_list.contains(check1))) && (!(GameGrid.math_list.contains(check2)))){
                        if ((!(check1.equals(" "))) && (!(check2.equals(" ")))){
                            if ((jewel_list.get(len + 1).get(size + 1).getName().equals(jewel_list.get(len + 2).get(size + 2).getName()))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 1).get(size + 1).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 2).get(size + 2).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len + 1).get(size + 1).setName(" ");
                                jewel_list.get(len + 2).get(size + 2).setName(" ");
                            }
                            else if (jewel_list.get(len + 1).get(size + 1).getName().equals("W") || (jewel_list.get(len + 2).get(size + 2).getName().equals("W"))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 1).get(size + 1).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 2).get(size + 2).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len + 1).get(size + 1).setName(" ");
                                jewel_list.get(len + 2).get(size + 2).setName(" ");
                            }
                        }
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    String check1 = jewel_list.get(len - 1).get(size + 1).getName();
                    String check2 = jewel_list.get(len - 2).get(size + 2).getName();
                    if ((!(GameGrid.math_list.contains(check1))) && (!(GameGrid.math_list.contains(check2)))){
                        if ((!(check1.equals(" "))) && (!(check2.equals(" ")))){
                            if ((jewel_list.get(len - 1).get(size + 1).getName().equals(jewel_list.get(len - 2).get(size + 2).getName()))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len - 1).get(size + 1).getScore();
                                GameGrid.score_sum += jewel_list.get(len - 2).get(size + 2).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len - 1).get(size + 1).setName(" ");
                                jewel_list.get(len - 2).get(size + 2).setName(" ");
                            }
                            else if (jewel_list.get(len - 1).get(size + 1).getName().equals("W") || (jewel_list.get(len - 2).get(size + 2).getName().equals("W"))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len - 1).get(size + 1).getScore();
                                GameGrid.score_sum += jewel_list.get(len - 2).get(size + 2).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len - 1).get(size + 1).setName(" ");
                                jewel_list.get(len - 2).get(size + 2).setName(" ");
                            }
                        }
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
            if (!(jewel_list.get(len).get(size).getName().equals(" "))){
                try {
                    String check1 = jewel_list.get(len + 1).get(size - 1).getName();
                    String check2 = jewel_list.get(len + 2).get(size - 2).getName();
                    if ((!(GameGrid.math_list.contains(check1))) && (!(GameGrid.math_list.contains(check2)))){
                        if ((!(check1.equals(" "))) && (!(check2.equals(" ")))){
                            if ((jewel_list.get(len + 1).get(size - 1).getName().equals(jewel_list.get(len + 2).get(size - 2).getName()))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 1).get(size - 1).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 2).get(size - 2).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len + 1).get(size - 1).setName(" ");
                                jewel_list.get(len + 2).get(size - 2).setName(" ");
                            }
                            else if (jewel_list.get(len + 1).get(size - 1).getName().equals("W") || (jewel_list.get(len + 2).get(size - 2).getName().equals("W"))){
                                GameGrid.score_sum += jewel_list.get(len).get(size).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 1).get(size - 1).getScore();
                                GameGrid.score_sum += jewel_list.get(len + 2).get(size - 2).getScore();
                                jewel_list.get(len).get(size).setName(" ");
                                jewel_list.get(len + 1).get(size - 1).setName(" ");
                                jewel_list.get(len + 2).get(size - 2).setName(" ");
                            }
                        }
                    }
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException){
                    int x = 5;
                }
            }
        }
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }
    public abstract void action(ArrayList<ArrayList<Jewel>> jewel_list,int len,int size);
}
