import java.util.ArrayList;

public class Math extends Jewel{
    Math(String name, int score) {
        super(name, score);
    }
    @Override
    public void action(ArrayList<ArrayList<Jewel>> jewel_list, int len, int size) {
        if (jewel_list.get(len).get(size).getName().equals("|")){
            math_up_down(jewel_list,len,size,GameGrid.math_list);
        }
        else if (jewel_list.get(len).get(size).getName().equals("-")){
            math_left_right(jewel_list,len,size,GameGrid.math_list);
        }
        else if (jewel_list.get(len).get(size).getName().equals("+")){
            math_left_right(jewel_list,len,size,GameGrid.math_list);
            math_up_down(jewel_list,len,size,GameGrid.math_list);
        }
        else if (jewel_list.get(len).get(size).getName().equals("\\")){
            math_left_diagonal(jewel_list,len,size,GameGrid.math_list);
        }
        else if (jewel_list.get(len).get(size).getName().equals("/")){
            math_right_diagonal(jewel_list,len,size,GameGrid.math_list);
        }
        /* you can add new jewels by putting a new else if and the rule of it */
    }
}
