import java.util.ArrayList;

public class Empty extends Jewel{
    Empty(String name, int score) {
        super(name, score);
    }

    @Override
    public void action(ArrayList<ArrayList<Jewel>> jewel_list, int len, int size) {
    }
}
