public class Food {
    private int food_ID;
    private String name_of_food;
    private int caloire;
    private String kind;
    public Food(String[] features){
        this.food_ID = Integer.parseInt(features[0]);
        this.name_of_food = features[1];
        this.caloire = Integer.parseInt(features[2]);
    }
    public int getFood_ID() {
        return food_ID;
    }
    public String getName_of_food() {
        return name_of_food;
    }
    public int getCaloire() {
        return caloire;
    }
    public void setKind(String kind) {
        this.kind = kind;
    }
}