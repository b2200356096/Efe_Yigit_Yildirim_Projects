import java.util.ArrayList;

public class People {
    private int people_ID;
    private String name;
    private String gender;
    private Integer weight;
    private Integer height;
    private Integer birth_day;
    private Integer calorie_need;
    private Integer calorie_taken = 0;
    private Integer calorie_burned = 0;
    public People(String[] features){
        this.people_ID = Integer.parseInt(features[0]);
        this.name = features[1];
        this.gender = features[2];
        this.weight = Integer.parseInt(features[3]);
        this.height = Integer.parseInt(features[4]);
        this.birth_day = Integer.parseInt(features[5]);
    }
    public int getPeople_ID() {
        return people_ID;
    }
    public String getName() {
        return name;
    }
    public String getGender() {
        return gender;
    }
    public Integer getWeight() {
        return weight;
    }
    public Integer getHeight() {
        return height;
    }
    public Integer getCalorie_need() {
        return calorie_need;
    }
    public void setCalorie_need(Integer calorie_need) {
        this.calorie_need = calorie_need;
    }
    public Integer getAge(){
        return 2022 - birth_day;
    }
    public Integer getCalorie_taken() {
        return calorie_taken;
    }
    public void setCalorie_taken(Integer calorie_taken) {
        this.calorie_taken += calorie_taken;
    }
    public Integer getCalorie_burned() {
        return calorie_burned;
    }
    public void setCalorie_burned(Integer calorie_burned) {
        this.calorie_burned += calorie_burned;
    }
    public Integer getCalorie_difference(){
        return (calorie_taken - calorie_burned) - (calorie_need);
    }
}