import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class Main {

    public static void main(String[] args) throws IOException {
        File people = new File("people.txt");
        FileReader p_reader = new FileReader(people);
        BufferedReader bp_reader = new BufferedReader(p_reader);
        String p_eachline;
        ArrayList<People> people_list = new ArrayList<People>();
        while ((p_eachline = bp_reader.readLine()) != null ){
            String[] p_eachline_list = p_eachline.split("\t");
            people_list.add(new People(p_eachline_list));
            for (People sta : people_list){
                if (sta.getGender().equals("male")){
                    double a = (66) + (13.75 * sta.getWeight()) + (5 * sta.getHeight()) - (6.8 * sta.getAge());
                    int b = (int) Math.round(a);
                    sta.setCalorie_need(b);
                }
                else if (sta.getGender().equals("female")){
                    double c = (665) + (9.6 * sta.getWeight()) + (1.7 * sta.getHeight() - (4.7 * sta.getAge()));
                    int d = (int) Math.round(c);
                    sta.setCalorie_need(d);
                }
            }
        }
        File food = new File("food.txt");
        FileReader f_reader = new FileReader(food);
        BufferedReader bf_reader = new BufferedReader(f_reader);
        String f_eachline;
        ArrayList<Food> food_list = new ArrayList<Food>();
        while ((f_eachline = bf_reader.readLine()) != null){
            String[] f_eachline_list = f_eachline.split("\t");
            food_list.add(new Food(f_eachline_list));
            int a = Integer.parseInt(f_eachline_list[0]);
            if ((a >= 1000) & (a < 1100)){
                for (Food tro : food_list){
                    if (tro.getName_of_food().equals(f_eachline_list[1])){
                        tro.setKind("fruit");
                    }
                }
            }
            else if ((a >= 1100) & (a < 1200)){
                for (Food tro : food_list){
                    if (tro.getName_of_food().equals(f_eachline_list[1])){
                        tro.setKind("meal");
                    }
                }
            }
            else if ((a >= 1200) & (a < 1300)){
                for (Food tro : food_list){
                    if (tro.getName_of_food().equals(f_eachline_list[1])){
                        tro.setKind("dessert");
                    }
                }
            }
            else if ((a >= 1300) & (a < 1400)){
                for (Food tro : food_list){
                    if (tro.getName_of_food().equals(f_eachline_list[1])){
                        tro.setKind("nuts");
                    }
                }
            }
        }
        File sport = new File("sport.txt");
        FileReader s_reader = new FileReader(sport);
        BufferedReader bs_reader = new BufferedReader(s_reader);
        String s_eachline;
        ArrayList<Sport> sport_list = new ArrayList<Sport>();
        while ((s_eachline = bs_reader.readLine()) != null){
            String[] s_eachline_list = s_eachline.split("\t");
            sport_list.add(new Sport(s_eachline_list));
        }
        File command = new File(args[0]);
        FileReader c_reader = new FileReader(command);
        BufferedReader bc_reader = new BufferedReader(c_reader);
        String c_eachline;
        File monitoring = new File("monitoring.txt");
        if (!monitoring.exists()){
            monitoring.createNewFile();
        }
        FileWriter m_writer = new FileWriter(monitoring, false);
        BufferedWriter bm_writer = new BufferedWriter(m_writer);
        ArrayList<People> list_include = new ArrayList<People>();
        ArrayList<People> list_include_warn = new ArrayList<People>();
        while ((c_eachline = bc_reader.readLine()) != null){
            if ("p".equals(String.valueOf(c_eachline.charAt(0)))){
                if (c_eachline.equals("printWarn")){
                    ArrayList<People> list_include_warn_remove = new ArrayList<People>();
                    for (People k : list_include){
                        if (k.getCalorie_difference() > 0){
                            list_include_warn.add(k);
                        }
                    }
                    if (list_include_warn.size() == 0){
                        bm_writer.write("there is no such person\n");
                        bm_writer.write("***************\n");
                    }
                    else {
                        for (People l : list_include_warn){
                            bm_writer.write(l.getName() + "\t" + String.valueOf(l.getAge()) + "\t" + String.valueOf(l.getCalorie_need()) + "kcal\t" + String.valueOf(l.getCalorie_taken()) + "kcal\t"
                                    + String.valueOf(l.getCalorie_burned()) + "kcal\t+" + String.valueOf(l.getCalorie_difference()) + "kcal\n");
                            list_include_warn_remove.add(l);
                        }
                        bm_writer.write("***************\n");
                        list_include_warn.removeAll(list_include_warn_remove);
                    }
                }
                else if (c_eachline.equals("printList")){
                    for (People f : list_include){
                        if (f.getCalorie_difference() <= 0){
                            bm_writer.write(f.getName() + "\t" + String.valueOf(f.getAge()) + "\t" + String.valueOf(f.getCalorie_need()) + "kcal\t" + String.valueOf(f.getCalorie_taken()) + "kcal\t" + String.valueOf(f.getCalorie_burned()) + "kcal\t" + String.valueOf(f.getCalorie_difference()) + "kcal\n");
                        }
                        else if (f.getCalorie_difference() > 0){
                            bm_writer.write(f.getName() + "\t" + String.valueOf(f.getAge()) + "\t" + String.valueOf(f.getCalorie_need()) + "kcal\t" + String.valueOf(f.getCalorie_taken()) + "kcal\t" + String.valueOf(f.getCalorie_burned()) + "kcal\t+" + String.valueOf(f.getCalorie_difference()) + "kcal\n");
                        }
                    }
                    bm_writer.write("***************\n");
                }
                else {
                    String updated = c_eachline.replace("print","");
                    updated = updated.replace("(","");
                    updated = updated.replace(")","");
                    Integer id_of = Integer.parseInt(updated);
                    for (People c : people_list){
                        if (c.getPeople_ID() == id_of){
                            if (c.getCalorie_difference() <= 0){
                                bm_writer.write(c.getName() + "\t" + String.valueOf(c.getAge()) + "\t" + String.valueOf(c.getCalorie_need()) + "kcal\t" + String.valueOf(c.getCalorie_taken()) + "kcal\t" + String.valueOf(c.getCalorie_burned()) + "kcal\t" + String.valueOf(c.getCalorie_difference()) + "kcal\n");
                            }
                            else if (c.getCalorie_difference() > 0){
                                bm_writer.write(c.getName() + "\t" + String.valueOf(c.getAge()) + "\t" + String.valueOf(c.getCalorie_need()) + "kcal\t" + String.valueOf(c.getCalorie_taken()) + "kcal\t" + String.valueOf(c.getCalorie_burned()) + "kcal\t+" + String.valueOf(c.getCalorie_difference()) + "kcal\n");
                            }
                        }
                    }
                    bm_writer.write("***************\n");
                }
            }
            else {
                String[] command_list_splitted = c_eachline.split("\t");
                Integer a1 = Integer.parseInt(command_list_splitted[1]);
                Integer a2 = Integer.parseInt(command_list_splitted[0]);
                double a3 = Double.parseDouble(command_list_splitted[2]);
                int c1 = 0;
                if ((a1 >= 1000) & (a1 < 1400)){
                    for (People i : people_list){
                        for (Food j : food_list){
                            if (i.getPeople_ID() == a2){
                                if (j.getFood_ID() == a1){
                                    Integer calorie_taken = j.getCaloire() * Integer.parseInt(command_list_splitted[2]);
                                    bm_writer.write(String.valueOf(i.getPeople_ID()) + "\thas\ttaken\t" + String.valueOf(calorie_taken) + "kcal\tfrom\t" + j.getName_of_food() + "\n");
                                    i.setCalorie_taken(calorie_taken);
                                    bm_writer.write("***************\n");
                                    if (!(list_include.contains(i))){
                                        list_include.add(i);
                                    }
                                }
                            }
                        }
                    }
                }
                else if ((a1 > 2000)){
                    for (People i : people_list){
                        for (Sport j : sport_list){
                            if (i.getPeople_ID() == a2){
                                if ((j.getSportID()) == a1){
                                    int calorie_burned = (int) ((a3/60) * j.getCalorie_burned());
                                    bm_writer.write(String.valueOf(i.getPeople_ID()) + "\thas\tburned\t" + String.valueOf(calorie_burned) + "kcal\tthanks to\t" + j.getName_of_sport() + "\n");
                                    i.setCalorie_burned(calorie_burned);
                                    bm_writer.write("***************\n");
                                    if (!(list_include.contains(i))){
                                        list_include.add(i);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        bm_writer.close();bf_reader.close();bp_reader.close();bs_reader.close();bc_reader.close();
        FileReader last_ri = new FileReader(monitoring);
        BufferedReader last_ride = new BufferedReader(last_ri);
        String l_each_line;
        ArrayList<String> last_list = new ArrayList<String>();
        while ((l_each_line = last_ride.readLine()) != null){
            last_list.add(l_each_line);
        }
        last_list.remove(last_list.size() - 1);
        FileWriter last_Wri = new FileWriter(monitoring);
        BufferedWriter last_Writer = new BufferedWriter(last_Wri);
        for (int i = 0;i < last_list.size();i++){
            if (i == last_list.size() - 1){
                last_Writer.write(last_list.get(i));
            }
            else {
                last_Writer.write(last_list.get(i));
                last_Writer.write("\n");
            }
        }
        last_ride.close();last_Writer.close();
    }
}