public class Sport {
    private int sportID;
    private String name_of_sport;
    private int calorie_burned;
    public Sport(String[] features){
        this.sportID = Integer.parseInt(features[0]);
        this.name_of_sport = features[1];
        this.calorie_burned = Integer.parseInt(features[2]);
    }
    public int getSportID() {
        return sportID;
    }
    public String getName_of_sport() {
        return name_of_sport;
    }
    public int getCalorie_burned() {
        return calorie_burned;
    }
}