#!/usr/bin/env python
# coding: utf-8

# # BBM409 Assignment_3
# 
# Group Member: Baran Kılıç 2210356108
# 
# Group Member: Efe Yiğit Yıldırım 2200356096

# ## Getting Data

# In[1]:


#We are importing the libraries for our assignment here
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix # Metrics
import random
import cv2
import os

flowers_path =  "C:/Users/barankilic/Desktop/flowers15"
data_paths = [flowers_path + '/train', flowers_path + '/val' , flowers_path + '/test']


# Here, we are reading our data into a numpy arrays using OpenCV.

# In[2]:


pixel_num = 64 #change this if you want different pixel number
train_x = np.zeros((pixel_num**2,10500 ))  # we know the total number of train images is 10500 and images are 64x64
validation_x = np.zeros((pixel_num**2, 2250)) # we know the total number of validation images is 2250 and images are 64x64
test_x = np.zeros((pixel_num**2, 2250)) # we know the total number of test images is 2250 and images are 64x64

train_y = np.full((10500,1), "", dtype='object')
validation_y = np.full((2250,1), "", dtype='object')
test_y = np.full((2250,1), "", dtype='object')

train_randomizer = list(range(10500))
val_randomizer = list(range(2250))
test_randomizer = list(range(2250))

# i is for deciding on train,validation and test
for i in range(3):
  curr_data_path = data_paths[i]
  for flower_folder in os.listdir(curr_data_path):
    flower_path = os.path.join(curr_data_path, flower_folder)
    for image_file in os.listdir(flower_path):
      image = cv2.resize(cv2.imread(os.path.join(flower_path, image_file), cv2.IMREAD_GRAYSCALE),(pixel_num,pixel_num)).flatten() / 255.0 #normalize the pixel values to the range [0, 1]
      if i==0:
        index = random.choice(train_randomizer)
        train_randomizer.remove(index)
        train_x[:,index] = image
        train_y[index,0] = flower_folder
      if i==1:
        index = random.choice(val_randomizer)
        val_randomizer.remove(index)
        validation_x[:,index] = image
        validation_y[index,0] = flower_folder
      if i==2:
        index = random.choice(test_randomizer)
        test_randomizer.remove(index)
        test_x[:,index] = image
        test_y[index,0] = flower_folder

#we need one hot encoding for labels
from sklearn.preprocessing import OneHotEncoder
encoder = OneHotEncoder()
train_y = encoder.fit_transform(train_y).toarray().T
validation_y = encoder.transform(validation_y).toarray().T
test_y = encoder.transform(test_y).toarray().T


# ## Part 1

# In[3]:


#Class of Neural Network
class MLPClassifier:
  def __init__(self,pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,batch_size,learning_rate,lr_decay,activation_funcs,layers,patience,max_epoch,encoder):
    if activation_funcs[-1] != "softmax":
      raise RuntimeError("Last activation function must be Softmax!")
    if layers[-1] < 2:
      raise RuntimeError("Last layer cannot contain less than 2 nodes!") #binary classification with 2 node

    self.pixel_num = pixel_num
    self.train_x = train_x
    self.validation_x = validation_x
    self.test_x = test_x
    self.train_y = train_y
    self.validation_y = validation_y
    self.test_y = test_y
    self.batch_size = batch_size
    self.learning_rate = learning_rate
    self.lr_decay = lr_decay
    self.activation_funcs = activation_funcs
    self.patience = patience
    self.max_epoch =max_epoch
    #here layers includes output layer too, for example if it is [64,15] then it means one hidden layer with 64 node and one output layer with 15 nodes
    weights = []
    biases = []
    for i in range(len(layers)):
      shape_1 = pixel_num**2  if i == 0 else layers[i-1]
      limit = np.sqrt(2 / (shape_1 + layers[i]))  # Xavier/Glorot initialization
      weights.append(np.random.uniform(-limit, limit, size=(layers[i], shape_1)))
      biases.append(np.random.randn(layers[i], 1)*0.001)
    self.weights = weights
    self.biases = biases
    #we are defining some functions here
    self.sigmoid = lambda x: 1 / (1 + np.exp(-1 * (x)))
    self.dsigmoid= lambda x: self.sigmoid(x)*(1-self.sigmoid(x))
    self.relu = lambda x: np.maximum(x,np.zeros(shape = x.shape))
    self.drelu = lambda x: np.where(x > 0, 1.0, 0.0)
    self.encoder = encoder

  #this is softmax function, it is used widely for multiclassification
  def softmax(self,data):
    e_x = np.exp(data)
    return e_x / np.sum(e_x, axis=0)


  '''
  We are computing cost with the NLL(negative log-likelihood).
  We are dividing by the size of the data because we don't want the
  cost to be dependent on the size of the data.
  '''
  def compute_cost(self,data,labels):
    temp =  labels * np.log(data)
    cost = -1 * np.sum(temp) / data.shape[1]
    return np.squeeze(cost)

  def linear_activation_forward(self,data):
    #here we are colculating σ(wx+b) for all σ functions and all layers
    Z = []
    A = []
    X = data
    for i in range(len(self.weights)):
      z_temp = np.dot(self.weights[i], X) + self.biases[i]
      a_temp = None
      if self.activation_funcs[i] == "relu":
        a_temp = self.relu(z_temp)
      elif self.activation_funcs[i] == "softmax":
         a_temp = self.softmax(z_temp)
      else:
        a_temp = self.sigmoid(z_temp)
      X = a_temp
      Z.append(z_temp)
      A.append(a_temp)
    return [Z,A]

  def linear_activation_backward(self,data,labels,Z,A):
    m = data.shape[1]
    lenWeights = len(self.weights)
    '''
    We know that the derivative of Cost with respect to dZ_output is A[-1] - Y
    when NLL and Softmax are used.
    '''
    dZ = A[-1] - labels
    dA = None
    dW = [0] * lenWeights
    db = [0] * lenWeights

    for i in range(lenWeights - 1, 0, -1):
      dW[i] =  np.dot(dZ, A[i - 1].T) / m
      db[i] =  np.array([np.sum(dZ, axis=1)]).T / m
      dA = np.dot(self.weights[i].T, dZ)
      if self.activation_funcs[i - 1] == "relu":
        dZ = dA * self.drelu(Z[i - 1])
      else:
        dZ = dA * self.dsigmoid(Z[i - 1])

    dW[0] =  np.dot(dZ, data.T) / m
    db[0] =  np.array([np.sum(dZ, axis=1)]).T / m
    for i in range(lenWeights):
      self.weights[i] -= self.learning_rate * dW[i]
      self.biases[i] -= self.learning_rate * db[i]

  def model(self):
    valcosts = []
    traincosts = []
    #we implemented our early stopping method with validation cost
    best_val_loss = float('inf')
    no_improvement_count = 0
    best_weights = []
    best_biases = []
    for i in range(self.max_epoch):
      #early stopping
      if i%10 == 0:
        Z_val , A_val = self.linear_activation_forward(self.validation_x)
        Z_train , A_train = self.linear_activation_forward(self.train_x)
        valcosts.append(self.compute_cost(A_val[-1],self.validation_y))
        traincosts.append(self.compute_cost(A_train[-1],self.train_y))
        if valcosts[-1] < best_val_loss:
             best_val_loss = valcosts[-1]
             no_improvement_count = 0
             best_weights.clear()
             best_biases.clear()
             for j in range(len(self.weights)):
               best_weights.append(self.weights[j].copy())
               best_biases.append(self.biases[j].copy())
        else:
             no_improvement_count += 1

        if no_improvement_count >= self.patience:
          break
        #learning rate decay in every 10 epochs
        if i > 1 and valcosts[-2] - valcosts[-1] <=0 and self.learning_rate >0.000625 :
          self.learning_rate *=  self.lr_decay

      #shuffling train data for batches
      indices = np.arange(self.train_x.shape[1])
      np.random.shuffle(indices)
      self.train_x = self.train_x[:, indices]
      self.train_y = self.train_y[:, indices]
      train_x_batch =  [self.train_x[:, i:i+self.batch_size] for i in range(0, self.train_x.shape[1], self.batch_size)]
      train_y_batch = [self.train_y[:, i:i+self.batch_size] for i in range(0, self.train_y.shape[1], self.batch_size)]

      #training
      for j in range(len(train_x_batch)):
        Z , A = self.linear_activation_forward(train_x_batch[j])
        self.linear_activation_backward(train_x_batch[j],train_y_batch[j],Z,A)

    self.weights = best_weights
    self.biases = best_biases
    return [valcosts,traincosts]

  def predict(self,data_x,data_y):
    Z , A = self.linear_activation_forward(data_x)
    pred_temp = np.argmax(A[-1], axis=0)
    pred = np.zeros_like(A[-1])
    pred[pred_temp, np.arange(A[-1].shape[1])] = 1
    pred = self.encoder.inverse_transform(pred.T)
    true = self.encoder.inverse_transform(data_y.T)
    all_labels = np.unique(pred)
    print("Accuracy: " + str(accuracy_score(true,pred)))
    print("Recall: " + str(recall_score(true,pred,average="macro",zero_division = 0)))
    print("Precision: " + str(precision_score(true,pred,average="macro",zero_division = 0)))
    print("F1 Score: " + str(f1_score(true,pred,average="macro", zero_division= 0)))
    cm = confusion_matrix(true, pred,labels = all_labels)
    plt.figure(figsize=(6, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=all_labels, yticklabels=all_labels)
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')
    plt.title('Confusion Matrix')
    plt.show()

  def printCost(self,cost,cost_type):
    if cost_type =="validation":
      plt.title('Validation Cost')
    else:
      plt.title('Train Cost')
    plt.xlabel("NUMBER OF EPOCHS")
    plt.ylabel("COST")
    plt.plot([i*10 for i in range(len(cost))],cost)
    plt.show()

  def visualization(self):
    fl_weights = self.weights[0].copy()
    fl_weights = (fl_weights - np.min(fl_weights)) / (np.max(fl_weights) - np.min(fl_weights))
    num_neurons = fl_weights.shape[0]

    #First layer(here we are visualizing weights of neurons of first layer)
    for i in range(num_neurons):
      neuron = fl_weights[i].reshape((self.pixel_num, self.pixel_num))
      plt.title("Neuron "+ str(i+1) + " of first layer:")
      plt.imshow(neuron, cmap='gray')
      plt.axis('off')
      plt.show()

    '''
    Other layers(Here, we are visualizing as in the first layer(same format).
    However, here the pixel(assume starting from (1,1)) at (a,b) demonstrates
    the relationship between this layer's ath neuron and previous layer's bth neuron.)
    '''
    for i in range(1,len(self.weights)):
      temp = self.weights[i].copy()
      temp = (temp - np.min(temp)) / (np.max(temp) - np.min(temp))
      plt.title("Weights of all neurons in the layer "+ str(i+1) + ":")
      plt.imshow(temp, cmap='gray')
      plt.axis('off')
      plt.show()


# Test 1:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[4]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 1 visualization:

# In[5]:


mlpc.visualization()


# Test 2:
# 
# batch_size = 32
# 
# learning_rate = 0.0125
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[6]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.0125,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 2 visualization:

# In[7]:


mlpc.visualization()


# Test 3:
# 
# batch_size = 32
# 
# learning_rate = 0.015
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[8]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.015,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 3 visualization:

# In[9]:


mlpc.visualization()


# Test 4:
# 
# batch_size = 32
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[10]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.0175,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 4 visualization:

# In[11]:


mlpc.visualization()


# Test 5:
# 
# batch_size = 64
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[12]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.005,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 5 visualization:

# In[13]:


mlpc.visualization()


# Test 6:
# 
# batch_size = 64
# 
# learning_rate = 0.0125
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[14]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.0125,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 6 visualization:

# In[15]:


mlpc.visualization()


# Test 7:
# 
# batch_size = 64
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[16]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.0175,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 7 visualization:

# In[17]:


mlpc.visualization()


# Test 8:
# 
# batch_size = 96
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[18]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,96,0.005,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 8 visualization:

# In[19]:


mlpc.visualization()


# Test 9:
# 
# batch_size = 96
# 
# learning_rate = 0.0125
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[20]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,96,0.0125,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 9 visualization:

# In[21]:


mlpc.visualization()


# Test 10:
# 
# batch_size = 96
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 15,
# 
# activation_funcs = softmax,

# In[22]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,96,0.0175,0.5,["softmax"],[15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 10 visualization:

# In[23]:


mlpc.visualization()


# Test 11:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 100,15,
# 
# activation_funcs = relu,softmax,

# In[24]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["relu","softmax"],[100,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 11 visualization:

# In[25]:


mlpc.visualization()


# Test 12:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 100,15,
# 
# activation_funcs = sigmoid,softmax,

# In[26]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["sigmoid","softmax"],[100,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 12 visualization:

# In[27]:


mlpc.visualization()


# Test 13:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 200,15,
# 
# activation_funcs = relu,softmax,

# In[28]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["relu","softmax"],[200,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 13 visualization:

# In[29]:


mlpc.visualization()


# Test 14:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 200,15,
# 
# activation_funcs = sigmoid,softmax,

# In[30]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["sigmoid","softmax"],[200,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 14 visualization:

# In[31]:


mlpc.visualization()


# Test 15:
# 
# batch_size = 64
# 
# learning_rate = 0.0125
# 
# learning_rate_decay = 0.5
# 
# layers = 100,15,
# 
# activation_funcs = relu,softmax,

# In[32]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.0125,0.5,["relu","softmax"],[100,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 15 visualization:

# In[33]:


mlpc.visualization()


# Test 16:
# 
# batch_size = 64
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 100,15,
# 
# activation_funcs = relu,softmax,

# In[34]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.0175,0.5,["relu","softmax"],[100,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 16 visualization:

# In[35]:


mlpc.visualization()


# Test 17:
# 
# batch_size = 64
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 200,15,
# 
# activation_funcs = relu,softmax,

# In[36]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.0175,0.5,["relu","softmax"],[200,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 17 visualization:

# In[37]:


mlpc.visualization()


# Test 18:
# 
# batch_size = 64
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 200,15,
# 
# activation_funcs = sigmoid,softmax,

# In[38]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.0175,0.5,["sigmoid","softmax"],[200,15],3,5000,encoder)
#patience is 3 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 18 visualization:

# In[39]:


mlpc.visualization()


# Test 19:
# 
# batch_size = 96
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 300,15,
# 
# activation_funcs = relu,softmax,

# In[40]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,96,0.005,0.5,["relu","softmax"],[300,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 19 visualization:

# In[41]:


mlpc.visualization()


# Test 20:
# 
# batch_size = 96
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 300,15,
# 
# activation_funcs = sigmoid,softmax,

# In[43]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,96,0.0175,0.5,["sigmoid","softmax"],[300,15],3,5000,encoder)
#patience is 3 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 20 visualization:

# In[44]:


mlpc.visualization()


# Test 21:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 200,100,15,
# 
# activation_funcs = relu,relu,softmax,

# In[45]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["relu","relu","softmax"],[200,100,15],5,5000,encoder)
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 21 visualization:

# In[46]:


mlpc.visualization()


# Test 22:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 200,100,15,
# 
# activation_funcs = relu,sigmoid,softmax,

# In[48]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["relu","sigmoid","softmax"],[200,100,15],3,5000,encoder)
#patience is 3 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 22 visualization:

# In[49]:


mlpc.visualization()


# Test 23:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 400,200,15,
# 
# activation_funcs = relu,relu,softmax,

# In[51]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["relu","relu","softmax"],[400,200,15],3,5000,encoder)
#patience is 3 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 23 visualization:

# In[52]:


mlpc.visualization()


# Test 24:
# 
# batch_size = 32
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 400,200,15,
# 
# activation_funcs = sigmoid,sigmoid,softmax,

# In[55]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,32,0.005,0.5,["sigmoid","sigmoid","softmax"],[400,200,15],3,500,encoder)
#patience is 3 and max_epoch = 500 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 24 visualization:

# In[56]:


mlpc.visualization()


# Test 25:
# 
# batch_size = 64
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 300,150,15,
# 
# activation_funcs = relu,sigmoid,softmax,

# In[57]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.005,0.5,["relu","sigmoid","softmax"],[300,150,15],3,500,encoder)
#patience is 3 and max_epoch = 500 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 25 visualization:

# In[58]:


mlpc.visualization()


# Test 26:
# 
# batch_size = 64
# 
# learning_rate = 0.0125
# 
# learning_rate_decay = 0.5
# 
# layers = 200,100,15,
# 
# activation_funcs = sigmoid,relu,softmax,

# In[60]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.0125,0.5,["sigmoid","relu","softmax"],[200,100,15],3,500,encoder)
#patience is 3 and max_epoch = 500 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 26 visualization:

# In[61]:


mlpc.visualization()


# Test 27:
# 
# batch_size = 64
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 250,50,15,
# 
# activation_funcs = relu,sigmoid,softmax,

# In[62]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,64,0.0175,0.5,["relu","sigmoid","softmax"],[250,50,15],3,500,encoder)
#patience is 3 and max_epoch = 500 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 27 visualization:

# In[63]:


mlpc.visualization()


# Test 28:
# 
# batch_size = 96
# 
# learning_rate = 0.005
# 
# learning_rate_decay = 0.5
# 
# layers = 300,50,15,
# 
# activation_funcs = sigmoid,sigmoid,softmax,

# In[64]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,96,0.005,0.5,["sigmoid","sigmoid","softmax"],[300,50,15],3,500,encoder)
#patience is 3 and max_epoch = 500 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 28 visualization:

# In[65]:


mlpc.visualization()


# Test 29:
# 
# batch_size = 96
# 
# learning_rate = 0.0125
# 
# learning_rate_decay = 0.5
# 
# layers = 300,50,15,
# 
# activation_funcs = sigmoid,sigmoid,softmax,

# In[66]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,96,0.0125,0.5,["sigmoid","sigmoid","softmax"],[300,50,15],3,500,encoder)
#patience is 3 and max_epoch = 500 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 29 visualization:

# In[67]:


mlpc.visualization()


# Test 30:
# 
# batch_size = 96
# 
# learning_rate = 0.0175
# 
# learning_rate_decay = 0.5
# 
# layers = 400,75,15,
# 
# activation_funcs = relu,sigmoid,softmax,

# In[68]:


mlpc = MLPClassifier(pixel_num,train_x,validation_x,test_x,train_y,validation_y,test_y,96,0.0175,0.5,["relu","sigmoid","softmax"],[400,75,15],3,500,encoder)
#patience is 3 and max_epoch = 500 because it becomes too long in patience 5
valcosts,traincosts = mlpc.model()
mlpc.printCost(valcosts,"validation")
mlpc.printCost(traincosts,"train")
mlpc.predict(mlpc.test_x,mlpc.test_y)


# Test 30 visualization:

# In[69]:


mlpc.visualization()


# ## Part 2

# First, we need to start by loading the data with the Dataloader.

# In[2]:


import torch
import torchvision.models as models
import torch.optim as optim
import torch.nn as nn
from torchvision import datasets, transforms
from torchvision.models.vgg import VGG19_Weights

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
transform = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor(),transforms.Normalize(mean=[0.485, 0.456, 0.406],std=[0.229, 0.224, 0.225]),])

train_image_folder = datasets.ImageFolder(root=flowers_path +'/train', transform=transform)
validation_image_folder = datasets.ImageFolder(root=flowers_path +'/val', transform=transform)
test_image_folder = datasets.ImageFolder(root=flowers_path +'/test', transform=transform)


train_32 = torch.utils.data.DataLoader(train_image_folder, batch_size=32, shuffle=True, pin_memory=True)
validation_32 = torch.utils.data.DataLoader(validation_image_folder, batch_size=32, shuffle=False, pin_memory=True)
test_32 = torch.utils.data.DataLoader(test_image_folder, batch_size=32, shuffle=False, pin_memory=True)


# Now we can start implementing the CNN.

# In[3]:


class VGG19_PT:
  def __init__(self,device,train,validation,test,all_weights,learning_rate,patience,max_epoch):
    self.device = device
    self.train = train
    self.validation = validation
    self.test = test

    vgg19 = models.vgg19(weights=VGG19_Weights.DEFAULT)

    #freezing
    if not all_weights:
      for param in vgg19.features.parameters():
        param.requires_grad = False
      vgg19.classifier[0] = nn.Linear(in_features=25088, out_features=4096, bias=True)  # FC1
      vgg19.classifier[3] = nn.Linear(in_features=4096, out_features=4096, bias=True)    # FC2

    vgg19.classifier[6] = nn.Linear(in_features=4096, out_features=15, bias=True)
    vgg19 = vgg19.to(self.device)
    self.vgg19 = vgg19
    self.criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(vgg19.parameters(), lr=learning_rate, momentum=0.9)
    self.optimizer = optimizer
    self.max_epoch = max_epoch
    self.patience = patience


  def compute_cost(self, dataloader):
    self.vgg19.eval()
    total_loss = 0.0
    total_samples = 0
    with torch.no_grad():
      for data, labels in dataloader:
        data, labels = data.to(self.device), labels.to(self.device)
        outputs = self.vgg19(data)
        loss = self.criterion(outputs, labels)
        total_loss += loss.item() * data.size(0)
        total_samples += data.size(0)
    return total_loss / total_samples

  def predict(self,dataloader):
    self.vgg19.eval()
    pred = []
    true = []
    class_to_idx = dataloader.dataset.class_to_idx
    idx_to_class = {v: k for k, v in class_to_idx.items()}
    with torch.no_grad():
      for data, labels in dataloader:
        data, labels = data.to(self.device), labels.to(self.device)
        outputs = self.vgg19(data)
        _, predicted = torch.max(outputs, 1)
        pred.extend([idx_to_class[i] for i in predicted.cpu().numpy()])
        true.extend([idx_to_class[i] for i in labels.cpu().numpy()])
    all_labels = np.unique(pred)
    print("Accuracy: " + str(accuracy_score(true,pred)))
    print("Recall: " + str(recall_score(true,pred,average="macro",zero_division = 0)))
    print("Precision: " + str(precision_score(true,pred,average="macro",zero_division = 0)))
    print("F1 Score: " + str(f1_score(true,pred,average="macro", zero_division= 0)))
    cm = confusion_matrix(true, pred,labels = all_labels)
    plt.figure(figsize=(6, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=all_labels, yticklabels=all_labels)
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')
    plt.title('Confusion Matrix')
    plt.show()

  def printCost(self,cost,cost_type):
    if cost_type =="validation":
      plt.title('Validation Cost')
    else:
      plt.title('Train Cost')
    plt.xlabel("NUMBER OF EPOCHS")
    plt.ylabel("COST")
    plt.plot(cost)
    plt.show()

  def model(self):
    valcosts = []
    traincosts = []
    best_val_loss = float('inf')
    no_improvement_count = 0
    best_state = None

    for i in range(self.max_epoch):
      '''
      We implemented early stopping here for 1 epoch instead of 10 epochs.
      The main reason for this is that the code takes excessively long to run,
      and the learning rate is very high. These two features complement each other.
      '''
      valcosts.append(self.compute_cost(self.validation))
      traincosts.append(self.compute_cost(self.train))
      if valcosts[-1] < best_val_loss:
            best_val_loss = valcosts[-1]
            no_improvement_count = 0
            best_state = self.vgg19.state_dict()
      else:
            no_improvement_count += 1

      if no_improvement_count >= self.patience:
        break

      self.vgg19.train()
      for data, labels in self.train:
        data, labels = data.to(self.device), labels.to(self.device)
        self.optimizer.zero_grad()
        outputs = self.vgg19(data)
        loss = self.criterion(outputs, labels)
        loss.backward()
        self.optimizer.step()
    self.vgg19.load_state_dict(best_state)
    return [valcosts,traincosts]

  '''
  We only visualizing the first layer here. The main reason for this is the
  large structure of VGG19, and we want to focus on seeing only the main components.
  '''
  def visualize_first_layer(self):
    first_layer = self.vgg19.features[0]
    weights = first_layer.weight.data.cpu().numpy()
    weights = (weights - weights.min()) / (weights.max() - weights.min())
    num_filters = weights.shape[0]
    for i in range(num_filters):
      rgb_filter = weights[i].transpose((1, 2, 0))
      plt.title("Filter "+ str(i+1) + " of first layer:")
      plt.imshow(rgb_filter)
      plt.axis('off')
      plt.show()


# Test 1:
# 
# Finetune the weights of all layers
# 
# Batch size = 32
# 
# learning rate = 0.005

# In[4]:


vgg19_pt_o = VGG19_PT(device,train_32,validation_32,test_32,True,0.005,3,50)
valcosts, traincosts = vgg19_pt_o.model()
vgg19_pt_o.printCost(valcosts,"validation")
vgg19_pt_o.printCost(traincosts,"train")
vgg19_pt_o.predict(vgg19_pt_o.test)


# Test 1 visualization(only first layer):

# In[5]:


vgg19_pt_o.visualize_first_layer()


# Test 2:
# 
# Finetune the weights of only two last fully connected (FC1 and FC2) layers
# 
# Batch size = 32
# 
# learning rate = 0.005

# In[6]:


vgg19_pt_o = VGG19_PT(device,train_32,validation_32,test_32,False,0.005,3,50)
valcosts, traincosts = vgg19_pt_o.model()
vgg19_pt_o.printCost(valcosts,"validation")
vgg19_pt_o.printCost(traincosts,"train")
vgg19_pt_o.predict(vgg19_pt_o.test)


# Test 3:
# 
# Finetune the weights of only two last fully connected (FC1 and FC2) layers
# 
# Batch size = 32
# 
# learning rate = 0.0075

# In[7]:


vgg19_pt_o = VGG19_PT(device,train_32,validation_32,test_32,False,0.0075,3,50)
valcosts, traincosts = vgg19_pt_o.model()
vgg19_pt_o.printCost(valcosts,"validation")
vgg19_pt_o.printCost(traincosts,"train")
vgg19_pt_o.predict(vgg19_pt_o.test)


# Test 4:
# 
# Finetune the weights of only two last fully connected (FC1 and FC2) layers
# 
# Batch size = 32
# 
# learning rate = 0.01

# In[8]:


vgg19_pt_o = VGG19_PT(device,train_32,validation_32,test_32,False,0.01,3,50)
valcosts, traincosts = vgg19_pt_o.model()
vgg19_pt_o.printCost(valcosts,"validation")
vgg19_pt_o.printCost(traincosts,"train")
vgg19_pt_o.predict(vgg19_pt_o.test)


# Test 5:
# 
# Finetune the weights of only two last fully connected (FC1 and FC2) layers
# 
# Batch size = 32
# 
# learning rate = 0.015

# In[9]:


vgg19_pt_o = VGG19_PT(device,train_32,validation_32,test_32,False,0.015,3,50)
valcosts, traincosts = vgg19_pt_o.model()
vgg19_pt_o.printCost(valcosts,"validation")
vgg19_pt_o.printCost(traincosts,"train")
vgg19_pt_o.predict(vgg19_pt_o.test)


# Test 6:
# 
# Finetune the weights of only two last fully connected (FC1 and FC2) layers
# 
# Batch size = 32
# 
# learning rate = 0.02

# In[4]:


vgg19_pt_o = VGG19_PT(device,train_32,validation_32,test_32,False,0.02,3,50)
valcosts, traincosts = vgg19_pt_o.model()
vgg19_pt_o.printCost(valcosts,"validation")
vgg19_pt_o.printCost(traincosts,"train")
vgg19_pt_o.predict(vgg19_pt_o.test)


# Test 2-6(we freezed layers so they are same) visualization(only first layer):

# In[5]:


vgg19_pt_o.visualize_first_layer()


# ## Report

# First of all, let's talk about how we implemented MLP and CNN. While implementing MLP, we used Negative log-likelihood(Calculated as −log(y), where y is a prediction corresponding to the true label) as the loss function and used the softmax activation function for the last layer. We took things like layer number, batch size, layer neuron size as parameters. Thus, we created MLP. For CNN, we used the ready-made vgg19 model available in the pytorch library.

# Now we are going to make experiments with various variable values and try to find the best results to work with and examine the affects of value changes of batch size, learning rate, learning rate decay and layers. Also we will change the activation functions that are used during the experiments.For our first 4 test for Part 1 we work with fixed batch_size = 32, learning_rate_decay = 0.5, layers = 15 values and activation_funcs = softmax function. In these tests, we change the learning rate values and look for the best one. When we examine them we can see that we get the best performance with the learning_rate = 0.0125 value for our accuracy , recall, precision, f1 Score values. Now in the next 3 test, again we are going to change learning rate values but now our batch size becomes 64. Actually when the batch size is 64 we cannot say there are really big performance differences in our scores but we got our best accuracy and recall values here from first 7 experiments when batch_size = 64 and learning_rate = 0.0175 and of course that is a an important thing. Now we are going to work with batch_size = 96. Actually with batch_size = 96 value we cannot say that our performance gets better. It is still in the same 0.17-0.18 interval and there is not some much reason to use batch_size with 96 value. We can also say that for these first 10 test batch size values don't make big differences. Now we are going to add a new layer and also add relu and sigmoid activation functions to our test and try to see their performance. For these new 4 test, I think there is something to say because when adding a new layer and an extra activation function improved our performance a bit. When we add a new layer with 100 neurons and add relu or sigmoid function, most of our scores got closer to the 0.19 value instead of 0.17-0.18 interval. But I think the biggest improvement happens when we add an layer with 200 neurons. Because our values go above 0.20 value. In fact, our accuracy and recall values go up to 0.21 when we have an extra layer with 200 neurons and with relu activation function. Now lets look at our scores when the batch_size = 64. We can say when the batch_size is 64 we get a good performance in general but there is a minor exception which is test 18. Unfortunately performance of that test get worse with the batch_size = 64. We can count on the test 17 because in these first 18 tests. Now lets look at the scores with batch_size = 96 and the extra layer with 300 neurons. We cannot say that batch_size with 96 value and extra layer with 300 neurons make an improvement in our scores. Our scores are not bad but there is no big difference in them. From now on, we are going to add two extra layers and we will change activations functions, batch size values and learning rate values. Lets test them and make a final comment about all of the test values. From now on we have made 30 test and we change our batch_size, learning_rate values. We add new layers with various neuron numbers and we make experiments with different activations functions. We can say that our scores go from our minimum 0.17 to maximum 0.21. We get our best results with the values in the tests named test13, test16, test17, test21, test30. So now it is appropriate to say that it is best for us to work with values from these tests.

# In the part2 we worked with torch's pretrained vgg19 and from the beginning we can easily say that usage of this is much better for our implementation because even with the worst performance of vgg19, performance of our program is better than all of the 30 tests of part1. Also, as we understand from the recall and precision values, there are big differences in the Confusion Matrix between part2 and part1. While the majority of the classes were found correct in part2 (close to 150), these numbers were very low in part1.So about the part2 we can say that we get the best performance when we finetune the weights of all layers and learning rate = 0.005. Our scores are above 0.85 and this is an incredible incrementation for us after part1.  After the test1 when we finetune the weights of only two last fully connected (FC1 and FC2) layers actually things are not that bad at the beginning but we see that our performance gets worse as we increase our learning rate. So we can say that the best learning rate for us is learning rate = 0.005 and it should not be increased.

# NOTE: The reason why we did less testing in Part 2 is that the training part takes too long, as you can see from the image file in the zip.
